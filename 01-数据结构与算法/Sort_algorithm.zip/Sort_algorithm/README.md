# 本仓库是对下面的视频进行简单实现

【只有程序员懂】 https://www.bilibili.com/video/BV1hM4y127NH

【原视频连接】：https://www.youtube.com/watch?v=kPRA0W1kECg

【原视频作者主页】：http://panthema.net/2013/sound-of-sorting/


> 原作者以C++实现，本仓库算是一种补充，欢迎各位大佬提出改进意见。


如果有任何问题可以随时交流! 如果对你有帮助，请别忘了给我一个star，非常感谢。


![](https://th.bing.com/th/id/OIP.5SgxDxkPLkRhGpMFrb9nGAAAAA?w=195&h=195&c=7&r=0&o=5&pid=1.7)


