# 算法笔记



[剑指offer](https://leetcode.cn/problem-list/xb9nqhhg/?topicSlugs=array&page=1)



[互联网笔试题](https://space.bilibili.com/1167140350)


