package com.zhaoyin;

import java.util.Scanner;

public class Main implements B{
    public static void main(String[] args) {

        new Main().print();
    }

    @Override
    public void print() {
        System.out.println("true = " + true);
    }

    @Override
    public void print1() {
        System.out.println("true = " + true);
    }
}


// 写一个抽象类
abstract class A{
    public abstract void print();
    //    普通方法
    public void print1(){
        System.out.println("print1");
    }



}


// 写一个接口
interface B{
    public void print();
    //    普通方法
    public void print1();

    default void print2(){
        System.out.println("print2");
    }

//    jdk1.9 以后可以private修饰方法
//    private void print3(){
//        System.out.println("print3");
//    }
}

