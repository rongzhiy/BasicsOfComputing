package com.baidu;
import java.util.Scanner;
//https://www.nowcoder.com/questionTerminal/5004e830579445acba8d2553cefec357
public class 最小值 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        long n = in.nextLong();
        long m = in.nextLong();
        long k = in.nextLong();
        if(n <= m){
            System.out.println(helper(n,m,k));
        }else{
            System.out.println(helper(m,n,k));
        }
    }

    public static long helper(long n,long m,long k){
        long num = k / m;
        return n - num;
    }
}
