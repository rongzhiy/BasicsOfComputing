package com.baidu;
//https://www.nowcoder.com/questionTerminal/daecc6edb5264b0d869e752bc8085571

import java.util.*;

public class 返回公司 {
    public static boolean isTouch;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int T = sc.nextInt();
        while (T-- > 0) {
            isTouch = false;
            int n = sc.nextInt();
            int m = sc.nextInt();
            Map<Integer, List<Integer>> map = new HashMap<>();
            while (m-- > 0) {
                int a = sc.nextInt();
                int b = sc.nextInt();
                List<Integer> tmpList = map.getOrDefault(a, new ArrayList<>());
                tmpList.add(b);
                map.put(a, tmpList);
                tmpList = map.getOrDefault(b, new ArrayList<>());
                tmpList.add(a);
                map.put(b, tmpList);
            }
            boolean[] vis = new boolean[n];
            vis[0] = true;
            helper(map, vis, 1, n, 2);
            System.out.println(isTouch == true ? "POSSIBLE" : "IMPOSSIBLE");
        }
    }
    public static void helper(Map<Integer, List<Integer>> map, boolean[] vis, int start, int end, int tili) {
        if (isTouch) return;
        if (tili == 0) {
            if (start == end) {
                isTouch = true;
            }
            return;
        }
        if (map.containsKey(start)) {
            List<Integer> tmpList = map.get(start);
            for (int t : tmpList) {
                if (vis[t - 1]) continue;
                vis[t - 1] = true;
                helper(map, vis, t, end, tili - 1);
                vis[t - 1] = false;
            }
        }
    }
}
