package com.acm;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//
public class Graph1 {
    public static void main(String[] args) {



    }
}
