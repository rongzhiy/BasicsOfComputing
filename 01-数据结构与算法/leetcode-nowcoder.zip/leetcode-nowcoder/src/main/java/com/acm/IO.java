package com.acm;

import java.util.Arrays;
import java.util.Scanner;

public class IO {
    public static void main(String[] args) {
//       add();
//        add1();
//        add2();
//        add3();
//        add4();
//        add5();
//        add6();
//        sort1();
//        sort2();
        sort3();

    }

    //输入数据包括多组。
    public static void add() {
        Scanner in = new Scanner(System.in);
        // hasNext 和 hasNextLine 的区别
        while (in.hasNextInt()) { // 注意 while 处理多个 case
            int a = in.nextInt();
            int b = in.nextInt();
            System.out.println(a + b);
        }
    }

    //输入数据包括多组。num为组数
    public static void add1() {
        Scanner in = new Scanner(System.in);
        int num = in.nextInt();
        while (num-- > 0) {  //num-- > 0 的意思是先判断num是否大于0，如果大于0，再执行num-1的操作
            int a = in.nextInt();
            int b = in.nextInt();
            System.out.println(a + b);
        }
    }

    //输入数据包括多组。0 0结束
    public static void add2() {
        Scanner in = new Scanner(System.in);
        // 注意 hasNext 和 hasNextLine 的区别
        while (in.hasNextInt()) { // 注意 while 处理多个 case
            int a = in.nextInt();
            int b = in.nextInt();
            if (a == 0 && b == 0) break;
            System.out.println(a + b);
        }
    }


//输入数据包括多组。
//每组数据一行,每行的第一个整数为整数的个数n(1 <= n <= 100), n为0的时候结束输入。
//接下来n个正整数,即需要求和的每个正整数。
    public static void add3() {
        Scanner in = new Scanner(System.in);
        int num = in.nextInt();
        int sum = 0;
        while (num != 0) {
            sum = 0;
            while (num-- > 0) {
                sum += in.nextInt();
            }
            System.out.println(sum);
            num = in.nextInt();
        }
    }

//    输入的第一行包括一个正整数t(1 <= t <= 100), 表示数据组数。
//    接下来t行, 每行一组数据。
//    每行的第一个整数为整数的个数n(1 <= n <= 100)。
//    接下来n个正整数, 即需要求和的每个正整数。
    public static void add4() {
        Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        int num = 0;
        int sum = 0;
        while (t-- > 0) {
            num = in.nextInt();
            sum = 0;
            while (num-- > 0) {
                sum += in.nextInt();
            }
            System.out.println(sum);
        }
    }


//    输入数据有多组, 每行表示一组输入数据。
//    每行的第一个整数为整数的个数n(1 <= n <= 100)。
//    接下来n个正整数, 即需要求和的每个正整数。
    public static void add5() {
        Scanner in = new Scanner(System.in);
        int num = 0;
        int sum = 0;
        while (in.hasNext()) {
            num = in.nextInt();
            sum = 0;
            while (num-- > 0) {
                sum += in.nextInt();
            }
            System.out.println(sum);
        }
    }

//    输入数据有多组, 每行表示一组输入数据。输出每一组数据的和
//    每行不定有n个整数，空格隔开。
    public static void add6() {
        Scanner sc = new Scanner(System.in);

        while (sc.hasNextLine()) {
            String[] strs = sc.nextLine().split(" ");
            int sum = 0;
            for (String str : strs) {
                sum += Integer.parseInt(str);
            }
            System.out.println(sum);
        }
    }

    /**
     * 字符串排序1
     * 输入有两行，第一行n
     * 第二行是n个空格隔开的字符串
     */
    public static void sort1() {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(); // 读取字符串数量
        sc.nextLine(); // 读取空白行

        String[] strings = new String[n];
        String inputLine = sc.nextLine(); // 读取字符串
        strings = inputLine.split(" "); // 使用空格将字符串分割成数组

        Arrays.sort(strings); // 对字符串数组进行排序

        // 打印排序后的字符串
        for (int i = 0; i < n; i++) {
            System.out.print(strings[i]);
            if (i < n - 1) {
                System.out.print(" "); // 在字符串之间添加空格，但不在末尾添加
            }
        }
    }

    /**
     * 字符串排序2
     * 多个测试用例，每个测试用例一行。
     * 每行通过空格隔开，有n个字符，n＜100
     */
    public static void sort2() {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextLine()) {
            String[] strings = sc.nextLine().split(" ");
            Arrays.sort(strings);
            for (int i = 0; i < strings.length; i++) {
                System.out.print(strings[i]);
                if (i < strings.length - 1) {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }

    /**
     * 字符串排序3
     * 多个测试用例，每个测试用例一行。
     * 每行通过,隔开，有n个字符，n＜100
     */
    public static void sort3() {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextLine()) {
            String[] strings = sc.nextLine().split(",");
            Arrays.sort(strings);
            for (int i = 0; i < strings.length; i++) {
                System.out.print(strings[i]);
                if (i < strings.length - 1) {
                    System.out.print(",");
                }
            }
            System.out.println();
        }
    }


}



