package com.alanxin.datastructure.sort;

public class MergeSort <T extends Comparable<T>> extends Sort<T> {
    //    归并排序
//    将数组分为两个子数组，分别对两个子数组进行排序，然后将两个子数组归并成一个有序的数组。
    private T[] aux;

    @Override
    public void sort(T[] nums) {
        aux = (T[]) new Comparable[nums.length];
        sort(nums, 0, nums.length - 1);
    }

    private void sort(T[] nums, int lo, int hi) {
        if (hi <= lo) {
            return;
        }
        int mid = lo + (hi - lo) / 2;
        sort(nums, lo, mid);
        sort(nums, mid + 1, hi);
        merge(nums, lo, mid, hi);
    }

    private void merge(T[] nums, int lo, int mid, int hi) {
        int i = lo, j = mid + 1;
        for (int k = lo; k <= hi; k++) {
            aux[k] = nums[k];
        }
        for (int k = lo; k <= hi; k++) {
            if (i > mid) {
                nums[k] = aux[j++];
            } else if (j > hi) {
                nums[k] = aux[i++];
            } else if (less(aux[j], aux[i])) {
                nums[k] = aux[j++];
            } else {
                nums[k] = aux[i++];
            }
        }
    }

    public static void main(String[] args) {
        Integer[] nums = {4, 5, 6, 3, 2, 1};
        MergeSort<Integer> mergeSort = new MergeSort<>();
        mergeSort.sort(nums);
        for (Integer num : nums) {
            System.out.println(num);
        }
    }
}
