package com.alanxin.datastructure.sort;

public class Insertion <T extends Comparable<T>> extends Sort<T> {
    //    插入排序
//    每次都将当前元素插入到左侧已经排序的数组中，使得插入之后左侧数组依然有序。
    @Override
    public void sort(T[] nums) {
        int N = nums.length;
        for (int i = 1; i < N; i++) {
            for (int j = i; j > 0 && less(nums[j], nums[j - 1]); j--) {
                swap(nums, j, j - 1);
            }
        }
    }

    public static void main(String[] args) {
        Integer[] nums = {4, 5, 6, 3, 2, 1};
        Insertion<Integer> insertion = new Insertion<>();
        insertion.sort(nums);
        for (Integer num : nums) {
            System.out.println(num);
        }
    }
}
