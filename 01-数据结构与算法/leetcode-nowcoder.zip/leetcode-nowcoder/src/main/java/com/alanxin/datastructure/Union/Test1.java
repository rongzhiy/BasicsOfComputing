package com.alanxin.datastructure.Union;

public class Test1 {
    public static void main(String[] args) {
//        String str1 = new String(new char[]{27, 91, 48, 49, 59, 51, 49, 109, 27, 91, 75, 27, 91, 109, 27, 91, 75});
        String str1 = new String(new char[]{27, 92, 48, 49, 59, 51, 49, 109, 27, 91, 75, 27, 91, 109, 27, 91, 75});
        System.out.println(str1.length());
        System.out.println(str1 + "1");

        String redColorCode = "\u001B[0;31m"; // 控制字符，用于设置字体颜色为红色
        String resetColorCode = "\u001B[0m"; // 控制字符，用于重置字体颜色
        String str2 = redColorCode + "Hello World!" + resetColorCode;
        System.out.println(str2);
    }
}
