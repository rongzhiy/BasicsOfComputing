package com.alanxin.datastructure.sort;

public class Shell <T extends Comparable<T>> extends Sort<T> {
    //    希尔排序
//    将数组中的元素分为几个子序列，分别进行插入排序，然后减小子序列的大小，再进行插入排序，直到子序列的大小为1。
    @Override
    public void sort(T[] nums) {
        int N = nums.length;
        int h = 1;
        while (h < N / 3) {
            h = 3 * h + 1;
        }
        while (h >= 1) {
            for (int i = h; i < N; i++) {
                for (int j = i; j >= h && less(nums[j], nums[j - h]); j -= h) {
                    swap(nums, j, j - h);
                }
            }
            h = h / 3;
        }
    }

    public static void main(String[] args) {
        Integer[] nums = {4, 5, 6, 3, 2, 1};
        Shell<Integer> shell = new Shell<>();
        shell.sort(nums);
        for (Integer num : nums) {
            System.out.println(num);
        }
    }
}
