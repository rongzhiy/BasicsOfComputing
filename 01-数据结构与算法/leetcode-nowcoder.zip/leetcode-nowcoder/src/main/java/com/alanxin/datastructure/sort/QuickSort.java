package com.alanxin.datastructure.sort;

public class QuickSort<T extends Comparable<T>> extends Sort<T> {
    //    快速排序
//    从数组中随机选择一个元素作为基准，将数组中小于基准的元素放在基准的左边，大于基准的元素放在基准的右边，然后对基准的左右两边的子数组进行快速排序。
    @Override
    public void sort(T[] nums) {
        sort(nums, 0, nums.length - 1);
    }

    private void sort(T[] nums, int lo, int hi) {
        if (hi <= lo) {
            return;
        }
        int j = partition(nums, lo, hi);
        sort(nums, lo, j - 1);
        sort(nums, j + 1, hi);
    }

    private int partition(T[] nums, int lo, int hi) {
        int i = lo;
        int j = hi + 1;
        T v = nums[lo];
        while (true) {
            while (less(nums[++i], v)) {
                if (i == hi) {
                    break;
                }
            }
            while (less(v, nums[--j])) {
                if (j == lo) {
                    break;
                }
            }
            if (i >= j) {
                break;
            }
            swap(nums, i, j);
        }
        swap(nums, lo, j);
        return j;
    }

    public static void main(String[] args) {
        Integer[] nums = {4, 5, 6, 3, 2, 1};
        QuickSort<Integer> quickSort = new QuickSort<>();
        quickSort.sort(nums);
        for (Integer num : nums) {
            System.out.println(num);
        }
    }
}