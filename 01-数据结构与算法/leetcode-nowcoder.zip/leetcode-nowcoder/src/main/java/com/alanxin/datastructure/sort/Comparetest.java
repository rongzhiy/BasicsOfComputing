package com.alanxin.datastructure.sort;

public abstract class Comparetest<T extends Comparable<T>>{

//    实现元素的比较
    public static <T extends Comparable<T>> int compare(T t1, T t2) {
        return t1.compareTo(t2);
    }
//    测试元素的比较

    public static void main(String[] args) {
//        测试compare方法
        System.out.println(Comparetest.compare(1, 4));
        System.out.println(Comparetest.compare(2, 1));
        System.out.println(Comparetest.compare(1, 1));
        System.out.println(Comparetest.compare("a", "b"));
        System.out.println(Comparetest.compare("b", "a"));
        System.out.println(Comparetest.compare("a", "a"));

    }



}
