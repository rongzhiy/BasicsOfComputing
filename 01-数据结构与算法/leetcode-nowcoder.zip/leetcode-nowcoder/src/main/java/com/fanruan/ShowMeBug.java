package com.fanruan;

//求解字符串转化为另一个字符串的最小代价
//x代表插入的代价，y代表删除的代价，z代表替换的代价
//        例如：virusA = "abc", virusB = "adc", x = 5, y = 3, z = 100

public class ShowMeBug {
    // 本题面试官已设置测试用例
    public int solution(String virusA, String virusB, int x, int y, int z) {
        // 在这⾥写代码

        // 创建一个二维数组dp，其中dp[i][j]表示将前i个字符转换为前j个字符的最小代价
        int[][] dp = new int[virusA.length() + 1][virusB.length() + 1];

        // 当virusB为空串时，将virusA转换为virusB的最小代价为i * j
        for (int i = 0; i <= virusA.length(); i++) {
            dp[i][0] = i * y;
        }
        // 当virusA为空串时，将virusA转换为virusB的最小代价为j * x
        for (int j = 0; j <= virusB.length(); j++) {
            dp[0][j] = j * x;
        }
        // 从前往后遍历virusA和virusB的每个字符
        for (int i = 1; i <= virusA.length(); i++) {
            for (int j = 1; j <= virusB.length(); j++) {
                if (virusA.charAt(i - 1) == virusB.charAt(j - 1)) { // 如果当前字符相同，不需要转换，代价不变
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = Math.min(dp[i - 1][j - 1] + z, Math.min(dp[i - 1][j] + y, dp[i][j - 1] + x));  // 如果当前字符不同，需要转换，取三种转换方式的最小值
                }
            }
        }
        return dp[virusA.length()][virusB.length()]; // 返回将virusA转换为virusB的最小代价
    }


    public static void main(String[] args) {
        ShowMeBug showMeBug = new ShowMeBug();
        System.out.println(showMeBug.solution("abc", "adc", 5, 3, 100));
    }
}
