package com.深信服;

import java.util.Scanner;

//Java实现：给定一个输入字符串s和一个字符模式p,s和p的长度均在100以内
//        要求实现一个支持.和*的正则表达式匹配。字符模式必须能够完全匹配
//        输入字符串。
//        如果匹配成功返回1，匹配失败返回0
//        请设计一个时间复杂度为O(m)或更优的算法来解决这个问题。如果使
//        用内置正则库得0分。
//        输入描述
//        第一行输入为字符串s
//        第二行输入为字符模式p
//        输出描述
//        如果匹配成功返回1，匹配失败返回0
//        1示例1
//        输入输出示例仅供调试，后台判题数据一般不包含示例
//        输入
//        复制
//        aaa
//        a*
//        输出
//        复制
//        1
public class Main2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String s = scanner.nextLine();
        String p = scanner.nextLine();

        boolean isMatch = isMatch(s, p);
        if (isMatch) {
            System.out.println(1);
        } else {
            System.out.println(0);
        }
    }

    public static boolean isMatch(String s, String p) {     // 动态规划
        int m = s.length();
        int n = p.length();

        // dp[i][j]表示s的前i个字符与p的前j个字符是否匹配
        boolean[][] dp = new boolean[m + 1][n + 1];
        dp[0][0] = true;

        // 处理s为空字符串的情况
        for (int j = 1; j <= n; j++) {
            if (p.charAt(j - 1) == '*') {
                // '*'可以将p的前j-2个字符消去，所以当前字符必须是'*'的前一个字符
                dp[0][j] = dp[0][j - 2];
            }
        }

        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (s.charAt(i - 1) == p.charAt(j - 1) || p.charAt(j - 1) == '.') {
                    // 当前字符匹配成功，则取决于前一个字符是否匹配成功
                    dp[i][j] = dp[i - 1][j - 1];
                } else if (p.charAt(j - 1) == '*') {
                    // 处理'*'的情况
                    if (s.charAt(i - 1) == p.charAt(j - 2) || p.charAt(j - 2) == '.') {
                        // '*'可以将p的前j-2个字符消去，也可以将s的前i-1个字符消去
                        dp[i][j] = dp[i][j - 2] || dp[i - 1][j];
                    } else {
                        // '*'只能将p的前j-2个字符消去
                        dp[i][j] = dp[i][j - 2];
                    }
                }
            }
        }

        return dp[m][n];
    }
}
