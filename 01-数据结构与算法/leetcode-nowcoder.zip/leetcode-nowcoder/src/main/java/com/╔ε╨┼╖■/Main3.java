package com.深信服;

import java.util.Scanner;

//Java实现：给定一个未经排序的整数数组，找到最长且连续递减的子序列，并返回
//        该序列的长度。
//        连续递减的子序列可以由两个下标I和”(1<)确定，如果对于每个
//        <=i<r,都有nums)<nums[i+1],那么子序列[nums,nums[l+1],nums[r-1],nums[]就是连续递增子序列。
//        )输入描述
//        未经排序的整数数组
//        I输出描述
//        返回连续递减子序列的长度
//        1示例1
//        输入输出示例仅供调试，后台判题数据一般不包含示例
//        输入
//        7,4,5,3,1
//        输出
//        3
public class Main3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 读取输入的数组
        String[] arr = scanner.nextLine().split(",");
        int n = arr.length;
        int[] nums = new int[n];
        for (int i = 0; i < n; i++) {
            nums[i] = Integer.parseInt(arr[i].trim());
        }

        int maxLength = findLongestDecreasingSubsequence(nums);
        System.out.println(maxLength);
    }

    public static int findLongestDecreasingSubsequence(int[] nums) {
        int maxLength = 0;
        int currentLength = 1;

        for (int i = 1; i < nums.length; i++) {
            if (nums[i] < nums[i - 1]) {
                // 当前数字小于前一个数字，连续递减子序列长度加1
                currentLength++;
            } else {
                // 当前数字大于等于前一个数字，连续递减子序列结束
                maxLength = Math.max(maxLength, currentLength);
                currentLength = 1;
            }
        }

        maxLength = Math.max(maxLength, currentLength);

        return maxLength;
    }
}
