package com.深信服;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

//Java实现输入需要统计的字符串，输出 输入字符串中不重复字符组成的字符集合个数 , 例如输入：abcd  输出：15。
// 输出的15表示的意思是：a','c','b','d','ac','ab','ad','cb','cd','bd','acb','acd','abd',
//'cbd','acbd']

public class Main1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str0  = sc.nextLine();

        if(str0.length() == 0) return;

        String str  = removeDuplicates(str0);  // 去重

        HashSet<String> set = new HashSet<>();
        combination(str, new StringBuilder(), 0, set);  // 组合
//        for (String s : set) {
//            System.out.println(s);
//        }
        System.out.println(set.size()-1);
    }

    private static String removeDuplicates(String str0) {
        // 创建一个HashSet用来存储不重复的字符
        HashSet<Character> set = new HashSet<>();
        // 遍历输入字符串中的每个字符
        for (int i = 0; i < str0.length(); i++) {
            set.add(str0.charAt(i));
        }
        // 将HashSet中的字符重新拼接成新的字符串
        StringBuilder sb = new StringBuilder();
        for (Character ch : set) {
            sb.append(ch);
        }
        return sb.toString();
    }

//      递归实现组合
    public static void combination(String str, StringBuilder sb, int index, HashSet<String> set) {

        set.add(sb.toString());  // 将组合的字符串加入到set中
        for (int i = index; i < str.length(); i++) {  // 从index开始遍历字符串
            sb.append(str.charAt(i));            //前序
            combination(str, sb, i + 1, set);   // 递归调用  中序
            sb.deleteCharAt(sb.length() - 1);   // 回溯   后序
        }
    }

}

