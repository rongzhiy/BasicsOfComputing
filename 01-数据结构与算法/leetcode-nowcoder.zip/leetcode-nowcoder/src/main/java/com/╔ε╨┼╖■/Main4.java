package com.深信服;

import java.util.*;
//有n个任务，序号从1到n,每个任务需要的编辑时间为t分钟。小明和
//        小白需要在对其中k个任务中进行编辑。
//        编辑的过程如下：门个任务按照顺序排列，他们删除-k个任务，不改
//        变剩下的k个任务的顺序。
//        然后小明选取全部任务的前面一部分任务（可能不选或所有任务），小白
//        选取剩余的。相当于将任务从某个位置分割成两部分，第一部分给小
//        明，第二部分给小白。
//        之后他们分别对各自的任务进行编辑，编辑所需的时间取决于两者中较
//        长的那个。
//        请帮助小明和小白选择任务和分割方式使编辑尽可能早地完成。
//        输入描述
//        第一行包含一个整数T(1≤T≤104)，表示测试用例的数量。
//        每个测试用例的第一行包含两个整数n和k(1≤k≤n≤3×10)，表示完整任务
//        集中的任务数量与小明和小白将进行编辑的任务数量。
//        第二行包含n个整数t1,2,,tn（1≤t≤10°)，表示每个编辑所需的时间。所有
//        测试用例中n的总和不超过3×105。
//        输出描述
//        对于每个测试用例输出一个整数，表示如果小明和小白选择个任务中的k个
//        问题进行编辑，并将它们分配给各自完成编辑所需的最短时间。
//
//        输入：
//        5
//        6 3
//        8 1 10 1 1 1
//        5 3
//        1 13 5 12 3
//        10 6
//        10 8 18 13 3 8 6 4 14 12
//        10 5
//        9 9 2 11 14 33 4 9 14 12
//        1 1
//        1
//
//        输出：
//        2
//        6
//        21
//        18
//        1

// Todo 结果不对，但是可以参考
public class Main4 {

    public  static  void  main(String[]  args)  {
        Scanner  scanner  =  new  Scanner(System.in);
        int  T  =  scanner.nextInt();
        int[]  res  =  new  int[T];
        for  (int  i  =  0;  i  <  T;  i++)  {
            int  n  =  scanner.nextInt();
            int  k  =  scanner.nextInt();
            int[]  t  =  new  int[n];
            for  (int  j  =  0;  j  <  n;  j++)  {
                t[j]  =  scanner.nextInt();
            }
            res[i]  =  findMinTime(n,  k,  t);   //  计算最小时间
        }

        for  (int  i  =  0;  i  <  T;  i++)  {
            System.out.println(res[i]);
        }
    }

    public  static  int  findMinTime(int  n,  int  k,  int[]  tasks)  {

        PriorityQueue<Integer> queue  =  new  PriorityQueue<>(Collections.reverseOrder());
        for  (int  task  :  tasks)  {
            queue.add(task);
        }
        ArrayList<Integer> mingTasks  =  new  ArrayList<>();
        for  (int  i  =  0;  i  <  k;  i++)  {
            mingTasks.add(queue.poll());
        }
        Collections.reverse(mingTasks);
        for  (int  task  :  mingTasks)  {
            queue.add(task);
        }
        int  maxTime  =  0;
        for  (int  i  =  0;  i  < k;  i++)  {
            int  time  =  Math.max(mingTasks.get(i),  queue.poll());
            maxTime  =  Math.max(maxTime,  time);
        }
        return  maxTime;
    }

//        Arrays.sort(t);
//        int  min  =  Integer.MAX_VALUE;
//        for  (int  i  =  0;  i  <=  k;  i++)  {
//            int  maxTime  =  0;
//            for  (int  j  =  0;  j  <  i;  j++)  {
//                maxTime  =  Math.max(maxTime,  t[j]);
//            }
//            for  (int  j  =  k  -  i;  j  <  n;  j++)  {
//                maxTime  =  Math.max(maxTime,  t[j]);
//            }
//            min  =  Math.min(min,  maxTime);
//        }
//        return  min;
//    }

}
