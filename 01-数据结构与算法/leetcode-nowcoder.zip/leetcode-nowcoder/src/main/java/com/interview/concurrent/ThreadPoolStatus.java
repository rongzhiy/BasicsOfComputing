package com.interview.concurrent;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ThreadPoolStatus {
    //    线程池的状态
//    1.运行状态 Running
//    2.关闭状态 Shutdown
//    3.停止状态 Stop
//    4.终止状态 Tidying
    public static void main(String[] args) {
        // 创建线程池
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(10, 10, 0, TimeUnit.SECONDS, new LinkedBlockingQueue<>());
        // 提交任务
        threadPoolExecutor.execute(() -> {
            System.out.println("ThreadPoolExecutor");
        });

        // 输出线程池的运行状态
        System.out.println("任务队列中的任务数量：" + threadPoolExecutor.getQueue().size());
        System.out.println("活动线程的数量：" + threadPoolExecutor.getActiveCount());

        // 关闭线程池
        threadPoolExecutor.shutdown();
    }
}
