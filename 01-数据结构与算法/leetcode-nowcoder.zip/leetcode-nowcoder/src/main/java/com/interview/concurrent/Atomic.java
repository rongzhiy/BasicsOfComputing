package com.interview.concurrent;

public class Atomic {
//    原子性
    //Java中我们需要通过各种锁机制来保证原子性。
    //程序例子
    //1.使用synchronized关键字
    //2.使用Lock
    //3.使用AtomicInteger
    //4.使用LongAdder

    public static void main(String[] args) {



    }


}
