package com.interview.often;

//Integer的常见面试题
public class IntegerTest {
    public static void main(String[] args) {
        Integer a = 100;
        Integer b = 100;
        System.out.println(a == b);//true
        Integer c = 1000;
        Integer d = 1000;
        System.out.println(c == d);//false   Integer的缓存机制，当数值在-128~127之间时，会从缓存中取，否则会new Integer
        Integer e = new Integer(100);
        Integer f = new Integer(100);
        System.out.println(e == f);//false  new Integer()会新建对象
        Integer g = new Integer(1000);
        Integer h = new Integer(1000);
        System.out.println(g == h);//false  new Integer()会新建对象
        Integer i = Integer.valueOf(100);
        Integer j = Integer.valueOf(100);
        System.out.println(i == j);//true   Integer.valueOf()会从缓存中取
        Integer k = Integer.valueOf(1000);
        Integer l = Integer.valueOf(1000);
        System.out.println(k == l);//false  Integer.valueOf()会从缓存中取
        Integer m = Integer.parseInt("100");
        Integer n = Integer.parseInt("100");
        System.out.println(m == n);//true   Integer.parseInt()会从缓存中取
        Integer o = Integer.parseInt("1000");
        Integer p = Integer.parseInt("1000");
        System.out.println(o == p);//false  Integer.parseInt()会从缓存中取，但是1000不在缓存中，所以会new Integer
    }

}
