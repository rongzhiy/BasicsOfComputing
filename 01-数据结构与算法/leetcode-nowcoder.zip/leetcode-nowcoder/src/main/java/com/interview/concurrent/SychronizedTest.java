package com.interview.concurrent;

public class SychronizedTest {
//    synchronized锁升级过程
//    1.偏向锁: 在锁对象的对象头中记录一下当前获取到该锁的线程ID，该线程下次如果又来获取该锁就可以直接获取到了，也就是支持锁重入
//    2.轻量级锁:由偏向锁升级而来，当一个线程获取到锁后，此时这把锁是偏向锁，此时如果有第二个线程来竞争锁，偏向锁就会升级为轻量级锁，之所以叫轻量级锁，是为了和重量级锁区分开来，轻量级锁底层是通过自旋来实现的，并不会阻塞线程
//    3.重量级锁:如果自旋次数过多仍然没有获取到锁，则会升级为重量级锁，重量级锁会导致线程阻塞
//    4.自旋锁: 自旋锁就是线程在获取锁的过程中，不会去阻塞线程，也就无所谓唤醒线程，阻塞和唤醒这两个步骤都是需要操作系统去进行的，比较消耗时间，自旋锁是线程通过CAS获取预期的一个标记，如果没有获取到，则继续循环获取，如果获取到了则表示获取到了锁，这个过程线程一直在运行中，相对而言没有使用太多的操作系统资源，比较轻量。
    public static void main(String[] args) {
        Counter counter = new Counter();
        for (int i = 0; i < 20; i++) {
            new Thread(() -> {
                counter.increment();
            }).start();
        }
        for (int i = 0; i < 20; i++) {
            new Thread(() -> {
                counter.decrement();
            }).start();
        }
    }

}

class Counter {
    private int count = 0;
    private Object lock = new Object();

    public void increment() {
        synchronized (lock) {
            // 第一级锁: 对象级别的锁
            count++;
            if (count >= 10) {
                // 锁升级
                synchronized (this) {
                    // 第二级锁: 类级别的锁
                    // 执行一些需要类级别锁的操作
                    System.out.println("count >= 10");
                }
            }
        }
    }

    public synchronized void decrement() {
        // 第二级锁: 类级别的锁
        count--;
        if (count <= 0) {
            // 锁降级
            synchronized (lock) {
                // 第一级锁: 对象级别的锁
                // 执行一些需要对象级别锁的操作
                System.out.println("count <= 0");
            }
        }
    }
}