package com.interview.web;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.ServerResponse;

import java.lang.annotation.Annotation;

import static org.springframework.web.servlet.function.RouterFunctions.route;

//    SpringBoot中的Handler四种类型(处理请求与请求处理)
//    1. @Controller+@RequestMapping注解的类
@Controller
class NameController2 {
    //    @RequestMapping("/name")
    @GetMapping("/name")
    public String name() {
        return "name";
    }
}


//    2.实现Controller接口的类: 通过实现Controller接口来处理请求,返回值是ModelAndView
@Component("/beanNameController")
class NameController implements Controller {

    public ModelAndView handleRequest(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws Exception {
        response.getWriter().println("Controller");
        return null;
    }
    @Override
    public String value() {
        return null;
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return null;
    }
}



//    3. HttpRequestHandler: 通过实现HttpRequestHandler接口来处理请求，返回值是void
class NameHandler implements org.springframework.web.HttpRequestHandler {

    @Override
    public void handleRequest(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {
            response.getWriter().write("hello");
    }
}

//    4.RouterFunction
public class HanderTest {

    @Bean
    public RouterFunction<ServerResponse> routerFunction() {
        return route()
                .GET("/hello", request -> ServerResponse.ok().body("hello"))
                .POST("/world", request -> ServerResponse.ok().body("world"))
                .build();

    }

}
