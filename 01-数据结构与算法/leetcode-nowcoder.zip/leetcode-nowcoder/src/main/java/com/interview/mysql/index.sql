
-- # 索引
select * from user;

-- # 查看user是否有索引
show indexes from user;

-- # 创建索引
create index head on user(user_head);

-- # 查看是否创建成功
explain select * from user where user_head = '1'; # 有索引
explain select * from user ;  # 没有用索引

-- # 删除索引
drop index head on user;


-- # mysql中每页大小为16k
-- # 一条数据大小为 1k

-- # 优化
-- # 1.创建索引 B+树
-- # 2.分表
-- # 3.分库
-- # 4.读写分离
-- # 5.主从复制
-- # 6.分区
-- # 7.垂直拆分
-- # 8.水平拆分
-- # 9.缓存

-- # 组合索引
-- # 1.最左匹配原则
-- # 2.索引列不能参与计算,否则索引失效
-- # 3.尽量选择区分度高的列作为索引列
-- # 4.索引列尽量选择短的列
select * from user;
create index id_nickname on user(id,user_nickname);
show indexes from user;
# drop index id_nickname on user;
explain select * from user where id = 3 and user_nickname = '团团';   -- 符合最左匹配原则，可以用索引
explain select * from user where user_nickname = '团团' and id = 3; -- 符合最左匹配原则，可以用索引
explain select * from user where user_nickname = '团团';  -- 不符合最左匹配原则，不能用索引
-- # 最左匹配原则意思是，索引列从左到右，如果索引列不是连续的，那么中间的列不能用索引
explain select * from user where id = 3; -- 符合最左匹配原则，可以用索引
explain select * from user where id > 1;
explain select * from user order by id,user_nickname; # 没有走索引
explain select id from user order by id,user_nickname; # 没有走索引
explain select id from user order by id,user_nickname; # 走索引

-- # 聚簇索引
-- # 1.数据和索引在一起
-- # 2.只能有一个
-- # 3.叶子节点存储的是数据，有序的

# 一、 MySQL索引失效的九种情况
# 1。不符合最左前缀原则
explain select * from t1 where a=1 and b=1;  -- 没有最左索引c 不能用索引
# 2。不正确使用Like
explain select * from t1 where a like '%1';
# 3。对索引列进行了计算或使用了函数
explain select * from t1 where a+1=1;
# 4. 索引列进行了类型转换
explain select * from t1 where a=1;     -- a是varchar类型，索引失效
explain select * from t1 where a=’1’;   -- a是varchar类型，索引生效
# 5. 使用了不等于<>
explain select * from t1 where a<>1;
# 6. 使用了order by
explain select * from t1 where a=1 order by b，c，d; -- b，c，d是索引列，但是还不如全表扫描，所以索引失效
# 7. 使用了or
explain select * from t1 where a=1 or b=1; -- a，b是索引列，但是还不如全表扫描，所以索引失效
# 8. 使用了select *
explain select * from t1 where a=1;
# 9. 范围查询数据量过多导致索引失效
explain select * from t1 where a>1; -- a是索引列，但是还不如全表扫描，所以索引失效



