package com.interview.often;


import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

//模拟一串整数的接收，考虑乱序、丢包的情况
public class IntegerSendReceiver {
    private static final int NUM = 100; //要接收的整数个数
    private static final Random random = new Random(); //随机数生成器
    private static final BlockingQueue<Integer> queue = new LinkedBlockingQueue<>(); //接收到的整数队列



    public static void main(String[] args) {
        //接收线程
        new Thread(() -> {
            int count = 0;
            while (count < NUM) {
                try {
                    Integer num = receive();
                    if (num != null) {
                        System.out.println("接收到"+num);
                        count++;  //确保接收到所有的整数
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        //发送线程
        new Thread(() -> {
            for (int i = 0; i < NUM; i++) {
                send(i);
            }
        }).start();

    }

    private static void send(int i) {
        try {
            queue.put(i);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static Integer receive() throws InterruptedException {
        Integer num = queue.take();
        if(random.nextBoolean()){
            queue.put(num);
            System.out.println("随机丢弃掉 = " + num+"，重新接收");
            return null;
        }else {
            return num;
        }

    }
}
