package com.interview.concurrent;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SychronizedAndReetrantLock {
//    SychronizedAndReetrantLock的区别
//    1.synchronized是Java的类，自动加锁与释放锁，JVM(C++)层面的锁，非公平锁，锁的是对象，锁信息保存在对象头中，底层有锁升级过程
//    2.ReetrantLock是JDK的类，需要手动加锁与释放锁，API层面的锁，公平锁或非公平锁，int state保存锁的状态，底层使用CAS操作，无锁升级过程
//    CAS操作：Compare And Swap，比较并交换，是一种无锁算法，底层使用Unsafe类实现，Unsafe类是JDK的类，可以直接操作内存，可以实现原子操作

    public static void main(String[] args) {
        SynchronizedExample synchronizedExample = new SynchronizedExample();
        ReentrantLockExample reentrantLockExample = new ReentrantLockExample();
        for (int i = 0; i < 1000; i++) {
            new Thread(() -> {
                synchronizedExample.add(1);
                reentrantLockExample.add(1);
            }).start();
        }

//        非公平锁：不保证线程获取锁的顺序，有可能导致某些线程一直拿不到锁
//        公平锁：保证线程获取锁的顺序，但是性能较差
        System.out.println("synchronizedExample.get() = " + synchronizedExample.get());
        System.out.println("reentrantLockExample.get() = " + reentrantLockExample.get());

        try {
            Thread.sleep(1000); //等待所有线程执行完毕
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("synchronizedExample.get() = " + synchronizedExample.get());
        System.out.println("reentrantLockExample.get() = " + reentrantLockExample.get());
    }

}

class SynchronizedExample {
    private int count = 0;

    public synchronized void add(int n) {
        count += n;
    }
    public synchronized int get() {
        return count;
    }
}

class ReentrantLockExample {
    private int count = 0;
    private Lock lock = new ReentrantLock();

    public void add(int n) {
        lock.lock();
        try {
            count += n;
        } finally {
            lock.unlock();
        }
    }
    public int get() {
        lock.lock();
        try {
            return count;
        } finally {
            lock.unlock();
        }
    }
}