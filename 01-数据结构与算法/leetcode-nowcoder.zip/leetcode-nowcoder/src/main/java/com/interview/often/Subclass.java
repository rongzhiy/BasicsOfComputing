package com.interview.often;

// 集成常见面试题
public class Subclass extends Superclass {
    public Subclass() {
        super(1);
    }

    public static void main(String[] args) {
        // 1.子类继承父类，子类的构造方法中默认会调用父类的无参构造方法
        // 2.如果父类没有无参构造方法，子类的构造方法必须显示调用父类的有参构造方法
        // 3.如果父类没有无参构造方法，子类的构造方法没有显示调用父类的有参构造方法，编译报错
        // 4.如果父类没有无参构造方法，子类的构造方法显示调用父类的有参构造方法，编译通过
        // 5.如果父类没有无参构造方法，子类的构造方法显示调用父类的有参构造方法，父类的有参构造方法中调用了父类的无参构造方法，编译报错
        // 6.如果父类没有无参构造方法，子类的构造方法显示调用父类的有参构造方法，父类的有参构造方法中调用了父类的有参构造方法，编译通过
        // 7.如果父类没有无参构造方法，子类的构造方法显示调用父类的有参构造方法，父类的有参构造方法中调用了父类的有参构造方法，父类的有参构造方法中调用了父类的无参构造方法，编译报错


        Subclass sub = new Subclass();

    }
}

class Superclass{

    public Superclass(int a) {
        System.out.println("Superclass");
    }

}
