package com.interview.concurrent;

import java.util.concurrent.*;

public class ThreadTest {
//    创建线程的方式
//    1.继承Thread类
//    2.实现Runnable接口
//    3.实现Callable接口
//    4.使用线程池

    public static void main(String[] args) {
//        1. 继承Thread类
        Thread thread = new Thread() {
            @Override
            public void run() {
                System.out.println("Thread");
            }
        };
        thread.start();
//        总结：继承Thread类的方式，线程类只能继承一个父类，所以有局限性，不推荐使用

//        2. 实现Runnable接口
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                System.out.println("Runnable");
            }
        };
        Thread thread1 = new Thread(runnable);
        thread1.start();
//        总结：实现Runnable接口的方式，线程类可以继承其他父类，不受局限，推荐使用

//        3. 实现Callable接口
        FutureTask<String> futureTask = new FutureTask<>(new Callable<String>() {
            @Override
            public String call() throws Exception {
                System.out.println("Callable success");
                return "success";
            }
        });
        Thread thread2 = new Thread(futureTask);
        thread2.start();
//        总结：实现Callable接口的方式，可以获取线程执行的结果，不推荐使用


//        使用线程池
//        1.创建线程池
//        2.提交任务
//        3.关闭线程池
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                System.out.println("ThreadPoolExecutor");
            }
        });
        executorService.shutdown();
//        为什么不建议使用Executors创建线程池？   Executors创建的线程池有缺点:
//        1. FixedThreadPool和SingleThreadPool:
//        允许的请求队列长度为Integer.MAX_VALUE，可能会堆积大量的请求，从而导致OOM。
//        2. CachedThreadPool和ScheduledThreadPool:
//        允许的创建线程数量为Integer.MAX_VALUE，可能会创建大量的线程，从而导致OOM。
//        总结：使用Executors创建线程池的方式，不推荐使用


        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(5, 10, 60, java.util.concurrent.TimeUnit.SECONDS, new java.util.concurrent.LinkedBlockingQueue<>());
        for (int i = 0; i < 1; i++) {
            threadPoolExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    System.out.println(Thread.currentThread().getName() + " is running");
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            System.out.println("线程池中线程数目：" + threadPoolExecutor.getPoolSize() + "，队列中等待执行的任务数目：" + threadPoolExecutor.getQueue().size() + "，已执行完的任务数目：" + threadPoolExecutor.getCompletedTaskCount());
        }
//        总结：使用线程池的方式，可以灵活的配置线程池的大小，推荐使用
    }

}

class CallableTest implements Callable<String> {
    @Override
    public String call() throws Exception {
        return "Callable";
    }
}
