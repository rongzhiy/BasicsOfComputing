package com.interview.concurrent;

public class ThreadStatus {
//    线程的状态
//    1.新建状态 new
//    2.就绪状态    ready
//    3.运行状态    running
//    4.阻塞状态    blocked
//    5.死亡状态    dead
    public static void main(String[] args) {
        Thread thread = new Thread(() -> {
            System.out.println("thread is running");
        });
        System.out.println("new thread status: " + thread.getState());
        thread.start();
        System.out.println("after start thread status: " + thread.getState());
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("after 1s thread status: " + thread.getState());
    }
}
