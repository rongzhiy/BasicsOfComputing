package com.interview.often;

public class 两线程打印奇偶 {
    public static void main(String[] args) {
//        两线程依次打印奇偶
        final Object lock = new Object();
        Thread t1 = new Thread(new Runnable() {
            int i = 1;
            @Override
            public void run() {
                while (i <= 100) {
                    synchronized (lock) {
                        System.out.println("奇数线程打印：" + i);
                        i += 2;
                        lock.notify();
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

        Thread t2 = new Thread(new Runnable() {
            int i = 2;
            @Override
            public void run() {
                while (i <= 100) {
                    synchronized (lock) {
                        System.out.println("偶数线程打印：" + i);
                        i += 2;
                        lock.notify();
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

        t1.start();
        t2.start();

    }

}
