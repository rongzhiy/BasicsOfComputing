
package com.interview.often;

//java String 常见笔试题

import lombok.val;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StringTest {
    public static void main(String[] args) throws ParseException {
        String s1="abc";
        String s2="abc";
        String s3=new String("abc");
        String s4="a"+"b"+"c";
        String s5="ab";
        String s6=s5+"c";

        /**
         * 该题考查的是对java常量池的理解，先在常量池中创建一个"abc",s1的引用指向它；
         * 创建s2时，由于常量池中已经存在”abc“，只需指向s2就可以，而不需要再创建。
         * ==在这里比较的是对象引用，故结果为true
         * 因为String重写了equals方法，所以比较的字符串的内容
         */
        System.out.println(s1==s2); //true
        System.out.println(s1.equals(s2));  //true

        System.out.println("------------------------------------------------------");

        /**
         * s3是在堆内存开辟了一块空间，把引用赋给了s3；s1的引用是指向常量池中的"abc"
         * 所以 s1==s3 为 false
         */
        System.out.println(s1==s3); //false
        System.out.println(s1.equals(s3));  //true  String重写了equals方法，所以比较的字符串的内容

        System.out.println("------------------------------------------------------");

        /**
         * 本题主要考察java中常量优化机制，编译时s1已经成为“abc”在常量池中查找创建，s2不需要再创建
         */
        System.out.println(s1==s4); //true
        System.out.println(s1.equals(s4));  //true

        System.out.println("------------------------------------------------------");

        /**
         * Java 语言提供对字符串串联符号（”+”）和其他对象到字符串的转换的特殊支持。字符串串联是通过 StringBuilder
         * （或 StringBuffer）类及其 append 方法实现的，字符串转换是通过 toString 方法实现的。
         *
         * 也就是说当执行 s6=s5+c 的时候，首先在堆中生成一个StringBuilder（或StringBuffer）对象，然后把 ab 和 c 连接在一起 ，
         * 再利用 toString 方法生成一个 “abc”的字符串 再来进行比较..s1 的 “abc” 在常量池中，s6 在堆中所以为false
         */
        System.out.println(s1==s6); //false
        System.out.println(s1.equals(s6));  //true

        //        将字符串转化为整数
        System.out.println(Integer.parseInt("123"));

        //        将整数转化为字符串
        System.out.println(String.valueOf(123));

        //        将字符串转化为字符数组
        char[] chars = "123".toCharArray();
        for (char aChar : chars) {
            System.out.println(aChar);
        }

        //        将字符数组转化为字符串
        String s = new String(chars);
        System.out.println(s);

        //将字符串转化为时间
        String str="Sep17,2013";
        Date date=new SimpleDateFormat("MMMMd,yy", Locale.ENGLISH).parse(str);
        System.out.println(date);


    }


}

