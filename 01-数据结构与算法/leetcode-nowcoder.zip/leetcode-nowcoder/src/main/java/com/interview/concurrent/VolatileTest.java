package com.interview.concurrent;

public class VolatileTest {
//    可见性
//    volatile关键字的作用是使变量在多个线程间可见
//    volatile的例子程序
//    1.变量i是volatile的，线程A对i的修改对线程B可见
//    2.变量i是非volatile的，线程A对i的修改对线程B不可见
    public static volatile int i = 0;
    public static void main(String[] args) throws InterruptedException {
        new Thread(() -> {
            while (i == 0) {
                System.out.println("i == 0");
            }
        }).start();
        Thread.sleep(1000);
        i = 1;
    }

}
