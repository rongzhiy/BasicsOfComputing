package com.interview.concurrent;

public class ThreadInterrupt {
//    线程如何优雅的停止
//    1.使用退出标志，使线程正常退出，也就是当run方法完成后线程终止。
//    2.使用stop方法强行终止线程（不推荐使用）
//    3.使用interrupt方法中断线程
    public static void main(String[] args) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!Thread.currentThread().isInterrupted()) {
                    System.out.println(Thread.currentThread() + "hello");
                }
            }
        });
        t.start();  // 启动子线程
        try {
            Thread.sleep(1000);     // 主线程休眠1s
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("main thread interrupt thread");
        t.interrupt();      // 中断子线程
        try {               // 主线程休眠1s
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("main thread is over");
    }

}
