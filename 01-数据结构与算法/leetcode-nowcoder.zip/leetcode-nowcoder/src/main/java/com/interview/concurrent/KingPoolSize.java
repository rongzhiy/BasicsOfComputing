package com.interview.concurrent;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class KingPoolSize {
    public static void main(String[] args) {
//        corePoolSize：核心线程数，线程池中一直存在的线程数量
//        maximumPoolSize：最大线程数，线程池中最多能创建的线程数量
//        对于CPU密集型任务，线程池大小设置为CPU核心数+1，因为CPU密集型任务并不是一直在执行任务，有可能在执行任务的时候发生阻塞，所以需要多配置一个线程
//        对于IO密集型任务，线程池大小设置为2*CPU核数，因为IO密集型任务线程并不是一直在执行任务，而是在等待数据，所以需要多配置一些线程
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(5, 10, 60, TimeUnit.SECONDS, new LinkedBlockingQueue<>());
        for (int i = 0; i < 16; i++) {
            threadPoolExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    System.out.println(Thread.currentThread().getName() + " is running");
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            System.out.println("线程池中线程数目：" + threadPoolExecutor.getPoolSize() + "，队列中等待执行的任务数目：" + threadPoolExecutor.getQueue().size() + "，已执行完的任务数目：" + threadPoolExecutor.getCompletedTaskCount());
        }
    }

}
