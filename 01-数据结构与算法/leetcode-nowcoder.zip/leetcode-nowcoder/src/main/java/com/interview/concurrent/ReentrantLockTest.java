package com.interview.concurrent;

public class ReentrantLockTest {
//    ReentrantLock的实现公平锁和非公平锁的区别？
//    公平锁：线程获取锁的顺序是按照线程加锁的顺序来分配的，即先来先得的FIFO先进先出顺序。
//    非公平锁：线程获取锁的顺序是抢占式的，是随机获取的。
//    公平锁的优点是等待锁的线程不会饿死，缺点是整体吞吐效率相对非公平锁要低，等待队列中除了第一个线程以外，其他线程都会阻塞，CPU唤醒阻塞线程的开销比较大。
// 不管是公平锁还是非公平锁，一旦没竞争到锁，都会进行排队，当锁释放时，都是唤醒排在最前面的线程，所以非公平锁只是体现在了线程加锁阶段，而没有体现在线程唤醒阶段。
//    ReentrantLock是可重入锁，不管非公平锁还是公平锁都是可重入的。

//    ReentrantLock的实现原理？
//    ReentrantLock是基于AQS实现的，AQS是一个FIFO的双向队列，用来存储等待获取锁的线程，AQS中有两个volatile变量，state和Node，state表示锁的状态，Node表示等待队列中的线程。
//    ReentrantLock的lock()方法会调用AQS的acquire()方法，acquire()方法会调用tryAcquire()方法，tryAcquire()方法会尝试获取锁，如果获取成功则返回true，如果获取失败则返回false。
//    如果获取失败则会调用addWaiter()方法，addWaiter()方法会将当前线程封装成Node并加入到等待队列中，然后会调用acquireQueued()方法，acquireQueued()方法会使线程阻塞，直到获取到锁。
//    如果获取成功则会调用setExclusiveOwnerThread()方法，setExclusiveOwnerThread()方法会将当前线程设置为独占线程，然后会调用tryAcquire()方法，tryAcquire()方法会将state加1，表示获取到了锁。

    public static void main(String[] args) {
        ReentrantLockExample reentrantLockExample = new ReentrantLockExample();
        for (int i = 0; i < 100; i++) {
            new Thread(() -> {
                reentrantLockExample.add(1);
            }).start();
        }
        System.out.println("reentrantLockExample.get() = " + reentrantLockExample.get());

        try {
            Thread.sleep(1000); //等待所有线程执行完毕
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("reentrantLockExample.get() = " + reentrantLockExample.get());

    }


}
