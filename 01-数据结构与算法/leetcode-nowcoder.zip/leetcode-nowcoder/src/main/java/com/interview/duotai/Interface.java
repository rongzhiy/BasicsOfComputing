package com.interview.duotai;

public interface Interface {
    public int a();

    public int a(int b);

    public static void main(String[] args) {

        System.out.println("args = " + args);
    }

    default void test() {
        System.out.println("test");
    }

    static void test2() {
        System.out.println("test2");
    }



}
