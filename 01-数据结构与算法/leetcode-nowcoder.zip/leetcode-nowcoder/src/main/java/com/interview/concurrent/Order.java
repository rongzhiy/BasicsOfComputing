package com.interview.concurrent;

public class Order {
// 有序性
//    new Person()的执行过程
//    1.分配内存空间
//    2.初始化对象
//    3.将内存空间的地址赋值给对应的引用
//    但是由于java编译器允许处理器乱序执行。
//    1.分配内存空间
//    2.将内存空间的地址赋值给对应的引用
//    3.初始化对象

    public static void main(String[] args) {
        Person person = new Person();
    }
}

class Person {
    static Person instance;

    static Person getInstance() {
        if (instance == null) {
            synchronized (Person.class) {
                if (instance == null) {
                    instance = new Person();    //可能会发生指令重排
                }
            }
        }
        return instance;    //第一个对象有可能还没初始化完就返回了
    }

}