package com.interview.plugintest;

import lombok.Data;

@Data
public class MyPlugin {
    private  Integer id;
    private  String name;
    private  String age;
    public static void main(String[] args) {
        MyPlugin myPlugin = new MyPlugin();
        myPlugin.setId(0);
        myPlugin.setName("");
        myPlugin.setAge("");
        System.out.println("myPlugin = " + myPlugin);

    }
}
