package com.interview.duotai;

public class A {
    public int a() {
        return 1;
    }


}

class B extends A {

    public int a(int b) {
        return b;
    }

    public static void main(String[] args) {
        A a = new B();
        System.out.println(a.a());
    }
}

