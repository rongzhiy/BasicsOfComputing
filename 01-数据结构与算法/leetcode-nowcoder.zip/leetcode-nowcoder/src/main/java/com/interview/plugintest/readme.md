# 1、Lombok
@Data @Getter @Setter @ToString @EqualsAndHashCode @NoArgsConstructor @AllArgsConstructor @RequiredArgsConstructor @Value @Builder @SneakyThrows @Synchronized @Getter(lazy=true) @Log @Log4j @Log4j2 @Slf4j @XSlf4j @CommonsLog @JBossLog @Flogger @CustomLog

# 2、GenerateAllSetter
@GenerateAllSetter @GenerateNullSetters @GenerateBuilder @GenerateDefaultConstructor @GenerateCopyConstructor @GenerateConstructor @GenerateToString @GenerateEqualsAndHashCode 

Alt + Enter

# 3、GsonFormat
根据json格式生成对应的实体类

Alt +S

# 4、Free Mybatis plugin
针对Mybatis的xml文件，可以在xml文件中直接跳转到对应的mapper接口

# 5、mybatisGenerator
根据数据库表生成对应的实体类、mapper接口、mapper.xml文件

# 6、RestFulTool
快速找到相应接口，可以直接在接口上进行测试
Ctrl+Alt+/

# 7 、Sequence Diagram
根据代码生成对应的时序图

# 8、HTTP Client
可以直接在IDEA中进行接口测试

# 9、Github copilot
根据代码提示生成代码

# 10、MybatisX
可以直接在mapper.xml文件中跳转到对应的mapper接口

# 11、NexChatGPT
根据代码提示生成代码

# 12、CodeGlance
在右侧显示代码的缩略图

# 13、Alibaba Java Coding Guidelines
阿里巴巴代码规范

