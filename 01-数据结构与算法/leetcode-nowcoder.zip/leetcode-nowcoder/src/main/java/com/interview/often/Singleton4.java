package com.interview.often;

class Singleton1 {
    //    懒汉式，我们使用了双重检查锁定机制，即先检查实例是否已经创建，
//    如果没有则进入同步块进行创建，然后再返回实例对象。这种方式可以有效地减少线程安全问题和提高性能。
    private static volatile Singleton1 instance;

    public Singleton1() {
    }

    public static Singleton1 getInstance() {
        if (instance == null) {
            synchronized (Singleton4.class) {
                if (instance == null) {
                    instance = new Singleton1();  //双重检查锁定机制 //volatile 保证可见性 有序性   但是不保证原子性

                }
            }
        }
        return instance;
    }
}


class Singleton2 {
    //    饿汉式，在类加载时就创建了单例对象并赋值给静态变量，所以不存在线程安全问题。
//    但是这种方式不管我们用不用都会进行实例化，会造成内存的浪费。
    private static Singleton2 instance = new Singleton2();

    public Singleton2() {
    }

    public static Singleton2 getInstance() {
        return instance;
    }
}


class Singleton3 {
    //    静态内部类，这种方式同样利用了类加载机制来保证只创建一个单例对象。
//    当第一次加载Singleton类时并不会初始化sInstance，
    private static class SingletonHolder {
        private static final Singleton3 INSTANCE = new Singleton3();
    }

    public Singleton3() {
    }

    public static final Singleton3 getInstance() {
        return SingletonHolder.INSTANCE;
    }
}


//    枚举，这种方式是Effective Java作者Josh Bloch提倡的方式，
//    它不仅能避免多线程同步问题，而且还能防止反序列化重新创建新的对象。
//    但是，这种方式不太好的地方就是不太好理解。
enum Singleton4 {
    INSTANCE;

    public void whateverMethod(String doSomething) {
        System.out.println("doSomething = " + doSomething);
    }
}


