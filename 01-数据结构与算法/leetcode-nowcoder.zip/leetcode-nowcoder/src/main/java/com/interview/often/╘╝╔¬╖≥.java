package com.interview.often;

public class 约瑟夫 {
    public static void main(String[] args) {
        int n = 10;  // 5个人
        int m = 3;  // 数到3的人出局
        System.out.println("最后留下的是第" + ysf(n, m) + "个");
    }

//    本题的约瑟夫环问题的公式为：f(n,k) = (f(n-1,k) + k) mod n
    public static int ysf(int n, int m) {
        int res = 0;
        for (int i = 2; i <= n; i++) {
            res = (res + m) % i;
        }
        return res ;
    }

}
