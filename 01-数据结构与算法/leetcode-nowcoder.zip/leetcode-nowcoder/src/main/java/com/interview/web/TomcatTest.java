package com.interview.web;

public class TomcatTest {
//    Tomcat为什么需要自定义类加载器?
//    一个Tomcat中可以部署多个应用，而每个应用中都存在很多类，并且各个应用中的类是独立
//    的，全类名是可以相同的，比如一个订单系统中可能存在com.zhouyu.User类，一个库存系统中
//    可能也存在com.zhouyu.User类，一个Tomcat，不管内部部署了多少应用，Tomcat启动之后就
//    是一个Java进程，也就是一个JVM，所以如果Tomcat中只存在一个类加载器，比如默认的
//    AppClassLoader，那么就只能加载一个com.zhouyu.User类，这是有问题的，而在Tomcat中
//    会为部署的每个应用都生成一个类加载器实例，名字叫做WebAppClassLoader，这样Tomcat中
//    每个应用就可以使用自己的类加载器去加载自己的类，从而达到应用之间的类隔离，不出现冲
//    突。另外Tomcat还利用自定义加载器实现了热加载功能。

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
