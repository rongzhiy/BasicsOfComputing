package com.interview.duotai;

import java.io.InputStream;

public class Input {
    public static void main(String[] args) {
        new InputStream() {
            @Override
            public int read() {
                System.out.println("args = " + args);
                return 0;
            }
        };

        float i = 1.0F; //浮点型
        double j = 1.0; //双精度浮点型
        long k = 1L; //长整型
        int l = 1; //整型
        short m = 1; //短整型
        byte n = 1; //字节型
        char o = '1'; //字符型
        boolean p = true; //布尔型

        System.out.println(i == j);

//        S=“abcdabcd”，则next数组值为


    }
}
