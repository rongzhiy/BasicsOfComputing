package com.interview.concurrent;

public class ThreadLocalTest {
//    ThreadLocal有那些应用场景？底层如何实现？
//    应用场景： Threadlocal是Java中所提供的线程本地存储机制，可以利用该机制将数据缓存在某个线程内部，该线程可以在任意时间、任意方法中获取缓存的数据，而无需以参数的形式来回传递。
//    1.每个线程需要一个独享的对象（通常是工具类，典型的是SimpleDateFormat）
//    2.每个线程内需要保存全局变量（例如在拦截器中获取用户信息，然后存储到ThreadLocal中，随后在Controller或Service中获取）

//    底层实现
//    1.每个Thread维护一个ThreadLocalMap，这个Map的key是ThreadLocal实例本身，value是真正需要存储的Object。
//    2.在ThreadLocal的get()方法中，首先获取当前线程Thread t = Thread.currentThread();，然后以ThreadLocal实例为key，到ThreadLocalMap中查找value。
//    3.在ThreadLocal的set()方法中，首先获取当前线程Thread t = Thread.currentThread();，然后以ThreadLocal实例为key，将value存储到ThreadLocalMap中。

    public static void main(String[] args) {
        ThreadLocal<String> threadLocal = new ThreadLocal<>();
        threadLocal.set("hello");
        System.out.println(threadLocal.get());
        threadLocal.remove();  // 一般不需要调用，因为ThreadLocalMap的key是弱引用，当ThreadLocal实例被回收后，key会被自动清除。
        System.out.println(threadLocal.get());
    }
}
