package com.xiaomi;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

//输入：1:10,2:12,3:10
//输出：13
public class Main1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String tasks = sc.nextLine();
        int result = calculate(tasks);
        System.out.println(result);
    }

    private static int calculate(String tasks) {
        Map<Integer,Integer> powerMap = new TreeMap<>();
        int totalPower = 0;
        String[] taskArr = tasks.split(",");

        for (String task : taskArr) {
            String[] taskInfo = task.split(":");
            int power = Integer.parseInt(taskInfo[1]);
            int time = Integer.parseInt(taskInfo[0]);
            powerMap.put(time,power);
            totalPower += power;
        }
        if(totalPower > 4800) return -1;

        int minitialPower = 0;
        for (int power : powerMap.values()) {
            int minPower = powerMap.get(power);
            minitialPower  = Math.max(minitialPower,minPower);

        }
        return minitialPower;
    }



}
