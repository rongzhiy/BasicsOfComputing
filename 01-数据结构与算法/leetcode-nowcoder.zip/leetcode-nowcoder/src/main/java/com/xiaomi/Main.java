package com.xiaomi;

////样例输入
//// 2800
//// 1950:10,2000:15,3000:9
//// 样品输出
//// 9.0

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {

    public static void main(String[] args) {
        //样例输入
// 2800
// 1950:10,2000:15,3000:9
// 样品输出
// 9.0
        Scanner sc = new Scanner(System.in);
        int freq = sc.nextInt();
        Map<Integer,Double> freqLossMap = new TreeMap<>();
        String[] data = sc.next().split(",");
        for (String s : data) {
            String[] values = s.split(":");
            int f = Integer.parseInt(values[0]);
            double loss = Double.parseDouble(values[1]);
            freqLossMap.put(f,loss);
        }

        double result = calculateAvgLoss(freq,freqLossMap);
        System.out.println(result);

    }

    private static double calculateAvgLoss(int freq, Map<Integer, Double> freqLossMap) {
        double nearestLoss = findNearestLoss(freq,freqLossMap);
        if (freqLossMap.containsKey(freq)) {
            double avgLoss = (freqLossMap.get(freq) + nearestLoss) / 2.0;
            return Math.round(avgLoss * 10) / 10.0;
        } else {
            return nearestLoss;
        }
    }

    private static double findNearestLoss(int freq, Map<Integer, Double> freqLossMap) {
        int nearestFreq = freqLossMap.keySet().stream().filter(f -> f < freq).max(Integer::compareTo).orElse(0);
        if (nearestFreq == freq){
            return freqLossMap.get(freq);
        }else if(nearestFreq == 0){
            return freqLossMap.get(freqLossMap.keySet().stream().filter(f -> f > freq).min(Integer::compareTo).orElse(0));
        }else {
            int nextFreq = freqLossMap.keySet().stream().filter(f -> f > freq).min(Integer::compareTo).orElse(0);
            if (nextFreq == 0){
                return freqLossMap.get(nearestFreq);
            }else{
                int diff1 = freq - nearestFreq;
                int diff2 = nextFreq - freq;
                if (diff1 < diff2){
                    return freqLossMap.get(nearestFreq);
                }else if(diff1 > diff2){
                    return freqLossMap.get(nextFreq);
                }
            }
            return freqLossMap.get(nearestFreq);
        }
    }

}
