package com.kuaishou;

public class ReserveMiddle {
    public static ListNode reverseMiddle(ListNode head, int m) {


        return head;
    }

}


class ListNode {
    int val;
    ListNode next;
    ListNode(int x) { val = x; }
}

