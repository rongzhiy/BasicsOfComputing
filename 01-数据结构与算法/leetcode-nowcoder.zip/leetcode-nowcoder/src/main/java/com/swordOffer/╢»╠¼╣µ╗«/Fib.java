package com.swordOffer.动态规划;

public class Fib {
//   剑指 Offer 10- I. 斐波那契数列
    public static void main(String[] args) {
        int n = 20;
        System.out.println("fib(n) = " + fib(n));
        System.out.println("fib1(n) = " + fib1(n));

    }

    // 暴力递归 时间复杂度O(2^n) 空间复杂度O(n)
    static int fib1(int N) {
        if (N == 1 || N == 2) return 1;
        return fib(N - 1) + fib(N - 2);
    }

//    动态规划  自底向上  备忘录 时间复杂度O(n) 空间复杂度O(n)
    int fib2(int N) {
        if (N == 0) return 0;
        int[] dp = new int[N + 1];
        // base case
        dp[0] = 0; dp[1] = 1;
        // 状态转移
        for (int i = 2; i <= N; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }

        return dp[N];
    }

//    动态规划  自底向上  状态压缩 时间复杂度O(n) 空间复杂度O(1)
    int fib3(int n) {
        if (n == 0 || n == 1) {
            // base case
            return n;
        }
        // 分别代表 dp[i - 1] 和 dp[i - 2]
        int dp_i_1 = 1, dp_i_2 = 0;
        for (int i = 2; i <= n; i++) {
            // dp[i] = dp[i - 1] + dp[i - 2];
            int dp_i = dp_i_1 + dp_i_2;
            // 滚动更新
            dp_i_2 = dp_i_1;
            dp_i_1 = dp_i;
        }
        return dp_i_1;
    }


//    动态规划  自底向上  状态压缩 时间复杂度O(n) 空间复杂度O(1)
    public static int fib(int n){
        if(n == 0) return 0;
        if(n == 1) return 1;
        int a = 0, b = 1, sum = 0;
        for (int i = 2; i <= n; i++) {
            sum = (a + b) % 1000000007;
            a = b;
            b = sum;
        }
        return sum;
    }

}
