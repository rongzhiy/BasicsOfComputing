package com.swordOffer.tree;

public class MaxDepthTraverse {

//    104. 二叉树的最大深度
    public static void main(String[] args) {
        TreeNode root = new TreeNode(3);
        TreeNode left = new TreeNode(9);
        TreeNode right = new TreeNode(20);
        root.left = left;
        root.right = right;

        TreeNode left1 = new TreeNode(15);
        TreeNode right1 = new TreeNode(7);
        right.left = left1;
        right.right = right1;


        System.out.println("maxDepth1(root) = " + maxDepth1(root));
        System.out.println("maxDepth(root) = " + maxDepth(root));
    }


    static int depth = 0;
    static int res = 0;

    public static int maxDepth(TreeNode root) {
        traverse(root);
        return res;
    }

    // 遍历二叉树
    static void traverse(TreeNode root) {
        if (root == null) {
            return;
        }

        // 前序遍历位置
        depth++;
        // 遍历的过程中记录最大深度
        res = Math.max(res, depth);
        traverse(root.left);
        traverse(root.right);
        // 后序遍历位置
        depth--;
    }

    // 定义：输入根节点，返回这棵二叉树的最大深度
    static int maxDepth1(TreeNode root) {
        if (root == null) {
            return 0;
        }
        // 利用定义，计算左右子树的最大深度
        int leftMax = maxDepth(root.left);
        int rightMax = maxDepth(root.right);
        // 整棵树的最大深度等于左右子树的最大深度取最大值，
        // 然后再加上根节点自己
        int res = Math.max(leftMax, rightMax) + 1;

        return res;
    }

}
