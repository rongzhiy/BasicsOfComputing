package com.swordOffer.链表;

public class ReserveN {
    public static void main(String[] args) {
        ListNode head = new ListNode(1);
        ListNode node1 = new ListNode(2);

        head.next = node1;

        ListNode res = reverseN(head, 2);
        res.forEach();
    }

    // 92. 反转链表 II
    // https://leetcode-cn.com/problems/reverse-linked-list-ii/
    public static ListNode reverseN(ListNode head, int n) {
        if (head == null || head.next == null) {
            return head;
        }

        ListNode pre = null;
        ListNode cur = head;
        ListNode temp = null;

        while (cur != null && n > 0) {   // 遍历链表
            temp = cur.next;  // 保存当前节点的下一个节点
            cur.next = pre;   // 当前节点指向前一个节点
            pre = cur;        // 前一个节点后移
            cur = temp;       // 当前节点后移
            n--;
        }

        head.next = cur;
        return pre;
    }


    // 递归反转链表前N个节点  法二
// https://labuladong.gitee.io/algo/images/%E5%8F%8D%E8%BD%AC%E9%93%BE%E8%A1%A8/7.jpg
    ListNode successor = null; // 后驱节点

    // 反转以 head 为起点的 n 个节点，返回新的头结点
    ListNode reverseN2(ListNode head, int n) {
        if (n == 1) {
            // 记录第 n + 1 个节点
            successor = head.next;
            return head;
        }
        // 以 head.next 为起点，需要反转前 n - 1 个节点
        ListNode last = reverseN2(head.next, n - 1);

        head.next.next = head;
        // 让反转之后的 head 节点和后面的节点连起来
        head.next = successor;
        return last;
    }

}
