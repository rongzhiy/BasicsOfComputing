package com.swordOffer.dfs;

public class KthSmallest {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(3);
        TreeNode node1 = new TreeNode(1);
        root.left = node1;
        TreeNode node2 = new TreeNode(4);
        root.right = node2;
        TreeNode node3 = new TreeNode(2);
        node1.right = node3;
        int k = 1;
        int res = kthSmallest(root, k);
        System.out.println(res);
    }


    // 230. 二叉搜索树中第K小的元素
    public static int kthSmallest(TreeNode root, int k) {
        traverse1(root, k);
        return res;
    }
    static int res = 0;
    static int rank = 0;

    private static void traverse1(TreeNode root, int k) {
        if (root == null) {
            return;
        }
        traverse1(root.left, k);
        //中序遍历代码位置
        rank++;
        if (k == rank) {
            res = root.val;
            return;
        }
        /*****************/
        traverse1(root.right, k);
    }
}
