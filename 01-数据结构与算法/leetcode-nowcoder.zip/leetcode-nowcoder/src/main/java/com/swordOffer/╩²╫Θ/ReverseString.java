package com.swordOffer.数组;

public class ReverseString {
    public static void main(String[] args) {
        char[] s = {'h', 'e', 'l', 'l', 'o'};

        reverseString(s);
        for (char c : s) {
            System.out.println(c);
        }
    }

    // 344. 反转字符串
    // https://leetcode-cn.com/problems/reverse-string/
    public static void reverseString(char[] s) {
        int left = 0, right = s.length - 1;

        // [left, right]
        while (left < right) {
            // 交换
            char temp = s[left];
            s[left] = s[right];
            s[right] = temp;

            left++;
            right--;
        }
    }
}
