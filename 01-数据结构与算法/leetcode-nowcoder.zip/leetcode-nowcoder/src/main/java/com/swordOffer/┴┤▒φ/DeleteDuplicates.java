package com.swordOffer.链表;

public class DeleteDuplicates {
//    删除排序链表中的重复元素
//    https://leetcode-cn.com/problems/remove-duplicates-from-sorted-list/
    public static void main(String[] args) {
        ListNode head = new ListNode(4);
        ListNode node1 = new ListNode(5);
        ListNode node2 = new ListNode(1);
        ListNode node3 = new ListNode(9);

        head.next = node1;
        node1.next = node2;
        node2.next = node3;
        node3.next = node1;

        ListNode res1 = deleteDuplicates(head);
        res1.forEach();
    }

    public static ListNode deleteDuplicates(ListNode head) {
        if(head == null){
            return null;
        }

        ListNode slow = head;
        ListNode fast = head.next;

        while(fast != null){
            if(slow.val != fast.val){
                slow.next = fast;
                slow = slow.next;
            }
            fast = fast.next;
        }

        // 断开与后面重复元素的连接
        slow.next = null;

        return head;
    }
}
