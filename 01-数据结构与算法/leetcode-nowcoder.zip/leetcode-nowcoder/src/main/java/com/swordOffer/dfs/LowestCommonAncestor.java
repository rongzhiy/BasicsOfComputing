package com.swordOffer.dfs;

public class LowestCommonAncestor {
    public static void main(String[] args) {
        //测试用例
        TreeNode root = new TreeNode(6);
        TreeNode node1 = new TreeNode(2);
        TreeNode node2 = new TreeNode(8);
        root.left = node1;
        root.right = node2;
        TreeNode node3 = new TreeNode(0);
        TreeNode node4 = new TreeNode(4);
        node1.left = node3;
        node1.right = node4;
        TreeNode node5 = new TreeNode(7);
        TreeNode node6 = new TreeNode(9);
        node2.left = node5;
        node2.right = node6;
        TreeNode node7 = new TreeNode(3);
        TreeNode node8 = new TreeNode(5);
        node4.left = node7;
        node4.right = node8;
        TreeNode res = lowestCommonAncestor(root, node1, node2);
        System.out.println("res = " + res.val);
    }

    // 剑指 Offer 68 - I. 二叉搜索树的最近公共祖先
    // 最近公共祖先的定义： 设节点 rootrootroot 为节点 p,qp,qp,q 的某公共祖先，若其左子节点 root.leftroot.leftroot.left 和右子节点 root.rightroot.rightroot.right 都不是 p,qp,qp,q 的公共祖先，则称 rootrootroot 是 “最近的公共祖先” 。
    // 二叉搜索树
    public static TreeNode lowestCommonAncestor(TreeNode root, TreeNode p, TreeNode q) {
        while(root != null) {
            if(root.val < p.val && root.val < q.val) // p,q 都在 root 的右子树中
            {
                root = root.right; // 遍历至右子节点
            } else if(root.val > p.val && root.val > q.val) // p,q 都在 root 的左子树中
            {
                root = root.left; // 遍历至左子节点
            } else {
                break;
            }
        }
        return root;
    }

    //剑指 Offer 68 - II. 二叉树的最近公共祖先
    //非二叉搜索树
    public static TreeNode lowestCommonAncestor2(TreeNode root, TreeNode p, TreeNode q) {
        if(root == null || root == p || root == q) { //递归终止条件
            return root;
        }
        TreeNode left = lowestCommonAncestor2(root.left, p, q); //递归左子树
        TreeNode right = lowestCommonAncestor2(root.right, p, q); //递归右子树
        if(left == null && right == null) { //说明左右子树都不包含p,q
            return null;
        }
        if(left == null) { //说明p,q都在右子树
            return right;
        }
        if(right == null) { //说明p,q都在左子树
            return left;
        }
        return root; //说明p,q分别在左右子树
    }

}
