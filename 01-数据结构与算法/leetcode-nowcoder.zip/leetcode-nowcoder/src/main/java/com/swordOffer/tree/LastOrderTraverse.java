package com.swordOffer.tree;

public class LastOrderTraverse {
//    后序遍历
    public static void main(String[] args) {
        TreeNode root = new TreeNode(3);
        TreeNode left = new TreeNode(9);
        TreeNode right = new TreeNode(20);
        root.left = left;
        root.right = right;

        TreeNode left1 = new TreeNode(15);
        TreeNode right1 = new TreeNode(7);
        right.left = left1;
        right.right = right1;

        lastOrder(root);
    }

    //    递归
    public static void lastOrder(TreeNode root) {
        if (root == null) {
            return;
        }
        lastOrder(root.left);
        lastOrder(root.right);
        // 后序遍历位置
        System.out.println("root.val = " + root.val);
    }
}
