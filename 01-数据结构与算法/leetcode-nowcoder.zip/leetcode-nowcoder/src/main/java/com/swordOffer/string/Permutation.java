package com.swordOffer.String;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.nowcoder.TestpermuteUnique.permuteUnique;

public class Permutation {
    public static void main(String[] args) {

    }

    // 剑指 Offer 38. 字符串的排列
    // 回溯算法  「元素可重不可复选」的排列问题
    public String[] permutation(String s) {
        permuteUnique(s.toCharArray());
        String[] arr = new String[res.size()];  // List<String> 转 String[]
        for (int i = 0; i < res.size(); i++) {
            arr[i] = res.get(i);
        }
        return arr;
    }

    List<String> res = new ArrayList<>();   // 结果集
    StringBuilder track = new StringBuilder();  // 路径
    boolean[] used;

    public List<String> permuteUnique(char[] nums) {
        // 先排序，让相同的元素靠在一起
        Arrays.sort(nums);
        used = new boolean[nums.length];    // 记录元素是否使用过
        backtrack(nums);    // 回溯
        return res;
    }

    void backtrack(char[] nums) {
        if (track.length() == nums.length) {
            res.add(track.toString());
            return;
        }

        for (int i = 0; i < nums.length; i++) {
            if (used[i]) {
                continue;
            }
            // 新添加的剪枝逻辑，固定相同的元素在排列中的相对位置
            if (i > 0 && nums[i] == nums[i - 1] && !used[i - 1]) {
                continue;
            }
            track.append(nums[i]);
            used[i] = true;
            backtrack(nums);
            track.deleteCharAt(track.length() - 1);
            used[i] = false;
        }
    }
}
