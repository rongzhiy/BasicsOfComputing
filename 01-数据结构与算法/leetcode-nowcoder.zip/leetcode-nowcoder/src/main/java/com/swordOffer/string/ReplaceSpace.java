package com.swordOffer.String;

public class ReplaceSpace {
    public static void main(String[] args) {
        StringBuffer str = new StringBuffer("We Are Happy");
        String res = replaceSpace(str);
        System.out.println("res = " + res);

        String s = "We Are Happy";
        String ss = replace1(s);
        System.out.println("ss = " + ss);
    }

    // 剑指 Offer 05. 替换空格
    //暴力法
    private static String replaceSpace(StringBuffer str) {
        return str.toString().replaceAll(" ", "%20");
    }

    // 从后往前替换
    public static String replace1(String s){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if(c == ' '){
                sb.append("%20");
            }else{
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
