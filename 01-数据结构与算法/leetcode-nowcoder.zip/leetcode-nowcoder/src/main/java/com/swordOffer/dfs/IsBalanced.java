package com.swordOffer.dfs;

public class IsBalanced {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(3);
        TreeNode node1 = new TreeNode(1);
        TreeNode node2 = new TreeNode(4);
        root.left = node1;
        root.right = node2;
        TreeNode node3 = new TreeNode(2);
        node1.right = node3;

        boolean res = isBalanced(root);
        System.out.println(res);
    }

    // 剑指 Offer 55 - II. 平衡二叉树
    // 自底向上，后序遍历 + 剪枝
    public static boolean isBalanced(TreeNode root) {
        return dfs(root) != -1;
    }

    public static int dfs(TreeNode root) {
        if (root == null) {
            return 0;
        }
        int left = dfs(root.left);
        if (left == -1) {
            return -1;
        }
        int right = dfs(root.right);
        if (right == -1) {
            return -1;
        }
        // 后序遍历代码位置，即在递归的最后一步判断左右子树的高度差是否小于 2
        return Math.abs(left - right) < 2 ? Math.max(left, right) + 1 : -1;
    }


//  递归
    public int maxDepth1(TreeNode root){
        if(root == null){
            return 0;
        }
        int left = maxDepth1(root.left);
        int right = maxDepth1(root.right);
        return Math.max(left,right)+1;

    }
}
