package com.swordOffer.dfs;

public class MirrorTree {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(4);
        TreeNode node1 = new TreeNode(2);
        TreeNode node2 = new TreeNode(7);
        root.left = node1;
        root.right = node2;
        TreeNode node3 = new TreeNode(1);
        TreeNode node4 = new TreeNode(3);
        node1.left = node3;
        node1.right = node4;
        TreeNode node5 = new TreeNode(6);
        TreeNode node6 = new TreeNode(9);
        node2.left = node5;
        node2.right = node6;

        TreeNode res = mirrorTree(root);
        // 前序遍历
        preOrder(res);

    }


    // 剑指 Offer 27. 二叉树的镜像
    public static TreeNode mirrorTree(TreeNode root){
        if(root == null){
            return null;
        }
        // 前序位置
        // 每个节点需要做的事就是交换其左右子节点
        TreeNode temp = root.left;
        root.left = root.right;
        root.right = temp;

        // 遍历框架，去遍历左右子树的节点
        mirrorTree(root.left);
        mirrorTree(root.right);
        return root;
    }


    private static void preOrder(TreeNode res) {  //  前序遍历
        if(res == null){
            return;
        }
        System.out.println("res = " + res.val);
        preOrder(res.left);
        preOrder(res.right);
    }
}
