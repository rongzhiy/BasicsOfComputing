package com.swordOffer.dfs;

public class IsSubStructure {
    public static void main(String[] args) {
        TreeNode A = new TreeNode(3);
        TreeNode A1 = new TreeNode(4);
        TreeNode A2 = new TreeNode(5);
        TreeNode A3 = new TreeNode(1);
        TreeNode A4 = new TreeNode(2);
        TreeNode B = new TreeNode(4);
        TreeNode B1 = new TreeNode(1);
        A.left = A1;
        A.right = A2;
        A1.left = A3;
        A1.right = A4;
        B.left = B1;
        boolean res = isSubStructure(A, B);
        System.out.println("res = " + res);
    }

    //  剑指 Offer 26. 树的子结构：判断 B 是否是 A 的子结构
    //  递归
    public static boolean isSubStructure(TreeNode A, TreeNode B){
        return (A != null && B != null) && (recur(A, B) || isSubStructure(A.left, B) || isSubStructure(A.right, B));    //  A != null && B != null 保证了 A 和 B 都不为空
    }

    private static boolean recur(TreeNode a, TreeNode b) {  //  判断 b 是否是 a 的子结构
        if(b == null){  //  b 为 null，说明 b 已经遍历完，是 a 的子结构
            return true;
        }
        if(a == null || a.val != b.val){        //  a 为 null，或者 a.val != b.val，说明不是子结构
            return false;
        }
        return recur(a.left, b.left) && recur(a.right, b.right);    //  递归判断 a 的左右子树是否包含 b 的左右子树
    }

}
