package com.swordOffer.链表;

public class DetectCycle {
    public static void main(String[] args) {
        ListNode head = new ListNode(4);
        ListNode node1 = new ListNode(5);
        ListNode node2 = new ListNode(1);
        ListNode node3 = new ListNode(9);

        head.next = node1;
        node1.next = node2;
        node2.next = node3;
        node3.next = node1;

        ListNode res1 = detectCycle(head);
        res1.forEach();
    }

    // 剑指 Offer 23. 链表中环的入口节点
    // https://leetcode-cn.com/problems/linked-list-cycle-ii/
    public static ListNode detectCycle(ListNode head) {
        // 快慢指针
        ListNode fast = head;
        ListNode slow = head;

        // 快指针先走k步
        while(fast != null && fast.next != null){
            fast = fast.next.next;
            slow = slow.next;

            if(fast == slow){
                break;
            }
        }

        // 如果没有环
        if(fast == null || fast.next == null){
            return null;
        }

        // 有环的话，快指针回到head，然后快慢指针一起走，相遇的地方就是环的入口
        fast = head;
        while(fast != slow){
            fast = fast.next;
            slow = slow.next;
        }

        return fast;
    }
}
