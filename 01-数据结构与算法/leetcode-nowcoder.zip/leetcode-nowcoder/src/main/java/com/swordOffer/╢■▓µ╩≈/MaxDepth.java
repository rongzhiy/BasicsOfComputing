package com.swordOffer.二叉树;

import com.swordOffer.dfs.TreeNode;

public class MaxDepth {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(3);
        TreeNode left = new TreeNode(9);
        TreeNode right1 = new TreeNode(20);
        TreeNode right2 = new TreeNode(15);
        TreeNode right3 = new TreeNode(7);
        root.left = left;
        root.right = right1;
        right1.left = right2;
        right1.right = right3;

        int res = maxDepth(root);
        System.out.println(res);
    }

    // 104. 二叉树的最大深度
    // https://leetcode-cn.com/problems/maximum-depth-of-binary-tree/
    public static int maxDepth(TreeNode root) {
        if (root == null) {
            return 0;
        }
        // 递归求解左右子树的最大深度
        int leftDepth = maxDepth(root.left);
        int rightDepth = maxDepth(root.right);
        // 返回左右子树中的最大深度 + 1
        return Math.max(leftDepth, rightDepth) + 1;
    }


}


