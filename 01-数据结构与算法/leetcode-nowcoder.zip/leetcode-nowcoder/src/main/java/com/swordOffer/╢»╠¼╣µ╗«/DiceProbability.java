package com.swordOffer.动态规划;

public class DiceProbability {
    public static void main(String[] args) {
        int n = 2;
        double[] res = dicesProbability(n);
        for (int i = 0; i < res.length; i++) {
            System.out.println("res = " + res[i]);
        }
    }

    // 剑指 Offer 60. n个骰子的点数
    //一个骰子能扔出的点数是 1~6，那么 n 个骰子扔出点数 point 的概率就可以通过 n - 1 个骰子扔出点数 point-1, point-2,... point-6 的概率分别乘以 1/6 再相加得到。
    public static double[] dicesProbability(int n) {
        double[] dp = new double[6];
        for (int i = 0; i < 6; i++) {
            dp[i] = 1.0 / 6.0;
        }
        for (int i = 2; i <= n; i++) {  // 骰子数
            // 5 * i + 1 代表骰子数为 i 时，点数和的范围
            //比如当 i=2 时，点数和可能为 2、3、4、5、6、7、8、9、10、11、12。因此，可能的点数和一共有 (6i - i + 1) = 5i + 1 种可能性
            double[] tmp = new double[5 * i + 1];
            for (int j = 0; j < dp.length; j++) {   // 点数和
                for (int k = 0; k < 6; k++) {   // 当前骰子的点数
                    tmp[j + k] += dp[j] / 6.0;  // 点数和为 j + k 的次数 = 点数和为 j 的次数 * 当前骰子的点数为 k 的次数
                }
            }
            dp = tmp;
        }
        return dp;
    }
}
