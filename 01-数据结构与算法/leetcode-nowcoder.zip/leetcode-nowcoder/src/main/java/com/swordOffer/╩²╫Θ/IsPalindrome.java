package com.swordOffer.数组;

public class IsPalindrome {
    public static void main(String[] args) {
        String s = new String("aba");

        boolean res = isPalindrome(s);
        System.out.println(res);
    }

    // 125. 验证回文串
    // https://leetcode-cn.com/problems/valid-palindrome/
    public static boolean isPalindrome(String s) {
        // 一左一右两个指针相向而行
        int left = 0, right = s.length() - 1;
        while (left < right) {
            if (s.charAt(left) != s.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
}
