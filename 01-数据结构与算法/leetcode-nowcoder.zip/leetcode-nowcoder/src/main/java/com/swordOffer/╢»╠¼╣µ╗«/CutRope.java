package com.swordOffer.动态规划;

public class CutRope {
    public static void main(String[] args) {
        int n = 4;
        int res = cuttingRope(n);
        System.out.println("res = " + res);

        int res2 = cuttingRope2(n);
        System.out.println("res2 = " + res2);
    }

    // 剑指 Offer 14- I. 剪绳子
    // 动态规划
    public static int cuttingRope(int n){
        int[] dp = new int[n + 1];
        dp[2] = 1;
        for (int i = 3; i < n + 1; i++) {
            for (int j = 1; j < i - 1; j++) {
                // j * (i - j) 代表拆分成两个数
                // j * dp[i - j] 代表拆分成多个数
                dp[i] = Math.max(dp[i], Math.max(j * (i - j), j * dp[i - j]));
            }
        }
        return dp[n];
    }

    // 剑指 Offer 14- II. 剪绳子 II  “大数越界情况下的求余问题”
    // 贪心算法: 当 n >= 5 时，我们尽可能多地剪长度为 3 的绳子；当剩下的绳子长度为 4 时，把绳子剪成两段长度为 2 的绳子。
    public static int cuttingRope2(int n){
        if(n <= 3){
            return n - 1;
        }
        long res = 1;
        while(n > 4){           // 当n大于4时，尽可能多地剪长度为3的绳子
            res %= 1000000007;   // 每次都要取余
            res *= 3;       // 乘3
            n -= 3;          // 减3
        }
        return (int)(res * n % 1000000007);     // 最后乘以剩下的n
    }
}
