package com.swordOffer.String;

public class ReverseWords {
    public static void main(String[] args) {
        String s = "the sky is blue";
        String res = reverseWords(s);
        System.out.println("翻转单词顺序 = " + res);
    }

// 剑指 Offer 58 - I. 翻转单词顺序
    public static String reverseWords (String s) {
        String[] strs = s.trim().split(" "); // 去除首尾空格，分割字符串
        StringBuilder sb = new StringBuilder();
        for(int i = strs.length-1; i>=0; i--){
            if(strs[i].equals("")) continue;
            sb.append(strs[i]+" "); // 拼接字符串
        }
        return sb.toString().trim();
    }
}
