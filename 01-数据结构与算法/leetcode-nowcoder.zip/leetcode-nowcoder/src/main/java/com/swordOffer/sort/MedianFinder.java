package com.swordOffer.sort;

import java.util.PriorityQueue;

public class MedianFinder {
    public static void main(String[] args) {

    }

    // 剑指 Offer 41. 数据流中的中位数
    // 295. 数据流的中位数

    // 本题的核心思路是使用两个优先级队列。
    private PriorityQueue<Integer> large;
    private PriorityQueue<Integer> small;

    public MedianFinder() {
        // 小顶堆，保存较大的一半
        large = new PriorityQueue<>();
        // 大顶堆, 保存较小的一半
        small = new PriorityQueue<>((a, b) -> {
            return b - a;
        });
    }

    public double findMedian() {

        // 如果元素不一样多，多的那个堆的堆顶元素就是中位数
        if (large.size() < small.size()) {  // small 比 large 元素多
            return small.peek();
        } else if (large.size() > small.size()) {   // large 比 small 元素多
            return large.peek();
        }
        // 如果元素一样多，两个堆堆顶元素的平均数是中位数
        return (large.peek() + small.peek()) / 2.0;

    }

    public void addNum(int num) {
        if (small.size() >= large.size()) { // 保证 small 比 large 元素多
            small.offer(num);   // 先加到 small，再把 small 的堆顶元素加到 large
            large.offer(small.poll());  // small 的堆顶元素是 small 中最大的，加到 large 中
        } else {    // small 比 large 元素少
            large.offer(num);   // 先加到 large，再把 large 的堆顶元素加到 small
            small.offer(large.poll());  // large 的堆顶元素是 large 中最小的，加到 small 中
        }
    }
}
