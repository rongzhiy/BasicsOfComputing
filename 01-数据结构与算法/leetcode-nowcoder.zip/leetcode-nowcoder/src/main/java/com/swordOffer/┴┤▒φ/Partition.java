package com.swordOffer.链表;

public class Partition {
    public static void main(String[] args) {
        ListNode head = new ListNode(1);
        ListNode node1 = new ListNode(4);
        ListNode node2 = new ListNode(3);
        ListNode node3 = new ListNode(2);
        ListNode node4 = new ListNode(5);
        ListNode node5 = new ListNode(2);

        head.next = node1; node1.next = node2; node2.next = node3;
        node3.next = node4; node4.next = node5;

        int x = 3;
        ListNode res = partition(head, x);
        res.forEach();
    }

    // 86. 分隔链表: 用两个虚拟节点来存，一个存小于X的，一个存大于等于x的，最后拼接起来
    // https://leetcode-cn.com/problems/partition-list/
    public static ListNode partition(ListNode head, int x) {
        ListNode dummy1 = new ListNode(-1);
        ListNode dummy2 = new ListNode(-1);
        ListNode p = dummy1, q = dummy2;
        while (head != null){
            if (head.val < x){  // 小于x的节点接到dummy1上
                p.next = head;
                p = p.next;
            }else {        // 大于等于x的节点接到dummy2上
                q.next = head;
                q = q.next;
            }
            ListNode temp = head.next;  // 断开原链表中的每个节点的next指针,防止出现环
            head.next = null;
            head = temp;
        }
        p.next = dummy2.next;
        return dummy1.next;
    }
}
