package com.swordOffer.String;

public class StrToInt {
    public static void main(String[] args) {
        String str = "42";
        int res = strToInt(str);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 67. 把字符串转换成整数
    public static int strToInt(String str) {
        int  n = str.length();
        int i = 0 ;
        // 记录正负号
        int sign = 1;
        // 用long 避免int 溢出
        long res = 0;
        // 跳过前面的空格
        while(i < n && str.charAt(i) == ' '){
            i++;
        }
        if(i == n){
            return 0;
        }
        // 修改符号位
        if(str.charAt(i) == '-'){
            sign = -1;
            i++;
        }else if(str.charAt(i) == '+'){
            i++;
        }
        if(i == n){
            return 0;
        }
        //统计数字位
        while(i < n && '0' <= str.charAt(i) && str.charAt(i) <= '9'){
            res = res * 10 + str.charAt(i) - '0';
            if(res > Integer.MAX_VALUE){
                break;
            }
            i++;
        }
        // 如果溢出，强转成int就会和真实值不同
        if((int) res != res){
            return sign == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE;
        }
        return (int) res *sign;
    }
}
