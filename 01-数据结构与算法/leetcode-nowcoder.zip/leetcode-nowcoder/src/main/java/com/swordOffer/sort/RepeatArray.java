package com.swordOffer.sort;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class RepeatArray {
    public static void main(String[] args) {
        int[] arr = {1, 1, 2, 2};
        List<Integer> res = findDuplicates442(arr);
        System.out.println("res = " + res);

//        int[] arr2 = {2, 3, 1, 0, 2, 5, 3};
        int[] arr2 = {1, 0, 1, 4, 2, 5, 3};
        int res2 = findRepeatNumber03(arr2);
        System.out.println("findRepeatNumber03 = " + res2);

        int[] arr3 = {4, 3, 2, 7, 8, 2, 3, 1};
        List<Integer> res3 = findDisappearedNumbers(arr3);
        System.out.println("findDisappearedNumbers = " + res3);

    }

    //    剑指 Offer 56 - I. 数组中数字出现的次数 I
//    442. 数组中重复的数据，找出所有出现两次的元素，范围在1-n之间
    public static List<Integer> findDuplicates442(int[] nums) {
        int n = nums.length;
        List<Integer> res = new LinkedList<>();
        // 用数组模拟哈希集合
        int[] seen = new int[n+1];
        for(int num : nums){
            if(seen[num] == 0){
                // 添加到哈希集合
                seen[num] = 1;
            }else{
                res.add(num);
            }
        }
        return res;
    }

//    剑指 Offer 03. 数组中重复的数字 ,找出任意一个即可,范围在0-n-1之间
    public static int findRepeatNumber03(int[] nums) {
        Set<Integer> set = new HashSet<Integer>();
        int repeat = -1;
        for(int num : nums){
            if(!set.add(num)){
                repeat = num;
                break;
            }
        }
        return repeat;
    }

//    448. 找到所有数组中消失的数字，范围在1-n之间
    public static List<Integer> findDisappearedNumbers(int[] nums) {
        int n = nums.length;
        int[] count = new int[n+1];
        for(int num:nums){
            count[num]++;
        }
        List<Integer> res = new LinkedList<>();
        for(int num=1;num<=n; num++){
            if(count[num] == 0){
                res.add(num);
            }
        }
        return res;
    }
}
