package com.swordOffer.sort;

public class Exchange {
    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 4, 6, 7};
        int[] res = exchange(nums);
        for (int i : res) {
            System.out.println("i = " + i);
        }
    }

    // 剑指 Offer 21. 调整数组顺序使奇数位于偶数前面
    // https://leetcode.cn/problems/diao-zheng-shu-zu-shun-xu-shi-qi-shu-wei-yu-ou-shu-qian-mian-lcof/?envType=study-plan-v2&envId=coding-interviews
    public static int[] exchange(int[] nums) {
        // nums[0..slow]为奇数
        int fast = 0, slow =0;
        while(fast < nums.length){
            if(nums[fast] % 2 == 1){        // fast遇到奇数，把nums[fast]换到nums[slow]
                int temp = nums[slow];      // slow指向的是偶数，所以slow++
                nums[slow] = nums[fast];    // fast指向的是奇数，所以fast++
                nums[fast] = temp;        // 交换
                slow++;                    // slow指向的是偶数，所以slow++
            }
            fast++;                      // fast指向的是奇数，所以fast++
        }
        return nums;
    }
}
