package com.swordOffer.动态规划;

public class CountDigitOne {
    public static void main(String[] args) {
        int n = 12;
        int res = countDigitOne(n);
        System.out.println("res = " + res);

        int res2 = countDigitOne2(n);
        System.out.println("res2 = " + res2);
    }

    // 剑指 Offer 43. 1～n 整数中 1 出现的次数

    // 1. 暴力解法   超时
    public static int countDigitOne(int n) {
        int count = 0;
        for(int i = 1; i <= n; i++){
            int temp = i;
            while(temp != 0){
                if(temp % 10 == 1){
                    count++;
                }
                temp /= 10;
            }
        }
        return count;
    }

    // 2. 数学解法  逐位统计
    public static int countDigitOne2(int n) {
        int digit = 1, res = 0;
        int high = n / 10, cur = n % 10, low = 0;
        while(high != 0 || cur != 0) {
            if(cur == 0) res += high * digit;
            else if(cur == 1) res += high * digit + low + 1;
            else res += (high + 1) * digit;
            low += cur * digit;
            cur = high % 10;
            high /= 10;
            digit *= 10;
        }
        return res;
    }


}
