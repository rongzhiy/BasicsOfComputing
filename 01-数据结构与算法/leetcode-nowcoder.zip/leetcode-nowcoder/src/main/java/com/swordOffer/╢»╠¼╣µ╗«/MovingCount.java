package com.swordOffer.动态规划;

public class MovingCount {
    public static void main(String[] args) {
        int m = 2, n = 3, k = 1;
        int res = movingCount(m, n, k);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 13. 机器人的运动范围
    // 深度优先搜索
    public static int movingCount(int m, int n, int k){
        boolean[][] visited = new boolean[m][n];
        return dfs(0, 0, m, n, k, visited);
    }

    static int dfs(int i, int j, int m, int n, int k, boolean[][] visited){
        if(i >= m || j >= n || k < (i / 10 + i % 10 + j / 10 + j % 10) || visited[i][j]){
            return 0;
        }
        visited[i][j] = true;
        return 1 + dfs(i + 1, j, m, n, k, visited) + dfs(i, j + 1, m, n, k, visited); // 只需要向下或向右搜索
    }
}
