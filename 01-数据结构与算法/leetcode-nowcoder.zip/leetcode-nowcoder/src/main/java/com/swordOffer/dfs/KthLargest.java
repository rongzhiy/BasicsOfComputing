package com.swordOffer.dfs;

public class KthLargest {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(3);
        TreeNode node1 = new TreeNode(1);
        TreeNode node2 = new TreeNode(4);
        root.left = node1;
        root.right = node2;
        TreeNode node3 = new TreeNode(2);
        node1.right = node3;

        int res = kthLargest(root, 1);
        System.out.println("第K大节点 = " + res);

    }

    // 记录结果
    static int res = 0;
    // 记录当前元素的排名
    static int rank = 0;

    // 剑指 Offer 54. 二叉搜索树的第k大节点
    public static int kthLargest(TreeNode root, int k) {
        // 利用 BST 的中序遍历特性
        traverse(root, k);  //  中序遍历代码位置
        return res;
    }


    static void traverse(TreeNode root, int k) {
        if (root == null) {
            return;
        }
        traverse(root.right, k);
        /* 中序遍历代码位置 */
        rank++;
        if (k == rank) {
            // 找到第 k 大的元素
            res = root.val;
            return;
        }
        /*****************/
        traverse(root.left, k);
    }


}
