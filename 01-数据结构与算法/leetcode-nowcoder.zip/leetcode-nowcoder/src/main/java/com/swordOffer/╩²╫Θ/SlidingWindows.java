package com.swordOffer.数组;

public class SlidingWindows {
    public static void main(String[] args) {
        int[] nums = {1, 3, -1, -3, 5};
        int[] res = maxSlidingWindow(nums, 3);
        for (int re : res) {
            System.out.println(re);
        }
    }

    // 239. 滑动窗口最大值
    // https://leetcode-cn.com/problems/sliding-window-maximum/
    public static int[] maxSlidingWindow(int[] nums, int k) {
        if (nums.length == 0) {
            return nums;
        }

        int[] res = new int[nums.length - k + 1];
        int resIndex = 0;

        // 双端队列
        int[] deque = new int[nums.length];
        int dequeHead = 0, dequeTail = -1;

        for (int i = 0; i < nums.length; i++) {
            // 队列不为空且队尾元素小于当前元素
            while (dequeHead <= dequeTail && nums[deque[dequeTail]] <= nums[i]) {
                dequeTail--;
            }
            // 入队
            deque[++dequeTail] = i;

            // 队头元素不在滑动窗口内
            if (deque[dequeHead] <= i - k) {
                dequeHead++;
            }

            // 滑动窗口形成时
            if (i >= k - 1) {
                res[resIndex++] = nums[deque[dequeHead]];
            }
        }

        return res;
    }
}
