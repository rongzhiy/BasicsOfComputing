package com.swordOffer.sort;

import java.util.HashSet;

public class Poke {
    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 4, 4, 3, 2, 1};

        boolean res = isStraight(nums);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 61. 扑克牌中的顺子
    private static boolean isStraight(int[] nums) {
        int[] bucket = new int[14];
        int max = 0, min = 14;
        for (int num : nums) {
            if (num == 0) continue;  // 跳过大小王
            bucket[num]++;
            if (bucket[num] > 1) return false;  // 若有重复，提前返回 false
            max = Math.max(max, num);   // 最大牌
            min = Math.min(min, num);   // 最小牌
        }
        return max - min < 5;   // 最大牌 - 最小牌 < 5 则可构成顺子
    }

    //方法二： HashSet

    public static boolean isStraight1(int[] nums){
        HashSet set = new HashSet();
        int max = 0;
        int min = 14;
        for (int num : nums) {
            if (num == 0) continue;  // 跳过大小王
            max = Math.max(max, num);   // 最大牌
            min = Math.min(min, num);   // 最小牌
            if (set.contains(num)) return false;  // 若有重复，提前返回 false
            set.add(num);
        }
        return false;
    }

}
