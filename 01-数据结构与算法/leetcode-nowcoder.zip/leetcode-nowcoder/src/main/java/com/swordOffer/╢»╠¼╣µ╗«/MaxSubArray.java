package com.swordOffer.动态规划;

public class MaxSubArray {
    public static void main(String[] args) {
        int[] nums = {-2,1,-3,4,-1,2,1,-5};
//        int[] nums = {-2,1};
        int res = maxSubArray(nums);
        System.out.println("res = " + res);
    }

    // 剑指offer 42. 连续子数组的最大和
//    以 nums[i] 为结尾的「最大子数组和」为 dp[i]。
//
//    dp[i] 有两种「选择」，要么与前面的相邻子数组连接，形成一个和更大的子数组；要么不与前面的子数组连接，自成一派，自己作为一个子数组。
//
//    在这两种选择中择优，就可以计算出最大子数组，而且空间复杂度还有优化空间
    public static int maxSubArray(int[] nums) {
        int n = nums.length;
        if (n == 0) return 0;
        int[] dp = new int[n];
        // base case
        // 第一个元素前面没有子数组
        dp[0] = nums[0];
        // 状态转移方程
        for (int i = 1; i < n; i++) {
            dp[i] = Math.max(nums[i], nums[i] + dp[i - 1]);
        }
        // 得到 nums 的最大子数组
        int res = Integer.MIN_VALUE;
        for (int i = 0; i < n; i++) {
            res = Math.max(res, dp[i]);
        }
        return res;
    }

}
