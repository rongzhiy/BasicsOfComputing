package com.swordOffer.String;

public class ReverseLeftWords {
    public static void main(String[] args) {
        String s = "abcdefg";
        int n = 2;
        String res = reverseLeftWords(s, n);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 58 - II. 左旋转字符串
    public static String reverseLeftWords(String s, int n) {
        return s.substring(n) + s.substring(0,n);
    }

}
