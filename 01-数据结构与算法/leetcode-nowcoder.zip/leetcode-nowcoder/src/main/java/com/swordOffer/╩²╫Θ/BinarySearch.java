package com.swordOffer.数组;

public class BinarySearch {
    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 4, 5};

        int res = binarySearch(nums, 3);
        System.out.println(res);
    }

    // 二分查找
    // https://leetcode-cn.com/problems/binary-search/
    public static int binarySearch(int[] nums, int target) {
        int left = 0, right = nums.length - 1;

        // [left, right]
        while (left <= right) {
            // 防止溢出
            int mid = left + (right - left) / 2;

            if (target == nums[mid]) {
                return mid;
            } else if (target > nums[mid]) {
                // target 在 [mid + 1, right]
                left = mid + 1;
            } else {
                // target 在 [left, mid - 1]
                right = mid - 1;
            }
        }

        return -1;
    }
}
