package com.swordOffer.bfs;

import com.swordOffer.dfs.TreeNode;

import java.util.LinkedList;
import java.util.List;

public class LevelOrder {
    public static void main(String[] args) {
            TreeNode root = new TreeNode(3);
            TreeNode node1 = new TreeNode(1);
            TreeNode node2 = new TreeNode(2);
            root.left = node1;
            root.right = node2;
            TreeNode node3 = new TreeNode(4);
            node1.right = node3;
        for (List<Integer> integers : levelOrder(root)) {
            System.out.println(integers);
        }
    }

    // 剑指 Offer 32 - I. 从上到下打印二叉树
    // BFS
    public static List<List<Integer>> levelOrder(TreeNode root) {
        List<List<Integer>> res = new LinkedList<>();  // 用于存放结果
        if(root == null) {
            return res;
        }
        LinkedList<TreeNode> queue = new LinkedList<>();        // 用于存放节点
        queue.add(root);        // 先将根节点加入队列
        while(!queue.isEmpty()) {       // 队列不为空时，循环
            LinkedList<Integer> tmp = new LinkedList<>();   // 用于存放每一层的结果
            for(int i = queue.size(); i > 0; i--) {     // 遍历当前层的节点
                TreeNode node = queue.poll();           // 取出当前层的节点
                tmp.add(node.val);                      // 将当前层的节点值加入结果
                if(node.left != null) {                 // 如果当前层的节点有左子节点，将左子节点加入队列
                    queue.add(node.left);
                }
                if(node.right != null){                     // 如果当前层的节点有右子节点，将右子节点加入队列
                    queue.add(node.right);
                }
            }
            res.add(tmp);       // 将当前层的结果加入最终结果
        }
        return res;
    }
}
