package com.swordOffer.链表;

import static com.swordOffer.链表.ReserveN.reverseN;

public class ReserveBetween {
    public static void main(String[] args) {
        ListNode head = new ListNode(1);
        ListNode node1 = new ListNode(2);

        head.next = node1;

        ListNode res = reverseBetween(head, 1, 2);
        res.forEach();
    }

    // 92. 反转链表 II
    // https://leetcode-cn.com/problems/reverse-linked-list-ii/
    public static ListNode reverseBetween(ListNode head, int left, int right) {
        ListNode dummy = new ListNode(-1);
        dummy.next = head;

        ListNode pre = dummy;
        ListNode cur = head;

        // 找到left的前一个节点
        for (int i = 0; i < left - 1; i++) {
            pre = pre.next;
            cur = cur.next;
        }

        // 反转链表
        for (int i = 0; i < right - left; i++) {
            ListNode temp = cur.next;
            cur.next = temp.next;
            temp.next = pre.next;
            pre.next = temp;
        }

        return dummy.next;
    }

    // 递归反转链表前M 到 N 个节点  法二
    ListNode reverseBetween1(ListNode head, int m, int n) {
        // base case
        if (m == 1) {
            return reverseN(head, n);
        }
        // 前进到反转的起点触发 base case
        head.next = reverseBetween1(head.next, m - 1, n - 1);
        return head;
    }


}
