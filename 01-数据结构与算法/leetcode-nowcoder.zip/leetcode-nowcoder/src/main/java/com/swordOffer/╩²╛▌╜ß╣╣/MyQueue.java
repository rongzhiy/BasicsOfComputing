package com.swordOffer.数据结构;

import java.util.Stack;

public class MyQueue {
    //    用栈实现队列
    private Stack<Integer> s1, s2;

    public MyQueue() {
        s1 = new Stack<>();
        s2 = new Stack<>();
    }

    public void push(int x) {
        s1.push(x);
    }

    public int pop() {
        peek();
        return s2.pop();
    }

    public int peek() {
        if (s2.isEmpty()) {
            while (!s1.isEmpty()) {
                s2.push(s1.pop());
            }
        }
        return s2.peek();
    }

    public boolean empty() {
        return s1.isEmpty() && s2.isEmpty();
    }

    public static void main(String[] args) {
        MyQueue queue = new MyQueue();
        queue.push(1);
        queue.push(2);

        System.out.println("queue.peek() = " + queue.peek());
        System.out.println("queue.pop() = " + queue.pop());
        System.out.println("queue.empty() = " + queue.empty());
    }


}
