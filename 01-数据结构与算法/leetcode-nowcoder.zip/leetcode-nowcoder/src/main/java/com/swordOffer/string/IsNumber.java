package com.swordOffer.String;

public class IsNumber {
    public static void main(String[] args) {
        String s = "e";
        boolean res = isNumber(s);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 20. 表示数值的字符串
//    部分数值列举如下：
//            ["+100", "5e2", "-123", "3.1416", "-1E-16", "0123"]
//    部分非数值列举如下：
//            ["12e", "1a3.14", "1.2.3", "+-5", "12e+5.4"]
    private static boolean isNumber(String s) {
        if(s == null || s.length() == 0) return false;
        // 标记是否遇到数位、小数点、‘e’或'E'
        boolean isNum = false, isDot = false, ise_or_E = false;
        // 删除字符串头尾的空格
        s = s.trim();
        for (int i = 0; i < s.length(); i++) {
            // 判断当前字符是否为 0~9 的数位
            if(s.charAt(i) >= '0' && s.charAt(i) <= '9'){ // 0~9 的数位
                isNum = true;
            }
            // 遇到小数点
            else if(s.charAt(i) == '.'){
                if(isDot || ise_or_E){  // 之前已经出现过小数点或者‘e’或'E'
                    return false;
                }
                isDot = true;
            }
            // 遇到‘e’或'E'
            else if(s.charAt(i) == 'e' || s.charAt(i) == 'E'){
                if(!isNum || ise_or_E){     // 之前没有出现过数位或者之前已经出现过‘e’或'E'
                    return false;
                }
                ise_or_E = true;
                isNum = false; // 重置isNum，因为‘e’或'E'之后也要求至少有一位数
            }
            // 遇到‘+’或'-'
            else if(s.charAt(i) == '+' || s.charAt(i) == '-'){
                // 第二次出现‘+’或'-'必须紧跟在‘e’或'E'后面
                if(i != 0 && s.charAt(i - 1) != 'e' && s.charAt(i - 1) != 'E'){
                    return false;
                }
            }
            // 其它情况均为不合法字符
            else{
                return false;
            }
        }
        return isNum;
    }
}
