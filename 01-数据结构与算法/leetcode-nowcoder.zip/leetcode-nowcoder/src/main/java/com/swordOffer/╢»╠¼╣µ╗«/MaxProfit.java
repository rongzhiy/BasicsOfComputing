package com.swordOffer.动态规划;

public class MaxProfit {
    public static void main(String[] args) {
        int[] prices = {7, 1, 5, 3, 6, 4};

        int res = maxProfit(prices);
        System.out.println("股票的最大利润= " + res);

        int res1 = maxProfit1(prices);
        System.out.println("买股票的最佳时间1 一次交易= " + res1);

        int res2 = maxProfit2(prices);
        System.out.println("买股票的最佳时间2 无限次交易= " + res2);

        int res3 = maxProfit3(prices);
        System.out.println("买股票的最佳时间3 两次交易= " + res3);

        int res4 = maxProfit4(2, prices);
        System.out.println("买股票的最佳时间4 k次交易= " + res4);

        int res5 = maxProfit5(prices);
        System.out.println("买股票的最佳时间5 冷冻期1天= " + res5);

        int res6 = maxProfit6(prices,2);
        System.out.println("买股票的最佳时间6 交易费用2= " + res6);

    }

    // 剑指 Offer 63. 股票的最大利润
    public static int maxProfit(int[] prices) {
        int n = prices.length;
        if (n == 0) return 0;

        int min = prices[0];
        int res = 0;

        for (int i = 1; i < n; i++) {
            if (prices[i] < min) {
                min = prices[i];
            } else {
                res = Math.max(res, prices[i] - min);
            }
        }
        return res;

    }


    // 121. 买卖股票的最佳时机  一次交易
//    dp[i][k][0 or 1]
//    0 <= i <= n - 1, 1 <= k <= K
//    n 为天数，大 K 为交易数的上限，0 和 1 代表是否持有股票。
    public static int maxProfit1(int[] prices) {
        int n = prices.length;      // 天数
        int[][] dp = new int[n][2]; // 0 代表不持有股票，1 代表持有股票
        for (int i = 0; i < n; i++) {
            if (i - 1 == -1) {      // base case
                dp[i][0] = 0;       // 第 0 天，不持有股票，利润为 0
                dp[i][1] = -prices[i];  // 第 0 天，持有股票，利润为 -prices[i]
                continue;        // 进入下一次循环
            }
            dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] + prices[i]);    // 第 i 天，不持有股票，利润为：max(前一天不持有股票的利润，前一天持有股票的利润 + 当天股票的价格)
            dp[i][1] = Math.max(dp[i - 1][1], -prices[i]);               // 第 i 天，持有股票，利润为：max(前一天持有股票的利润，当天买入股票的利润)
        }
        return dp[n - 1][0];   // 返回最后一天，不持有股票的利润
    }

    //122. 买卖股票的最佳时机 II 无限次交易

        public static int maxProfit2(int[] prices) {
            int n = prices.length;
            int[][] dp = new int[n][2];
            for (int i = 0; i < n; i++) {
                if (i - 1 == -1) {
                    // base case
                    dp[i][0] = 0;
                    dp[i][1] = -prices[i];
                    continue;
                }
                dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] + prices[i]);
                dp[i][1] = Math.max(dp[i - 1][1], dp[i - 1][0] - prices[i]);
            }
            return dp[n - 1][0];
        }

    // 123. 买卖股票的最佳时机 III    两次交易
//    股票系列问题状态定义：
//    dp[i][k][0 or 1]
//    0 <= i <= n - 1, 1 <= k <= K
//    n 为天数，大 K 为交易数的上限，0 和 1 代表是否持有股票。
    public static int maxProfit3(int[] prices) {
        int max_k = 2, n = prices.length;
        int[][][] dp = new int[n][max_k + 1][2];
        for (int i = 0; i < n; i++) {
            for (int k = max_k; k >= 1; k--) {
                if (i - 1 == -1) {
                    // 处理 base case
                    dp[i][k][0] = 0;
                    dp[i][k][1] = -prices[i];
                    continue;
                }
                dp[i][k][0] = Math.max(dp[i-1][k][0], dp[i-1][k][1] + prices[i]);
                dp[i][k][1] = Math.max(dp[i-1][k][1], dp[i-1][k-1][0] - prices[i]);
            }
        }
        // 穷举了 n × max_k × 2 个状态，正确。
        return dp[n - 1][max_k][0];
    }

    // 188. 买卖股票的最佳时机 IV  k次交易

    public static int maxProfit4 (int max_k, int[] prices) {
        int n = prices.length;
        if (n <= 0) {
            return 0;
        }
        // base case：
        // dp[-1][...][0] = dp[...][0][0] = 0
        // dp[-1][...][1] = dp[...][0][1] = -infinity
        int[][][] dp = new int[n][max_k + 1][2];
        // k = 0 时的 base case
        for (int i = 0; i < n; i++) {
            dp[i][0][1] = Integer.MIN_VALUE;
            dp[i][0][0] = 0;
        }

        for (int i = 0; i < n; i++)
            for (int k = max_k; k >= 1; k--) {
                if (i - 1 == -1) {
                    // 处理 i = -1 时的 base case
                    dp[i][k][0] = 0;
                    dp[i][k][1] = -prices[i];
                    continue;
                }
                // 状态转移方程
                dp[i][k][0] = Math.max(dp[i - 1][k][0], dp[i - 1][k][1] + prices[i]);
                dp[i][k][1] = Math.max(dp[i - 1][k][1], dp[i - 1][k - 1][0] - prices[i]);
            }
        return dp[n - 1][max_k][0];
    }

    //309. 最佳买卖股票时机含冷冻期
    public static int maxProfit5(int[] prices) {
        int n = prices.length;
        int[][] dp = new int[n][2];
        for (int i = 0; i < n; i++) {
            if (i - 1 == -1) {
                // base case 1
                dp[i][0] = 0;
                dp[i][1] = -prices[i];
                continue;
            }
            if (i - 2 == -1) {
                // base case 2
                dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] + prices[i]);
                // i - 2 小于 0 时根据状态转移方程推出对应 base case
                dp[i][1] = Math.max(dp[i - 1][1], -prices[i]);
                //   dp[i][1]
                // = max(dp[i-1][1], dp[-1][0] - prices[i])
                // = max(dp[i-1][1], 0 - prices[i])
                // = max(dp[i-1][1], -prices[i])
                continue;
            }
            dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] + prices[i]);
            dp[i][1] = Math.max(dp[i - 1][1], dp[i - 2][0] - prices[i]); //第 i 天选择 buy 的时候，要从 i-2 的状态转移，而不是 i-1。
        }
        return dp[n - 1][0];
    }

    //714. 买卖股票的最佳时机含手续费
//    特化到 k 无限制且包含手续费的情况，只需稍微修改 122. 买卖股票的最佳时机 II，手续费可以认为是买入价变贵了或者卖出价变便宜了。
    public static int maxProfit6(int[] prices, int fee) {
        int n = prices.length;
        int[][] dp = new int[n][2];
        for (int i = 0; i < n; i++) {
            if (i - 1 == -1) {
                // base case
                dp[i][0] = 0;
                dp[i][1] = -prices[i] - fee;
                //   dp[i][1]
                // = max(dp[i - 1][1], dp[i - 1][0] - prices[i] - fee)
                // = max(dp[-1][1], dp[-1][0] - prices[i] - fee)
                // = max(-inf, 0 - prices[i] - fee)
                // = -prices[i] - fee
                continue;
            }
            dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] + prices[i]);
            dp[i][1] = Math.max(dp[i - 1][1], dp[i - 1][0] - prices[i] - fee);
        }
        return dp[n - 1][0];
    }
}
