package com.swordOffer.二叉树;

import com.swordOffer.dfs.TreeNode;

public class PreorderTraverse {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(1);
        TreeNode node1 = new TreeNode(2); root.left = node1;
        TreeNode node2 = new TreeNode(3); root.right = node2;
        TreeNode node3 = new TreeNode(4); node1.left = node3;
        TreeNode node4 = new TreeNode(5); node1.right = node4;
        TreeNode node5 = new TreeNode(6); node2.left = node5;
        TreeNode node6 = new TreeNode(7); node2.right = node6;

        preorderTraverse(root);
    }

    // 二叉树的前序遍历
    // https://leetcode-cn.com/problems/binary-tree-preorder-traversal/
    public static void preorderTraverse(TreeNode root) {
        if (root == null) {
            return;
        }

        System.out.println(root.val);
        preorderTraverse(root.left);
        preorderTraverse(root.right);
    }
}
