package com.swordOffer.数组;

public class MoveZeroes {
    public static void main(String[] args) {
        int[] nums = {0, 1, 0, 3, 12};

        moveZeroes(nums);
        for (int num : nums) {
            System.out.println(num);
        }
    }

    // 283. 移动零
    // https://leetcode-cn.com/problems/move-zeroes/
    public static void moveZeroes(int[] nums) {
        int slow = 0, fast = 0;
        while (fast < nums.length) {
            if (nums[fast] != 0) {
                // 维护 nums[0..slow] 无零
                nums[slow] = nums[fast];
                slow++;
            }
            fast++;
        }
        // 将 nums[slow..nums.length - 1] 设为零
        while (slow < nums.length) {
            nums[slow] = 0;
            slow++;
        }
    }
}
