package com.swordOffer.数组;

public class RemoveElement {
    public static void main(String[] args) {
        int[] nums = {3, 2, 2, 3};
        int res = removeElement(nums, 3);
        System.out.println(res);
    }

    // 27. 移除元素
    // https://leetcode-cn.com/problems/remove-element/
    public static int removeElement(int[] nums, int val) {
        int slow = 0, fast = 0;
        while (fast < nums.length) {
            if (nums[fast] != val) {
                // 维护 nums[0..slow] 无 val
                nums[slow] = nums[fast];
                slow++;
            }
            fast++;
        }
        // 数组长度为索引 + 1
        return slow;
    }
}
