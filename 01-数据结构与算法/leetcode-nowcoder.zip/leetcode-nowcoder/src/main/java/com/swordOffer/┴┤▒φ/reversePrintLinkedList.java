package com.swordOffer.链表;


public class reversePrintLinkedList {
    public static void main(String[] args) {
        ListNode head = new ListNode(1);
        ListNode node1 = new ListNode(3);
        ListNode node2 = new ListNode(2);

        head.next = node1;
        node1.next = node2;

        int[] res = reversePrint(head);
        for (int i : res) {
            System.out.println(" " + i);
        }


    }

    // 剑指 Offer 06. 从尾到头打印链表
    // https://leetcode-cn.com/problems/cong-wei-dao-tou-da-yin-lian-biao-lcof/


    static int[] res; // 存放结果
    static int len = 0; // 链表长度

    static int p=0; // 指针

    public static int[] reversePrint(ListNode head){
        traverse(head);
        return res;
    }

    private static void traverse(ListNode head) {
        if(head == null){
            res = new int[len];
            return;
        }
        len++;
        traverse(head.next); // 后序遍历
        res[p] = head.val;
        p++;
    }

}
