package com.swordOffer.String;

public class FirstUniqChar {
    public static void main(String[] args) {
        String s = "abaccdeff";
        char res = firstUniqChar(s);
        System.out.println("返回字符 = " + res);

        String s1 = "leetcode";
        int res1 = firstUniqChar1(s1);
        System.out.println("返回下标 = " + res1);

    }

    // 剑指 Offer 50. 第一个只出现一次的字符  返回字符
    public static char firstUniqChar(String s) {
        int[] count = new int[26];
        char[] chars = s.toCharArray();
        for(char c : chars){
            count[c - 'a']++;
        }
        for(char c : chars){
            if(count[c - 'a'] == 1){
                return c;
            }
        }
        return ' ';
    }
    // 387. 字符串中的第一个唯一字符  返回下标

        public static int firstUniqChar1(String s) {
            int[] count = new int[26];
            for(char c:s.toCharArray()){
                // 将字符转化为数字
                count[c-'a']++;
            }
            for(int i=0;i < s.length();i++){
                char c = s.charAt(i);
                if(count[c-'a'] == 1){
                    return i; //第一个出现一次的字符
                }
            }
            return -1;
        }


}
