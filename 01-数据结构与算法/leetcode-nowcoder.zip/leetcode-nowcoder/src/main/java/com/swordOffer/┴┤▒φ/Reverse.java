package com.swordOffer.链表;

public class Reverse {
    //    反转链表
    public static void main(String[] args) {
        ListNode head = new ListNode(1);
        ListNode node1 = new ListNode(2);
        ListNode node2 = new ListNode(3);
        ListNode node3 = new ListNode(4);
        ListNode node4 = new ListNode(5);

        head.next = node1;
        node1.next = node2;
        node2.next = node3;
        node3.next = node4;

        ListNode res = reverse(head);
        res.forEach();
    }

    // 206. 反转链表
    // https://leetcode-cn.com/problems/reverse-linked-list/
    public static ListNode reverse(ListNode head) {
        ListNode pre = null;
        ListNode cur = head;
        ListNode temp = null;

        while (cur != null) {   // 遍历链表
            temp = cur.next;  // 保存当前节点的下一个节点
            cur.next = pre;   // 当前节点指向前一个节点
            pre = cur;        // 前一个节点后移
            cur = temp;       // 当前节点后移
        }

        return pre;
    }


    //    递归反转链表
    // 定义：输入一个单链表头结点，将该链表反转，返回新的头结点
    ListNode reverse2(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }
        ListNode last = reverse2(head.next);
        head.next.next = head;
        head.next = null;
        return last;
    }


}
