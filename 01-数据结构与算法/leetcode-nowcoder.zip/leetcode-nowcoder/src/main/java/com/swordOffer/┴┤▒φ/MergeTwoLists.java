package com.swordOffer.链表;

public class MergeTwoLists {
    public static void main(String[] args) {
        ListNode head1 = new ListNode(1);
        ListNode node11 = new ListNode(2);
        ListNode node12 = new ListNode(4);

        head1.next = node11;
        node11.next = node12;

        ListNode head2 = new ListNode(1);
        ListNode node21 = new ListNode(3);
        ListNode node22 = new ListNode(4);

        head2.next = node21;
        node21.next = node22;

        ListNode res1 = mergeTwoLists(head1, head2);
        res1.forEach();
    }

    // 剑指 Offer 25. 合并两个排序的链表
    // https://leetcode-cn.com/problems/he-bing-liang-ge-pai-xu-de-lian-biao-lcof/

    public static ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        // 递归
        // 递归终止条件
        if(l1 == null){
            return l2;
        }

        if(l2 == null){
            return l1;
        }

        // 递归过程
        if(l1.val <= l2.val){
            l1.next = mergeTwoLists(l1.next, l2);
            return l1;
        }

        if(l1.val > l2.val){
            l2.next = mergeTwoLists(l1, l2.next);
            return l2;
        }

        return null;
    }

    public static ListNode mergeTwoLists2(ListNode l1, ListNode l2) {
        // 迭代
        ListNode dummy = new ListNode(-1);
        ListNode p = dummy;

        while(l1 != null && l2 != null){
            if(l1.val <= l2.val){
                p.next = l1;
                l1 = l1.next;
                p = p.next;
            }else{
                p.next = l2;
                l2 = l2.next;
                p = p.next;
            }
        }

        if(l1 != null){
            p.next = l1;
        }

        if(l2 != null){
            p.next = l2;
        }

        return dummy.next;
    }
}
