package com.swordOffer.链表;

public class ListNode {
    int val;
    public ListNode next;

    ListNode() {}
    ListNode(int x) { val = x; }

    ListNode (int val, ListNode next){
        this.val = val;
        this.next = next;
    }


    public void forEach(){
        ListNode cur = this;
        while (cur != null) {
            System.out.println("cur.val = " + cur.val);
            cur = cur.next;
        }
    }

}
