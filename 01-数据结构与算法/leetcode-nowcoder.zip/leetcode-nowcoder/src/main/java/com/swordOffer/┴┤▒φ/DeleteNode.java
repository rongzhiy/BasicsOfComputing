package com.swordOffer.链表;

public class DeleteNode {
    public static void main(String[] args) {
        ListNode head = new ListNode(4);
        ListNode node1 = new ListNode(5);
        ListNode node2 = new ListNode(1);
        ListNode node3 = new ListNode(9);

        head.next = node1;
        node1.next = node2;
        node2.next = node3;

        int val = 5;

        ListNode res1 = deleteNode(head, val);
        res1.forEach();
    }

    // 剑指offer 18. 删除链表的节点
    // https://leetcode-cn.com/problems/shan-chu-lian-biao-de-jie-dian-lcof/


    public static ListNode deleteNode(ListNode head, int val) {
        // 存放删除val的链表
        ListNode dummy = new ListNode(-1);
        // q指针负责生成结果链表
        ListNode q = dummy;
        // p 负责遍历原链表
        ListNode p = head;
        while(p != null){
            if(p.val != val){
                // 把不为val的节点接到结果链表上
                q.next = p;
                q = q.next;
            }

            ListNode temp = p.next;
            p.next = null;  // 断开原链表中的每个节点的next指针
            p = temp;
        }

        return dummy.next;
    }

}
