package com.swordOffer.链表;

public class FindeFromEnd {
    public static void main(String[] args) {
        ListNode head = new ListNode(4);
        ListNode node1 = new ListNode(5);
        ListNode node2 = new ListNode(1);
        ListNode node3 = new ListNode(9);

        head.next = node1;
        node1.next = node2;
        node2.next = node3;

        int k = 2;

        ListNode res1 = getKthFromEnd(head, k);
        res1.forEach();
    }

    // 剑指 Offer 22. 链表中倒数第k个节点
    // https://leetcode-cn.com/problems/lian-biao-zhong-dao-shu-di-kge-jie-dian-lcof/

    public static ListNode getKthFromEnd(ListNode head, int k) {
        // 快慢指针
        ListNode fast = head;
        ListNode slow = head;

        // 快指针先走k步
        while(k > 0){
            fast = fast.next;
            k--;
        }

        // 快慢指针一起走
        while(fast != null){
            fast = fast.next;
            slow = slow.next;
        }

        return slow;
    }
}
