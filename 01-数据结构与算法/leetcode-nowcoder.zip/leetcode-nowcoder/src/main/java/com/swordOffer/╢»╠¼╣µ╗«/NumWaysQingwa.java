package com.swordOffer.动态规划;

public class NumWaysQingwa {
    // 剑指 Offer 10- II. 青蛙跳台阶问题  (动态规划)
    //爬到第 n 级台阶的方法个数等于爬到 n - 1 的方法个数和爬到 n - 2 的方法个数之和。
//    一只青蛙一次可以跳上1级台阶，也可以跳上2级台阶。求该青蛙跳上一个 n 级的台阶总共有多少种跳法。
//
//    答案需要取模 1e9+7（1000000007），如计算初始结果为：1000000008，请返回 1。

    public static void main(String[] args) {
        int n = 2;
        int res = numWays(n);
        System.out.println("res = " + res);
    }

    public static int numWays(int n){
        if(n == 0 || n == 1) return 1;
        int a = 1, b = 1, sum = 0;
        for (int i = 2; i <= n; i++) {
            sum = (a + b) % 1000000007;
            a = b;
            b = sum;
        }
        return sum;
    }
}
