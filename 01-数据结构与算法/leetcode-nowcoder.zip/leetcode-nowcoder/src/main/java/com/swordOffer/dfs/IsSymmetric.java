package com.swordOffer.dfs;

public class IsSymmetric {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(1);
        TreeNode node1 = new TreeNode(2);
        TreeNode node2 = new TreeNode(2);
        TreeNode node3 = new TreeNode(3);
        TreeNode node4 = new TreeNode(4);
        TreeNode node5 = new TreeNode(4);
        TreeNode node6 = new TreeNode(3);
        root.left = node1;
        root.right = node2;
        node1.left = node3;
        node1.right = node4;
        node2.left = node5;
        node2.right = node6;
        boolean res = isSymmetric(root);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 28. 对称的二叉树
    public static boolean isSymmetric(TreeNode root){
        if (root == null) {
            return true;
        }
        return dfs(root.left, root.right);
    }

    private static boolean dfs(TreeNode left, TreeNode right) {     //  递归
        if (left == null && right == null) {    //  左右子树都为空，说明是对称的
            return true;
        }

        if (left == null || right == null || left.val != right.val) {   //  左右子树有一个为空，或者左右子树的值不相等，说明不是对称的
            return false;
        }

        return dfs(left.left, right.right) && dfs(left.right, right.left);  //  递归判断左右子树的左右子树是否对称
    }
}
