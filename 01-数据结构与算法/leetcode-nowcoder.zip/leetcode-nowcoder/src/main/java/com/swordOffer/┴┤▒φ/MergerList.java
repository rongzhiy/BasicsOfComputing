package com.swordOffer.链表;

import java.util.PriorityQueue;

public class MergerList {
//    优先级队列合并k个有序链表
//    https://leetcode-cn.com/problems/merge-k-sorted-lists/
    public static void main(String[] args) {
        ListNode head1 = new ListNode(1);
        ListNode node1 = new ListNode(4);
        ListNode node2 = new ListNode(5);

        head1.next = node1;
        node1.next = node2;

        ListNode head2 = new ListNode(1);
        ListNode node3 = new ListNode(3);
        ListNode node4 = new ListNode(4);

        head2.next = node3;
        node3.next = node4;

        ListNode head3 = new ListNode(2);
        ListNode node5 = new ListNode(6);

        head3.next = node5;

        ListNode[] lists = {head1, head2, head3};

        ListNode res = new MergerList().mergeKLists(lists);
        res.forEach();

    }

    public ListNode mergeKLists(ListNode[] lists) {
        if (lists == null || lists.length == 0){
            return null;
        }
        ListNode dummy = new ListNode(-1);
        ListNode p = dummy;

        // 优先级队列
        PriorityQueue<ListNode> queue = new PriorityQueue<>(lists.length,(o1,o2)->o1.val - o2.val);

        for (ListNode node : lists){
            if (node != null){
                queue.add(node);
            }
        }
        while (!queue.isEmpty()){
            ListNode node = queue.poll();
            p.next = node;
            p = p.next;
            if (node.next != null){
                queue.add(node.next);
            }
        }
        return dummy.next;

    }


}
