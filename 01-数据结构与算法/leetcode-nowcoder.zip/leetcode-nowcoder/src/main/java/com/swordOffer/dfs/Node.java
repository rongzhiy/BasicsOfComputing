package com.swordOffer.dfs;

public class Node {
    int val;
    Node left;
    Node right;
    public Node(){}
    public Node(int x) { val = x; }
    public Node(int val, Node left, Node right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
    public void dfs(Node root) {
        if(root == null) return;
        dfs(root.left); // 左
        System.out.println(root.val); // 根
        dfs(root.right); // 右
    }

}
