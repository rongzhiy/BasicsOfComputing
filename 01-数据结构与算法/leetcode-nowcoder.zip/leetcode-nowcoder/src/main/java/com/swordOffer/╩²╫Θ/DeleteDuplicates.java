package com.swordOffer.数组;

public class DeleteDuplicates {
    public static void main(String[] args) {
        int[] nums = {1, 1, 2};
        int res = removeDuplicates(nums);
        System.out.println(res);
    }

    // 26. 删除有序数组中的重复项
    // https://leetcode-cn.com/problems/remove-duplicates-from-sorted-array/
    public static int removeDuplicates(int[] nums) {
        if (nums.length == 0) {
            return 0;
        }
        int slow = 0, fast = 0;
        while (fast < nums.length) {
            if (nums[fast] != nums[slow]) {
                slow++;
                // 维护 nums[0..slow] 无重复
                nums[slow] = nums[fast];
            }
            fast++;
        }
        // 数组长度为索引 + 1
        return slow + 1;
    }
}
