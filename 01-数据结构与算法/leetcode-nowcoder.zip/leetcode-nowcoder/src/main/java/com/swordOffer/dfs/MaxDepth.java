package com.swordOffer.dfs;

public class MaxDepth {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(3);
        TreeNode node1 = new TreeNode(1);
        root.left = node1;
        TreeNode node2 = new TreeNode(4);
        root.right = node2;
        TreeNode node3 = new TreeNode(2);
        node1.right = node3;
        int res = maxDepth(root);
        System.out.println("回溯法 = " + res);

        int res2 = maxDepth2(root);
        System.out.println("动态规划 = " + res2);
    }

    // 剑指 Offer 55 - I. 二叉树的深度
    static int depth = 0;
    static int res = 0;
    public static int maxDepth(TreeNode root) {  //回溯算法
        if(root == null) {
            return 0;
        }
        dfs(root);
        return res;
    }
    static void dfs(TreeNode root) {
        if(root == null) {
            return;
        }
        // 前序遍历位置
        depth++;
        // 记录最大深度
        res = Math.max(res, depth);
        dfs(root.left);
        dfs(root.right);
        // 后序遍历位置
        depth--;
    }

    // 动态规划思路
    public static int maxDepth2(TreeNode root) {
        if(root == null) {  //递归终止条件
            return 0;
        }
        return Math.max(maxDepth2(root.left), maxDepth2(root.right)) + 1;
    }
}
