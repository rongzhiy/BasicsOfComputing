package com.swordOffer.sort;

import java.util.PriorityQueue;

public class LeastKSmallest {
    public static void main(String[] args) {
        int[] arr = {3, 2, 1};
        int k = 2;
        int[] res = getLeastNumbers(arr, k);
        for (int i : res) {
            System.out.println("i = " + i);
        }
    }

    // 剑指 Offer 40. 最小的k个数
    public static int[] getLeastNumbers(int[] arr, int k) {
        // 大顶堆，堆顶是最大元素
        PriorityQueue<Integer> pq = new PriorityQueue<>((a, b) -> {
            return b - a;
        });
//        PriorityQueue默认是小顶堆，实现大顶堆需要重写一下比较器。比如：
//        (a, b) -> {
//            return b - a;
//        }的意思是，如果a > b，返回一个正数，那么a就会被排在b的后面，这样就实现了大顶堆。
//        如果a < b，返回一个负数，那么a就会被排在b的前面，这样就实现了小顶堆。

        for (int e : arr) {
            // 每个元素都要过一遍二叉堆
            pq.offer(e);
            // 堆中元素多于 k 个时，删除堆顶元素
            if (pq.size() > k) {
                pq.poll();
            }
        }
        // pq 中剩下的是 arr 中最小的 k 个元素
        int[] res = new int[k];
        int i = 0;
        while (!pq.isEmpty()) {
            res[i] = pq.poll();
            i++;
        }
        return res;
    }


}
