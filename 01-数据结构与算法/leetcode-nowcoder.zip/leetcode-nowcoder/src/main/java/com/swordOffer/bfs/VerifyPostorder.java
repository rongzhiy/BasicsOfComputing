package com.swordOffer.bfs;

public class VerifyPostorder {
    public static void main(String[] args) {
        int[] postorder = {1, 6, 3, 2, 5};
        boolean res = verifyPostorder(postorder);
        System.out.println(res);
    }

    // 剑指 Offer 33. 二叉搜索树的后序遍历序列
    // 分解问题的思路，递归
    public static boolean verifyPostorder(int[] postorder) {
        return recur(postorder, 0, postorder.length - 1);
    }

    //定义：检查postorder[i,j]是否是一个合法的BST的后序遍历
    private static boolean recur(int[] postorder, int i, int j) {
        if (i >= j) {
            return true;
        }
        // 根节点的值是后序遍历结果的最后一个元素
        int root = postorder[j];
        // postorder[i..left) 是左子树，应该都小于 root
        int left = i;
        while (left < j && postorder[left] < root) {
            left++;
        }
        // postorder[left..j) 是右子树，应该都大于 root
        int right = left;
        while (right < j && postorder[right] > root) {
            right++;
        }
        if (right != j) {    // 右子树中有小于 root 的元素，不符合 BST 定义
            return false;
        }
        // 递归检查左右子树是否符合 BST 定义
        return recur(postorder, i, left - 1) && recur(postorder, left, j - 1);
    }
}
