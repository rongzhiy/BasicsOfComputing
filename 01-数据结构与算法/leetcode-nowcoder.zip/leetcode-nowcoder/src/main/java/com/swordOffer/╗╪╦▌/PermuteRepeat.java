package com.swordOffer.回溯;

import java.util.LinkedList;
import java.util.List;

public class PermuteRepeat {

public static void main(String[] args) {
        PermuteRepeat permuteRepeat = new PermuteRepeat();
        int[] nums = {1, 2, 3};
        List<List<Integer>> permuteRepeat1 = permuteRepeat.permuteRepeat(nums);
        System.out.println("permuteRepeat1 = " + permuteRepeat1);
    }

    List<List<Integer>> res = new LinkedList<>();
    LinkedList<Integer> track = new LinkedList<>();

    public List<List<Integer>> permuteRepeat(int[] nums) {
        backtrack(nums);
        return res;
    }

    // 回溯算法核心函数
    void backtrack(int[] nums) {
        // base case，到达叶子节点
        if (track.size() == nums.length) {
            // 收集叶子节点上的值
            res.add(new LinkedList(track));
            return;
        }

        // 回溯算法标准框架
        for (int i = 0; i < nums.length; i++) {
            // 做选择
            track.add(nums[i]);
            // 进入下一层回溯树
            backtrack(nums);
            // 取消选择
            track.removeLast();
        }
    }
}
