package com.swordOffer.hash;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class TinyURL {

    // 剑指 Offer 535. TinyURL 的加密与解密
//    链接：https://leetcode-cn.com/problems/encode-and-decode-tinyurl/

    public static void main(String[] args) {
        TinyURL tinyURL = new TinyURL();
        String longUrl = "https://leetcode.com/problems/design-tinyurl";
        String shortUrl = tinyURL.encode(longUrl);
        System.out.println(shortUrl);
        System.out.println(tinyURL.decode(shortUrl));
    }
    Map<String, String> origin2Tiny = new HashMap<>(), tiny2Origin = new HashMap<>();
    String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    String prefix = "https://rongzhiy.github.io/";
    int k = 6;
    Random random = new Random();
    public String encode(String longUrl) {
        while (!origin2Tiny.containsKey(longUrl)) {
            char[] cs = new char[k];
            for (int i = 0; i < k; i++) {
                cs[i] = str.charAt(random.nextInt(str.length()));   // 生成随机字符串
            }
            String cur = prefix + String.valueOf(cs);
            if (tiny2Origin.containsKey(cur)) {  // 如果已经存在，重新生成
                continue;
            }
            tiny2Origin.put(cur, longUrl);
            origin2Tiny.put(longUrl, cur);
        }
        return origin2Tiny.get(longUrl);
    }
    public String decode(String shortUrl) {
        return tiny2Origin.get(shortUrl);
    }



}
