package com.swordOffer.二叉树;

import com.swordOffer.dfs.TreeNode;

public class PostOrderTraverse {
    public static void main(String[] args) {
        TreeNode root = new TreeNode(1);
        TreeNode node1 = new TreeNode(4);
        TreeNode node2 = new TreeNode(2);
        TreeNode node3 = new TreeNode(3);
        TreeNode node4 = new TreeNode(5);

        root.left = node1;
        root.right = node2;
        node2.left = node3;
        node2.right = node4;

        postOrderTraverse(root);
    }

    // 二叉树的后序遍历
    // https://leetcode-cn.com/problems/binary-tree-postorder-traversal/
    public static void postOrderTraverse(TreeNode root) {
        if (root == null) {
            return;
        }

        postOrderTraverse(root.left);
        postOrderTraverse(root.right);
        System.out.println(root.val);
    }
}
