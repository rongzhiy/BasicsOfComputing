package com.swordOffer.sort;

import java.util.Arrays;

public class MinNumber {
    public static void main(String[] args) {
        int[] nums = {3, 30, 34, 5, 9};
        String res = minNumber(nums);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 45. 把数组排成最小的数
    // 179. 最大数
    public static String minNumber(int[] nums){
        int n = nums.length;
        String[] strs = new String[n];
        for (int i = 0; i < n; i++) {
            strs[i] = String.valueOf(nums[i]);
        }
        //看那种拼接方式得到的数字更小，就把它放在前面
        //不用转成int，直接比较字符串大小即可，因为字符串的比较规则就是按照字典序
        // 而且拼接字符串比较长，所以不用担心溢出
        Arrays.sort(strs, (x, y) -> (x + y).compareTo(y + x));
        return String.join("", strs);
    }
}
