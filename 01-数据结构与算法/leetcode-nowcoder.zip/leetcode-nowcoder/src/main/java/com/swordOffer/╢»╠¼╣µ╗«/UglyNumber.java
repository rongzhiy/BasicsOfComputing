package com.swordOffer.动态规划;

public class UglyNumber {
    public static void main(String[] args) {
        int n = 10;
        int res = uglyNumber(n);
        System.out.println("res = " + res);

    }

    // 剑指 Offer 49. 丑数
    public static int uglyNumber(int n) {
        int p2 = 1, p3 = 1, p5 = 1;  //三个指向有序链表头结点的指针
        int profuct2 = 1, profuct3 = 1, profuct5 = 1; // 三个有序链表的头结点
        int[] ugly = new int[n + 1];  // 用于存放丑数的数组
        int p = 1;  // 用于指向有序链表的第一个结点

        while (p <= n) { //开始合并是哪个有序链表
            int min = Math.min(Math.min(profuct2, profuct3), profuct5); // 三个有序链表头结点中的最小值
            ugly[p] = min; // 将最小值加入丑数数组
            if (min == profuct2) {    // 如果最小值是链表2的头结点，将头结点后移
                profuct2 = 2 * ugly[p2];
                p2++;
            }
            if (min == profuct3) {    // 如果最小值是链表3的头结点，将头结点后移
                profuct3 = 3 * ugly[p3];
                p3++;
            }
            if (min == profuct5) {    // 如果最小值是链表5的头结点，将头结点后移
                profuct5 = 5 * ugly[p5];
                p5++;
            }
            p++;
        }
        return ugly[n];
    }
}
