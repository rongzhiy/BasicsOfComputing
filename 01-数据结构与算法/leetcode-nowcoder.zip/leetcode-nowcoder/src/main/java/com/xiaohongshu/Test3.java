package com.xiaohongshu;
// 4 4 8  景点；路线；时间总和
// 4 3 2 1  价值
// 1 2 3 4  时间
// 1 2 1    第一条路线u-v,花费时间w
// 2 3 1
// 2 4 1
// 3 4 1

// 输出
// 9  18
import java.util.*;

public class Test3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt(); // 景点数量
        int m = scanner.nextInt(); // 路线数量
        int t = scanner.nextInt(); // 时间总和

        int[] value = new int[n];
        for (int i = 0; i < n; i++) {
            value[i] = scanner.nextInt(); // 景点价值
        }

        int[] time = new int[n];
        for (int i = 0; i < n; i++) {
            time[i] = scanner.nextInt(); // 景点所需时间
        }

        int[][] graph = new int[n][n]; // 路线图
        for (int i = 0; i < m; i++) {
            int u = scanner.nextInt();
            int v = scanner.nextInt();
            int w = scanner.nextInt();
            graph[u - 1][v - 1] = w;
        }

        int[][] dp = new int[t + 1][n]; // dp数组
        for (int i = 0; i <= t; i++) {
            for (int j = 0; j < n; j++) {
                dp[i][j] = -1;
            }
        }

        for (int i = 0; i <= t; i++) {
            for (int j = 0; j < n; j++) {
                if (i == 0) {
                    dp[i][j] = 0;
                } else {
                    for (int k = 0; k < n; k++) {
                        if (graph[k][j] != 0 && i - time[j] >= 0 && dp[i - time[j]][k] != -1) {
                            dp[i][j] = Math.max(dp[i][j], dp[i - time[j]][k] + value[j]);
                        }
                    }
                }
            }
        }

        int maxVal = 0;
        for (int i = 0; i <= t; i++) {
            for (int j = 0; j < n; j++) {
                maxVal = Math.max(maxVal, dp[i][j]);
            }
        }

        System.out.println(maxVal);
    }
}
