package com.xiaohongshu;

import java.util.*;

// https://codefun2000.com/p/P1429

public class Main1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        scanner.nextLine(); // 读取换行符

        Map<String, Integer> wordCount = new LinkedHashMap<>(); // 使用 LinkedHashMap 保持输入顺序

        for (int i = 0; i < n; i++) {
            String word = scanner.nextLine();
            wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
        }

        List<String> keywords = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
            if (entry.getValue() >= 3) {
                keywords.add(entry.getKey());
            }
        }

//        System.out.println(keywords.size());
        for (String keyword : keywords) {
            System.out.println(keyword);
        }
    }
}
