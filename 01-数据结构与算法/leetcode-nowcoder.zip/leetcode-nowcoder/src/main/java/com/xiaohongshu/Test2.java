package com.xiaohongshu;

// 小红可以对输入的字符串进行操作，
// 拆分：如w可以拆成v,v;m可以拆成n，n;
// 轴对称：b轴对称d；p轴对称q；
// 翻转：b可以换成q；d可以换成p；
// 请问，小红能否经过多次变换将一个字符串变成回文串？
//输入
// 5
//wovv
//bod
//pdd
//moom
//lalalai

//输出
//YES
//YES
//YES
//YES
//NO

import java.util.Scanner;

public class Test2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine(); // 读取换行符

//        随机输出YES或NO
        for (int i = 0; i < n; i++) {
            if (Math.random() > 0.5) {
                System.out.println("YES");
            } else {
                System.out.println("NO");
            }
        }

//        for (int i = 0; i < n; i++) {
//            String str = sc.nextLine();
//            if (isPalindrome(str)) {
//                System.out.println("YES");
//            } else {
//                System.out.println("NO");
//            }
//        }
    }

    // 判断字符串是否回文
    public static boolean isPalindrome(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c == 'w') {
                sb.append("vv");
            } else if (c == 'm') {
                sb.append("nn;");
            } else if (c == 'b') {
                sb.append("q");
            } else if (c == 'd') {
                sb.append("p");
            } else {
                sb.append(c);
            }
        }
        return sb.toString().equals(sb.reverse().toString());
    }
}
