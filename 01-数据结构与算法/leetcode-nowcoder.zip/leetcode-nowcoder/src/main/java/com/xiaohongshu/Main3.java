package com.xiaohongshu;

// https://codefun2000.com/p/P1431
//思路：动态规划
//        1. 创建一个长度为n的数组dp，dp[i]表示以第i个节点为根节点能染红的最大节点数；
//        2. 遍历每个节点i，计算以节点i为根节点能染红的最大节点数：
//        - 如果节点i为叶子节点（即没有子节点），则dp[i]为0；
//        - 否则，遍历节点i的所有子节点j，计算以节点j为根节点能染红的最大节点数，累加到dp[i]；
//        3. 遍历dp数组，找到其中的最大值，即为最多可以染红的节点数；
//        4. 输出最多可以染红的节点数。

import java.util.*;

public class Main3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] weights = new int[n];
        for (int i = 0; i < n; i++) {
            weights[i] = scanner.nextInt();
        }
        List<List<Integer>> graph = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            graph.add(new ArrayList<>());
        }
        for (int i = 0; i < n - 1; i++) {
            int u = scanner.nextInt() - 1;
            int v = scanner.nextInt() - 1;
            graph.get(u).add(v);
            graph.get(v).add(u);
        }

        int[] dp = new int[n];
        dfs(graph, weights, dp, 0, -1);

        int maxRedNodes = 0;
        for (int i = 0; i < n; i++) {
            maxRedNodes = Math.max(maxRedNodes, dp[i]);
        }
        System.out.println(maxRedNodes);
    }

    private static void dfs(List<List<Integer>> graph, int[] weights, int[] dp, int node, int parent) {
        dp[node] = 0;
        for (int child : graph.get(node)) {
            if (child != parent) {
                dfs(graph, weights, dp, child, node);
                if (isPrime(weights[child] + weights[node])) {
                    dp[node] += dp[child] + 1;
                }
            }
        }
    }

    private static boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
