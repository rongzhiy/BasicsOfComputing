package com.xiaohongshu;

// https://codefun2000.com/p/P1430

//思路：这是一个背包问题，可以使用动态规划来解决。创建一个二维数组dp，其中dp[i][j]表示在花费总时间不超过i且花费总精力不超过j的情况下，最大的快乐值。
//
//        具体步骤：
//        1. 创建一个二维数组dp，大小为(T+1) x (H+1)，初始化为0。
//        2. 遍历事件，对于每个事件，更新dp数组。假设当前事件的时间为ti，精力为hi，快乐值为ai，遍历dp数组，如果当前位置的时间和精力加上ti和hi不超过T和H，则更新dp[i+ti][j+hi]为dp[i][j] + ai和当前位置的值中的较大值。
//        3. 遍历dp数组的最后一行和最后一列，找到其中的最大值作为结果，即塔子哥最多的快乐值。
//
//        代码实现如下：

import java.util.*;

public class Main2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int T = scanner.nextInt();
        int H = scanner.nextInt();

        int[][] events = new int[n][3];
        for (int i = 0; i < n; i++) {
            events[i][0] = scanner.nextInt(); // 时间
            events[i][1] = scanner.nextInt(); // 精力
            events[i][2] = scanner.nextInt(); // 快乐值
        }

        int[][] dp = new int[T + 1][H + 1];

        for (int i = 0; i < n; i++) {
            int t = events[i][0];
            int h = events[i][1];
            int a = events[i][2];

            for (int j = T; j >= t; j--) {
                for (int k = H; k >= h; k--) {
                    dp[j][k] = Math.max(dp[j][k], dp[j - t][k - h] + a);
                }
            }
        }

        int maxHappiness = 0;
        for (int j = 0; j <= T; j++) {
            for (int k = 0; k <= H; k++) {
                maxHappiness = Math.max(maxHappiness, dp[j][k]);
            }
        }

        System.out.println(maxHappiness);
    }
}
