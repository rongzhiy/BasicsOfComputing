package com.xiaohongshu;


//小红记单词
//输入：
// 5
//        you
//        thank
//        queue
//        queue
//        thank
//输出：2
//        说明：小红记住了you和queue两个单词，所以输出2。因为you首先出现，小红记住了，又因为背了两次queue，所以只记住一个queue，所以输出2。thank虽然出现了两次，但是没有queue的次数多
//        ，所以不记，所以输出2。后一个出现的单词次数必须比前一个单词出现的次数多，才能记住。
//小红记单词，第一行是一个整数n，表示小红记住的单词数。
//        接下来n行，每行一个单词，表示小红记住的单词。
//        输出小红记住的单词数。
import java.util.Scanner;
import java.util.*;
public class Test1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        scanner.nextLine();

        Map<String, Integer> wordCount = new LinkedHashMap<>();

        for (int i = 0; i < n; i++) {
            String word = scanner.nextLine();
            if (wordCount.containsKey(word)) {
                wordCount.put(word, wordCount.get(word) + 1);
            } else {
                wordCount.put(word, 1);
            }
        }

        int rememberCount = 0;
        int count = 0;
        for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {

            if (entry.getValue() > count) {
                count = entry.getValue();
                rememberCount++;
            }else{
                break;//如果后一个出现的单词次数比前一个单词出现的次数少，就不记住
            }

        }

        System.out.println(rememberCount);
    }
}






