package com.xunfei;
import java.util.Scanner;


public class Main1 {
    public static void main(String[] args) {
        //小红认为一个排列是优美的当且仅当对于任意的1≤i≤n，都满足a[a1] = n - a1 + 1;
        //输入描述:
        //一个整数n,表示排列的长度。
        //输出描述:
        //一行n个整数，表示字典序最大的优美排列。
        //输入例子1:
        //2
        //输出:
        //2 1

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        int[] res = new int[n];
        for(int i = 0; i < n; i++) {
            arr[i] = i + 1;
        }
        for(int i = 0; i < n; i++) {
            res[i] = arr[n - i - 1];
        }
        for(int i = 0; i < n; i++) {
            System.out.print(res[i] + " ");
        }



    }
}
