package com.xunfei;

import java.util.Scanner;

public class Main2 {
    /**
     * https://codefun2000.com/p/P1450
     * 输入
     * 5 2
     * abcca
     * 输出
     * 2
     */

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int k = sc.nextInt();
        String s = sc.next();
//        解题思路：sum = k - (s.charAt(i + 1) - s.charAt(i));  循环n-1次，如果sum<0,则输出-1，否则输出sum

        int sum = k;
        for (int i = 0; i < n - 1; i++) {
            int diff = s.charAt(i + 1) - s.charAt(i);
            sum -= diff;
            if (sum < 0) {
                System.out.println(-1);
                return;
            }
        }

        System.out.println(sum);
    }


}


