package com.xunfei;

import java.util.*;

/**
 * https://codefun2000.com/p/P1451
 */

public class Main3 {
    static int maxLength = 2 * 100005;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }
        int[] b = new int[n];
        for (int i = 0; i < n; i++) {
            b[i] = sc.nextInt();
        }
        long count = generateSubsets(a) + generateSubsets(b);
        System.out.println(count);
    }

    static long generateSubsets(int[] nums) {
        return backtrack(nums, "", new HashSet<>());
    }

    static long backtrack(int[] nums, String current, HashSet<String> set) {
        if (nums == null || nums.length == 0) {
            return 0;
        }
        if (nums.length == 1) {
            return set.add(current) ? 1 : 0;
        }
        long count = 0;
        for (int i = 0; i < nums.length; i++) {
            count += backtrack(Arrays.copyOfRange(nums, 1, nums.length), current + nums[0], set);
            nums[0] = nums[i]; // restore the array for the next iteration
        }
        return count;
    }
}
