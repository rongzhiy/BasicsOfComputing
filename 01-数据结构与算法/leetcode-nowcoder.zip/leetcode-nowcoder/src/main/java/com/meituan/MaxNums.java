package com.meituan;
//
//小美有一个长度为 n 的数组，她最多可以进行 k 次操作，每次操作如下：
//        1. 选择两个整数 i, j(1 \leq i < j \leq n)
//        2. 选择两个整数 x, y，使得 x \times y = a_i \times a_j
//        3. 将 a_i 替换为 x，将 a_j 替换为 y
//
//        她希望最多进行 k 次操作之后，最后数组中的元素的总和尽可能大。
//输入
//复制
//5 2
//1 2 3 4 5
//输出
//复制
//65
//说明
//第一次操作后，数组变为 [1, 2, 12, 1, 5]
//第二次操作，数组变为 [1, 2, 60, 1, 1]
//输出一个整数，表示最后数组中的元素的总和的最大值，由于答案可能很大，你只需要输出答案对 10^9 + 7 取模的结果。


import java.util.Arrays;
import java.util.Scanner;

public class MaxNums {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt();
        int k = scanner.nextInt();

        int[] array = new int[n];
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }
//排序
        Arrays.sort(array);

        for (int i = 0; i < k; i++) {
            // 找到array[i]中的左侧中位数，然后用(array[i]+array[i+1])和1分别替换array[i]和array[i+1]，
            int mid = array[(n / 2) - 1];
            int temp = 0;
            for (int j = mid; j < n - 1; j++) {
                temp = array[mid] * array[j + 1];
                array[mid] = temp;
                array[j + 1] = 1;
            }
        }
//        最后求和
        long sum = 0;
        for (int i = 0; i < n; i++) {
            sum += array[i];
        }
        System.out.println(sum % ((long) 1e9 + 7));

    }


}
