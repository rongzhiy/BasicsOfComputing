package com.meituan;

import java.util.Scanner;

// 输入三个数 1 2 10
// 输出 6

public class Fruit {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        long x = in.nextLong(); // 1
        long y = in.nextLong(); // 2
        long z = in.nextLong(); // 10
        long sum = 0;
//每一次循环，都加一次x, y第一次加，之后每隔两次加一次，最终和为sum要大于等于z，求最少的次数
        int count = 0;

        while (sum < z) {
            count++;
            if (count % 3 == 1) {
                sum += (x + y);
            } else if (count % 3  == 2 || count % 3 == 0) {
                sum += x;
            }
        }
        System.out.println(count);

    }
}
