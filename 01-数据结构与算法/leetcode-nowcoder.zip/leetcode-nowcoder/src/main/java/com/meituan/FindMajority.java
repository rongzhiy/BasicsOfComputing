package com.meituan;

//实现数组中超过一半次数的数字

//该方法接受一个整型数组作为参数，使用一个计数器和一个候选数字来查找出现次数超过一半的数字。
// 遍历整个数组，如果当前数字等于候选数字，则将计数器加一，否则将计数器减一。当计数器为零时，说明当前数字与候选数字相等，更新候选数字。最后返回候选数字即可。
public class FindMajority {
    public static int findMajority(int[] nums) {
        int count = 0;
        int candidate = -1;
        for (int num : nums) {
            if (count == 0) {
                candidate = num;
            }
            count += (num == candidate) ? 1 : -1;
        }
        return candidate;
    }

    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 2, 2, 2, 5, 4, 2};
        System.out.println(findMajority(nums));
    }
}
