package com.meituan;

import java.util.*;

public class MinOperation {
    //    小美拿到了一个数组，她每次可以进行如下操作：
//    选择两个元素，一个加 1，另一个减 1。
//    小美希望若干次操作后，众数的出现次数尽可能多。你能帮她求出最小的操作次数吗？
//    输入例子：
//            3
//            1 4 4
//    输出例子：
//            2
//    例子说明：
//    第一次操作：第一个数加 1，第二个数减 1。
//    第二次操作：第一个数加 1，第三个数减 1。
//    数组变成[3,3,3]，众数出现了 3 次。
    public static int findMinOperations(int[] nums) {
        if (nums == null || nums.length == 0) {
            return 0;
        }
        Map<Integer, Integer> map = new HashMap<>();
        for (int num : nums) {
            map.put(num, map.getOrDefault(num, 0) + 1);
        }
        int maxCount = Collections.max(map.values());
        int minOps = 0;
        for (int num : map.keySet()) {
            if (map.get(num) == maxCount) {
                minOps += num - 1;
            } else {
                minOps += Math.abs(num - 1) - Math.abs(maxCount - 1);
            }
        }
        return minOps;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int nums[] = new int[n];
        System.out.println(findMinOperations(nums));  // 输出2
    }

}
