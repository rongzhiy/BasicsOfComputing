package com.meituan;

import java.util.Arrays;
import java.util.Scanner;

public class MaxSum {

////    小美有一个长度为n 的数组，她想将这个数组进行求和。小妹可以使用一次魔法（也可以不用），将其中一个加号变成乘号，使得sum最大
//    输入例子：
//            6
//            1 1 4 5 1 4
//    输出例子：
//            27
//    例子说明：
//    小美可以将 4 和 5 之间的加号改成乘号。
//            1 + 1 + 4 * 5 + 1 + 4 = 27

    public static void main(String[] args) {

        Scanner in=new Scanner(System.in);
        int n=in.nextInt();
        long[] a=new long[n];
        long sum=0;
        long maxSum=1;  // 记录最大乘积
        for (int i = 0; i <n ; i++) {
            a[i]=in.nextLong();
            sum+=a[i];
        }
        long maxA = 0, maxB = 0; // 记录最大乘积对应的两个数
        for (int i = 0; i < n-1; i++) { // 遍历数组
            long product = a[i] * a[i+1]; // 计算当前两个数的乘积
            if (maxSum <= product) { // 如果乘积大于等于当前最大乘积
                maxSum = product; // 更新最大乘积
                maxA = a[i]; // 更新最大乘积对应的两个数
                maxB = a[i+1];
            }
        }

        System.out.println(sum-maxA-maxB+maxSum);

    }




}




