package com.meituan;

import java.util.Scanner;

//给定n个正整数组成的数据，求平均数正好等于k的最长连续子数组的长度
//5 2
//        1 3 2 4 1

//输出 3
public class SubArray {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
//        int nums[] = new int[n]; 数组越界怎么解决
        long nums[] = new long[n];
        for (int i = 0; i < n; i++) {
            nums[i] = sc.nextInt();
        }
        System.out.println(subArray(nums, k));
    }

    private static int subArray(long[] nums, int k) {
        if (nums.length == 0) {
            return -1;
        }
        int left = 0, right = 0;
        int sum = 0;
        int maxLength = 0;

        while (right < nums.length) {
//            当前窗口内元素的个数 = right - left + 1
            int curLength = right - left + 1;
            sum += nums[right];
            while (sum > k *curLength) {
                sum -= nums[left];
                left++;
            }
            if (sum == k* curLength) {
                maxLength = Math.max(maxLength, right - left + 1);
            }
            right++;
        }
        return maxLength == 0 ? -1 : maxLength;

    }

}
