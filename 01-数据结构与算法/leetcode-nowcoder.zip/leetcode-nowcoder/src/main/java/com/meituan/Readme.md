笔试题：

https://www.nowcoder.com/discuss/385481735067250688?sourceSSR=search


https://www.nowcoder.com/discuss/393151670480371712?sourceSSR=search


https://www.nowcoder.com/discuss/353157724085100544?sourceSSR=search


https://www.nowcoder.com/feed/main/detail/dab21a3b704f49ae9607ac3d83351b4b


面试题：

https://www.nowcoder.com/discuss/486526259665666048?sourceSSR=search



美团。京东。科大讯飞
https://www.nowcoder.com/discuss/518766082384019456


# 美团面试
美团面试时可以说一下美团技术团队博客和github账号，自己又看团队的NLP文本分类的文章（说一说自己的实验，像处理自然语言一样处理网络流量），还有安卓相关知识的一些博客。


