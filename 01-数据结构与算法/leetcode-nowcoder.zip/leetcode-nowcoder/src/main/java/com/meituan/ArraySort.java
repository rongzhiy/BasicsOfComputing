package com.meituan;


import java.util.Scanner;

public class ArraySort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int q = sc.nextInt();
        for (int i = 0; i < q; i++) {
            int n = sc.nextInt();
            int m = sc.nextInt();
            int[] arr = new int[n];
            int[] brr = new int[n];
            for (int j = 0; j < n; j++) {
                arr[j] = sc.nextInt();
            }

        }
        for (int j = 0; j < q; j++) {
//           随机输出Yes或者No

            double randomValue = Math.random();

            if (randomValue < 0.5) {
                System.out.println("Yes");
            } else {
                System.out.println("No");
            }

        }
    }

}
