package com.nowcoder.array;

public class MinArray {
    public static void main(String[] args) {
        int[] numbers = {3, 4, 5, 1, 2};
        int res = minArray(numbers);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 11. 旋转数组的最小数字
    // 二分查找

    public static int minArray(int[] numbers){
        int low = 0, high = numbers.length - 1;
        while(low < high){
            int pivot = low + (high - low) / 2;
            if(numbers[pivot] < numbers[high]){  // 右边有序，最小值在左边
                high = pivot;
            }else if(numbers[pivot] > numbers[high]){  // 左边有序，最小值在右边
                low = pivot + 1;
            }else{      // 无法判断，缩小范围
                high -= 1;
            }
        }
        return numbers[low];
    }
}
