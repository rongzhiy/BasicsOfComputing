package com.nowcoder.array;

public class myPow {
    public static void main(String[] args) {
        double x = 2.00000;
        int n = 10;
        double res = myPow(x, n);
        System.out.println("res = " + res);
        System.out.println("Math.pow(x, n) = " + Math.pow(x, n));
    }

    // 剑指offer 16. 数值的整数次方
    // 快速幂 + 递归
    public static double myPow(double a, int k) {
        if (k == 0) return 1;

        if (k == Integer.MIN_VALUE) {
            // 把 k 是 INT_MIN 的情况单独拿出来处理
            // 避免 -k 整型溢出
            return myPow(1 / a, -(k + 1)) / a;
        }

        if (k < 0) {
            return myPow(1 / a, -k);
        }

        if (k % 2 == 1) {
            // k 是奇数
            return (a * myPow(a, k - 1));
        } else {
            // k 是偶数
            double sub = myPow(a, k / 2);
            return (sub * sub);
        }
    }


}
