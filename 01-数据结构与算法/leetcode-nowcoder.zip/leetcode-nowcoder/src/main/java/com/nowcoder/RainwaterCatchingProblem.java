package com.nowcoder;

public class RainwaterCatchingProblem {
    /**
     * @param heights: an array of integers
     * @return: a integer
     */
    public int trapRainWater(int[] heights) {
        // write your code here
        if (heights == null || heights.length == 0) {
            return 0;
        }
        int left = 0;
        int right = heights.length - 1;
        int leftMax = 0; // 左边最大值
        int rightMax = 0;   // 右边最大值
        int result = 0;
        while (left < right) {
            if (heights[left] < heights[right]) { //左边小于右边
                if (heights[left] >= leftMax) { //如果左边大于左边最大值
                    leftMax = heights[left];    //更新左边最大值
                } else {
                    result += leftMax - heights[left];  //如果左边小于左边最大值，那么就可以接到雨水
                }
                left++;
            } else {    //右边小于左边
                if (heights[right] >= rightMax) {   //如果右边大于右边最大值
                    rightMax = heights[right];  //更新右边最大值
                } else {
                    result += rightMax - heights[right];    //如果右边小于右边最大值，那么就可以接到雨水
                }
                right--;    //右边指针左移
            }
        }
        return result;
    }

    //    测试
    public static void main(String[] args) {
        RainwaterCatchingProblem rainwaterCatchingProblem = new RainwaterCatchingProblem();
        int[] heights = {3,1,2,5,2,4};
        int result = rainwaterCatchingProblem.trapRainWater(heights);
        System.out.println(result);
    }
}
