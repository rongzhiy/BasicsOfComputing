package com.nowcoder.array;

import java.util.Arrays;

public class MinPathSum {
    public static void main(String[] args) {
        int[][] grid = {{1, 2, 3}, {4, 5, 6}};
        int res = minPathSum(grid);
        System.out.println("res = " + res);
    }

    // 64. 最小路径和
//    dp 函数的定义：从左上角位置 (0, 0) 走到位置 (i, j) 的最小路径和为 dp(grid, i, j)。
//    这样，dp(grid, i, j) 的值由 dp(grid, i - 1, j) 和 dp(grid, i, j - 1) 的值转移而来：
//    dp(grid, i, j) = Math.min(
//    dp(grid, i - 1, j),
//    dp(grid, i, j - 1)
//) + grid[i][j];
    static int[][] memo;

    public static int minPathSum(int[][] grid) {
        int m = grid.length;
        int n = grid[0].length;
        // 构造备忘录，初始值全部设为 -1
        memo = new int[m][n];
        for (int[] row : memo)
            Arrays.fill(row, -1);

        return dp(grid, m - 1, n - 1);
    }

    static int dp(int[][] grid, int i, int j) {
        // base case
        if (i == 0 && j == 0) {
            return grid[0][0];
        }
        if (i < 0 || j < 0) {
            return Integer.MAX_VALUE;
        }
        // 避免重复计算
        if (memo[i][j] != -1) {
            return memo[i][j];
        }
        // 将计算结果记入备忘录
        memo[i][j] = Math.min(
                dp(grid, i - 1, j),
                dp(grid, i, j - 1)
        ) + grid[i][j];

        return memo[i][j];
    }
}
