package com.nowcoder;

public class ReverseString {
    /**
     * @param str: A string
     * @return: the string after reversing
     */
    public String reverseString(String str) {
        // write your code here
        if (str == null || str.length() == 0) {
            return "";
        }
        char[] chars = str.toCharArray();
        int i = 0;
        int j = chars.length - 1;
        while (i < j) {
            char temp = chars[i];
            chars[i] = chars[j];
            chars[j] = temp;
            i++;
            j--;
        }
        return new String(chars);
    }

    //    测试
    public static void main(String[] args) {
        ReverseString reverseString = new ReverseString();
        String s = reverseString.reverseString("hello");
        System.out.println(s);
    }
}
