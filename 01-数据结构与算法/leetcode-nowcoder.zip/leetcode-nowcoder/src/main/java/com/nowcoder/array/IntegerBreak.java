package com.nowcoder.array;

public class IntegerBreak {
    public static void main(String[] args) {
        int n = 2;
        int res = integerBreak(n);
        System.out.println("res = " + res);
    }
    // 343. 整数拆分
    // 动态规划   状态转移方程   2 <= n <= 58
    public static int integerBreak(int n){
        int[] dp = new int[n + 1];
        dp[2] = 1;
        for (int i = 3; i < n + 1; i++) {
            for (int j = 1; j < i - 1; j++) {
                // j * (i - j) 代表拆分成两个数
                // j * dp[i - j] 代表拆分成多个数
                dp[i] = Math.max(dp[i], Math.max(j * (i - j), j * dp[i - j]));
            }
        }
        return dp[n];
    }
}
