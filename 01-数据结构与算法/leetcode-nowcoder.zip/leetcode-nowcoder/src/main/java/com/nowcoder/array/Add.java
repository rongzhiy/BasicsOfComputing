package com.nowcoder.array;

public class Add {
    public static void main(String[] args) {
        int a = 1;
        int b = 3;
        int res = add(a, b);
        System.out.println(res);
    }

    // 剑指 Offer 65. 不用加减乘除做加法
    // 位运算
    public static int add(int a, int b){
        if(a == 0 || b == 0) {
            return a == 0 ? b : a;
        }
        // 设 a = 1001
        // 设 b = 0101
        // 求和 1100
        int sum = a ^ b;        //异或运算可以理解为对应位相加，不考虑进位
        // 进位 0001 << 1 = 0010
        int carry = (a & b) << 1;   //与运算可以理解为对应位相加，只考虑进位
        // add(1100, 0010)
        return add(sum, carry);    //递归求和，直到进位为 0
    }
}
