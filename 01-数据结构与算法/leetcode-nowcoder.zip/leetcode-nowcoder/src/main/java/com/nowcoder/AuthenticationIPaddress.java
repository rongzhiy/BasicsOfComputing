package com.nowcoder;

public class AuthenticationIPaddress {
    /**
     * @param ip: the ip
     * @return: output the type of ip address after authentication
     * 输入：
     * "172.16.254.1"
     * 返回值：
     * "IPv4"
     * 说明：
     * 这是一个有效的 IPv4 地址, 所以返回 "IPv4"
     * step 1：写一个split函数（或者内置函数）。
     * step 2：遍历IP字符串，遇到.或者:将其分开储存在一个数组中。
     * step 3：遍历数组，对于IPv4，需要依次验证分组为4，分割不能缺省，没有前缀0或者其他字符，数字在0-255范围内。
     * step 4：对于IPv6，需要依次验证分组为8，分割不能缺省，每组不能超过4位，不能出现除数字小大写a-f以外的字符。
     */
    public String validIPAddress(String ip) {
        // write your code here
        if (ip == null || ip.length() == 0) {
            return "Neither";
        }
        if (ip.contains(".")) {
            return validIPv4(ip);
        } else if (ip.contains(":")) {
            return validIPv6(ip);
        } else {
            return "Neither";
        }
    }

    private String validIPv6(String ip) {
//        验证IPv6
        String[] ips = ip.split(":", -1); // -1表示不忽略空字符串
        if (ips.length != 8) {
            return "Neither";
        }
        String hexdigits = "0123456789abcdefABCDEF";
        for (String s : ips) {
            if (s.length() == 0 || s.length() > 4) {
                return "Neither";
            }
            for (char c : s.toCharArray()) {
                if (hexdigits.indexOf(c) == -1) {
                    return "Neither";
                }
            }
        }
        return "IPv6";
    }

    private String validIPv4(String ip) {
//        验证IPv4
        String[] ips = ip.split("\\.",-1); //转义字符\\.中 \.表示匹配. \代表转义
        if (ips.length != 4) {
            return "Neither";
        }
        for (String s : ips) { //遍历数组
            if (s.length() == 0 || s.length() > 3) {
                return "Neither";
            }
            if (s.charAt(0) == '0') {
                return "Neither";
            }
            for (char c : s.toCharArray()) {
                if (!Character.isDigit(c)) {
                    return "Neither";
                }
            }
            if (Integer.parseInt(s) > 255) {
                return "Neither";
            }
        }
        return "IPv4";
    }

    public static void main(String[] args) {
        AuthenticationIPaddress authenticationIPaddress = new AuthenticationIPaddress();
        String s1 = authenticationIPaddress.validIPAddress("2001:0db8:85a3:0:0:8A2E:0370:7334:");
        System.out.println(s1);
        String s2 = authenticationIPaddress.validIPAddress("172.16.254.1");
        System.out.println(s2);
        String s3 = authenticationIPaddress.validIPAddress("256.256.256.256");
        System.out.println(s3);
    }
}
