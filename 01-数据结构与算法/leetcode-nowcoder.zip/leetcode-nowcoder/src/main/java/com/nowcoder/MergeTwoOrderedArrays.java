package com.nowcoder;

public class MergeTwoOrderedArrays {
    /**
     * @param A: sorted integer array A which has m elements, but size of A is m+n
     * @param B: sorted integer array B which has n elements
     * @return: void
     */

    public void merge(int A[], int m, int B[], int n) {
        //指向数组A的结尾
        int i = m - 1;
        //指向数组B的结尾
        int j = n - 1;
        //指向数组A空间的结尾处
        int k = m + n - 1;
        //从两个数组最大的元素开始，直到某一个数组遍历完
        while (i >= 0 && j >= 0) {
            //将较大的元素放到最后
            if (A[i] > B[j])
                A[k--] = A[i--];
            else
                A[k--] = B[j--];
        }
        //数组A遍历完了，数组B还有，则还需要添加到数组A前面
        if (i < 0) {
            while (j >= 0)
                A[k--] = B[j--];
        }
        //数组B遍历完了，数组A前面正好有，不用再添加
    }
//    测试
    public static void main(String[] args) {
        int[] A = {1, 4, 3, 0, 0, 0};
        int[] B = {2, 5, 6};
        MergeTwoOrderedArrays mergeTwoOrderedArrays = new MergeTwoOrderedArrays();
        mergeTwoOrderedArrays.merge(A, 3, B, 3);
        for (int i = 0; i < A.length; i++) {
            System.out.println(A[i]);
        }
    }

}
