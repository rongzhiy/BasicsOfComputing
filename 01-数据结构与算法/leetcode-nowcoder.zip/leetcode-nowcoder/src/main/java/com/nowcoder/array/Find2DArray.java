package com.nowcoder.array;

public class Find2DArray {
    public static void main(String[] args) {
        //剑指 Offer 04. 二维数组中的查找
//        int[][] matrix = {{1,2,3},{4,5,6},{7,9,10}};
        int[][] matrix = {};
        int target = 9;
        System.out.println(findNumberIn2DArray(matrix, target));

        int[][] matrix1 = {{1,2,3},{4,5,6},{7,9,10}};
        int target1 = 9;
        System.out.println(findNumberViolence(matrix1, target1));

    }

    // 剑指 Offer 04. 二维数组中的查找
    public static boolean findNumberIn2DArray(int[][] matrix, int target) {
        int row = 0 , col = 0;
        if(matrix.length == 0 || matrix[0].length == 0) {  //注意空数组的判断
            return false;
        } else {
            row = matrix.length;
            col = matrix[0].length;
        }
        // 从右上角开始查找
        int i = 0, j = col - 1;
        while(i < row && j >= 0) {
            if(matrix[i][j] == target) {
                return true;
            } else if(matrix[i][j] < target) {
                // 如果当前元素小于目标值，则向下查找
                i++;
            } else {
                // 如果当前元素大于目标值，则向左查找
                j--;
            }
        }

        return false;
    }

    // 暴力法
    public static boolean findNumberViolence(int[][] metrix, int target){
        for(int[] row : metrix){
            for(int col : row){
                if(col == target){
                    return true;
                }
            }
        }
        return false;

    }
}
