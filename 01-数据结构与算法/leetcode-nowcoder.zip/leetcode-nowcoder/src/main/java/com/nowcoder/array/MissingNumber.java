package com.nowcoder.array;

public class MissingNumber {
    public static void main(String[] args) {
        int[] nums = {0, 1, 2, 3, 5, 6, 7, 8, 9};
        int[] nums1 = {0};
        int res = miss(nums1);
        System.out.println("res = " + res);

        int res2 = missingNumber(nums);
        System.out.println("res2 = " + res2);
    }

    //  剑指 Offer 53 - II. 0～n-1中缺失的数字
    //暴力美学
    public static int miss(int[] nums) {
//        暴力解法
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != i) {
                return i;
            }
        }
        return nums.length;
    }
    // 二分查找
    public static int missingNumber(int[] nums) {
        int left = 0, right = nums.length - 1;
        // 搜索区间为 [left, right]
        while (left <= right) {
            int mid = left + (right - left) / 2;
            // 如果中间元素的值等于中间元素的下标，说明缺失的数字在右边
            if (nums[mid] == mid) {
                // 搜索区间变为 [mid+1, right]
                left = mid + 1;
            } else if (nums[mid] != mid) {
                // 搜索区间变为 [left, mid-1]
                right = mid - 1;
            }
        }
        // 检查出界情况
        if (left >= nums.length) {
            return nums.length;
        }
        return left;
    }

}
