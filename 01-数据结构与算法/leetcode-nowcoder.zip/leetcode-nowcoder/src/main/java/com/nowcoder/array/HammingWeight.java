package com.nowcoder.array;

public class HammingWeight {
    public static void main(String[] args) {
        int n = 2190;
        int res = hammingWeight(n);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 15. 二进制中1的个数 (位运算)
    //    n & (n-1) 这个操作是算法中常见的，作用是消除数字 n 的二进制表示中的最后一个 1
    // 例如：n = 10100，n-1 = 10011，n & (n-1) = 10000 不断消除最后一个 1，直到 n 变成 0
    private static int hammingWeight(int n) {
        int res = 0;
        while(n !=0){
            n = n&(n-1);
            res++;
        }
        return res;
    }
}
