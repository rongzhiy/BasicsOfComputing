package com.nowcoder;

public class The_container_that_holds_the_most_water {
    /**
     * @param heights: an array of integers
     * @return: an integer
     */
    public int maxArea(int[] heights) {
        // write your code here
        if (heights == null || heights.length == 0) {
            return 0;
        }
        int i = 0;
        int j = heights.length - 1;
        int max = 0;
        while (i < j) {
            int area = (j - i) * Math.min(heights[i], heights[j]);
            max = Math.max(max, area);
            if (heights[i] < heights[j]) {
                i++;
            } else {
                j--;
            }
        }
        return max;
    }

    //    测试
    public static void main(String[] args) {
        The_container_that_holds_the_most_water the_container_that_holds_the_most_water = new The_container_that_holds_the_most_water();
        int[] heights = {1,7,3,2,4,5,8,2,7};
        int max = the_container_that_holds_the_most_water.maxArea(heights);
        System.out.println(max);
    }
}
