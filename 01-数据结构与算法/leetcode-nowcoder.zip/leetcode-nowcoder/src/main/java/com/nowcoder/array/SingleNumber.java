package com.nowcoder.array;

import java.util.HashSet;
import java.util.Set;

public class SingleNumber {
    public static void main(String[] args) {
        int[] nums = {3, 2, 1, 5, 6, 4, 7};
        int[] res = singleNumbers(nums);
        for (int re : res) {
            System.out.println("re = " + re);
        }
    }

    // 剑指 Offer 56 - I. 数组中数字出现的次数 I
    // 一个整型数组 nums 里除两个数字之外，其他数字都出现了两次。
    // 请写程序找出这两个只出现一次的数字。
    // 要求时间复杂度是O(n)，空间复杂度是O(1)。

    public static int[] singleNumbers(int[] nums) {
        Set<Integer> set  = new HashSet<>();    // 用于存放出现一次的数字
        for(int num :nums){
            if(set.contains(num)){
                set.remove(num);
            }else{
                set.add(num);
            }
        }
        return set.stream().mapToInt(Integer::intValue).toArray();
    }

    public static int[] singleNumbers1(int[] nums) {
        int[] res = new int[2];  // 用于将两个数字分组
        int xor = 0;
        // 先对所有数字进行一次异或，得到两个出现一次的数字的异或值。
        for (int num : nums) {  // 1. 遍历数组，求出所有数字的异或值。
            xor ^= num;     // 异或运算：相同为0，不同为1
        }
        // 在异或结果中找到任意为 1 的位。
        int mask = 1;
        while ((xor & mask) == 0) {
            mask <<= 1;
        }
        // 根据这一位对所有的数字进行分组。
        // 在每个组内进行异或操作，得到两个数字。
        for (int num : nums) {
            if ((num & mask) == 0) {
                res[0] ^= num;
            } else {
                res[1] ^= num;
            }

        }
        return res;
    }

//    在一个数组 nums 中除一个数字只出现一次之外，其他数字都出现了三次。请找出那个只出现一次的数字。
    public static int singleNumber(int[] nums) {
        //记录每个数字出现的次数
        int[] counts = new int[32];  // 32位整数
        for(int num : nums){        // 遍历数组
            for(int i = 0; i < 32; i++){    // 遍历数字的二进制表示
                counts[i] += num & 1;    // 统计每个位上出现的次数
                num >>>= 1;             // 考虑下一位
            }
        }
        //对每个数字的出现次数进行取余
        int res = 0, m = 3;
        for(int i = 0; i < 32; i++){
            res <<= 1;
            res |= counts[31 - i] % m;
        }
        return res;
    }



}
