package com.nowcoder.array;

public class FindNthDigit {
    public static void main(String[] args) {
        int n = 11;
        int res = findNthDigit(n);
        System.out.println(res);

        int res44 = findNthDigit44(n);
        System.out.println(res44);
    }

    // 剑指 Offer 44. 数字序列中某一位的数字
    //12345678910111213141516171819202122232425
    public static int findNthDigit44(int n) {
        if (n == 0) {
            return 0;
        }
        // 位数（一位数，两位数...）
        int digit = 1;
        // 1,10,100, 1000 这样的后缀
        long base = 1;

        while (n > 9 * base * digit) {
            n -= 9 * base * digit;
            base *= 10;
            digit++;
        }

        // 此时假设 base = 1000，那么说明 n 是 100~999 中的某个三位数的某一位
        // 哪个三位数呢？这样算：
        long val = base + (n - 1) / digit;
        // 是这个三位数的第几位呢？这样算：
        int index = (n - 1) % digit;

        // 怎么把 val 的第 index 这一位数字抠出来呢？这样算：
        return ("" + val).charAt(index) - '0';
    }

    //400. 第N个数字
    // 一位数有1~9 共 9 * 1 = 9 个。共几位？共 1 * 9 = 9 位。
    //二位数有10~99 共 90 * 1 = 90 个。共几位？共 2 * 90 = 180 位。
    //三位数有100~999 共 9 * 100 = 900 个。共几位？共 3 * 900 = 2700 位。
    public static int findNthDigit(int n) {
        int digit = 1;  // 位数
        long base = 1;  //  1,10,100, 1000 这样的后缀

        while (n > 9 * base * digit) { // 9 * base * digit 代表当前位数的数字个数
            n -= 9 * base * digit;  // 减去当前位数的数字个数
            digit++;        // 位数加一
            base *= 10;     // 后缀乘以10
        }

        // 此时假设 base = 1000，那么说明 n 是 100~999 中的某个三位数的某一位
        // 哪个三位数呢？这样算：
        long val = base + (n - 1) / digit;
        // 是这个三位数的第几位呢？这样算：
        int index = (n - 1) % digit;
        // 怎么把 val 的第 index 这一位数字抠出来呢？可以转化成字符串来算：
        return String.valueOf(val).charAt(index) - '0';

    }

}
