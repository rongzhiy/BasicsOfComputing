package com.nowcoder.array;

import java.util.ArrayDeque;
import java.util.Deque;

public class ValidateStackSequences {
    public static void main(String[] args) {
        int[] pushed = {1,2,3,4,5};
        int[] poped = {4,5,3,2,1};
        boolean res = validateStackSequences(pushed, poped);
        System.out.println("res = " + res);
    }

    // 剑指 Offer 31. 栈的压入、弹出序列
    // 解法： 模拟栈操作
    public static boolean validateStackSequences(int[] pushed, int[] popped) {
        Deque<Integer> stack = new ArrayDeque<Integer>(); // 用Deque代替Stack
        int n = pushed.length; // 数组长度
        for (int i = 0, j = 0; i < n; i++) {  // i是pushed数组的索引，j是popped数组的索引
            stack.push(pushed[i]);  // 先将pushed数组的元素压入栈中
            while (!stack.isEmpty() && stack.peek() == popped[j]) { // 当栈不为空且栈顶元素等于popped数组的元素时，弹出栈顶元素
                stack.pop(); // 弹出栈顶元素
                j++;    // popped数组的索引后移
            }
        }
        return stack.isEmpty(); // 栈为空则返回true，否则返回false
    }

}
