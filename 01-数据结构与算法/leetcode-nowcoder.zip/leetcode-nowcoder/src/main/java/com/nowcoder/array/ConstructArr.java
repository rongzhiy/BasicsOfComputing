package com.nowcoder.array;

public class ConstructArr {
    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4, 5};

        int[] res = constructArr(a);
        for (int i : res) {
            System.out.println("i = " + i);
        }
    }

    // 剑指 Offer 66. 构建乘积数组
    // 本题的关键在于，不能使用除法，那么就需要将乘积分为两部分，左边的乘积和右边的乘积.
    // 238. 除自身以外数组的乘积
    public static int[] constructArr(int[] nums) {
        int n = nums.length;
        if (n == 0) {
            return new int[0];
        }
        // 从左到右的前缀积，prefix[i] 是 nums[0..i] 的元素积
        int[] prefix = new int[n];
        prefix[0] = nums[0];
        for (int i = 1; i < nums.length; i++) {
            prefix[i] = prefix[i - 1] * nums[i];
        }
        // 从右到左的前缀积，suffix[i] 是 nums[i..n-1] 的元素积
        int[] suffix = new int[n];
        suffix[n - 1] = nums[n - 1];
        for (int i = n - 2; i >= 0; i--) {
            suffix[i] = suffix[i + 1] * nums[i];
        }
        // 结果数组
        int[] res = new int[n];
        res[0] = suffix[1];
        res[n - 1] = prefix[n - 2];
        for (int i = 1; i < n - 1; i++) {
            // 除了 nums[i] 自己的元素积就是 nums[i] 左侧和右侧所有元素之积
            res[i] = prefix[i - 1] * suffix[i + 1];
        }
        return res;
    }
}
