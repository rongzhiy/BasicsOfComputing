package com.nowcoder;

public class PalindromeString {
    /**
     * @param s: A string
     * @return: Whether the string is a valid palindrome
     */
    public boolean isPalindrome(String s) {
        // write your code here
        if (s == null || s.length() == 0) {
            return true;
        }
        int i = 0;
        int j = s.length() - 1;
        while(i<j){
//           比较前后两个字符是否相等
            if(s.charAt(i) != s.charAt(j)){
                return false;
            }
            i++;
            j--;
        }
        return true;
    }

    //    测试
    public static void main(String[] args) {
        PalindromeString palindromeString = new PalindromeString();
//        String a = "absba";
        String a = "ranko";
        boolean b = palindromeString.isPalindrome(a);
        System.out.println(b);
    }
}
