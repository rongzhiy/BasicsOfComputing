package com.nowcoder;

public class LongestCommonPrefix {
    /**
     * @param strs: A list of strings
     * @return: The longest common prefix
     */
    public String longestCommonPrefix(String[] strs) {
        // write your code here
        if (strs == null || strs.length == 0) {
            return "";
        }
        String prefix = strs[0];
        for (int i = 1; i < strs.length; i++) { //遍历数组
            while (strs[i].indexOf(prefix) != 0) {  //indexOf() 方法可返回某个指定的字符串值在字符串中首次出现的位置。
                prefix = prefix.substring(0, prefix.length() - 1);  //substring() 方法用于提取字符串中介于两个指定下标之间的字符。
                if (prefix.isEmpty()) {
                    return "";
                }
            }
        }
        return prefix;
    }
//    测试
    public static void main(String[] args) {
        String[] strs = {"ABCD", "ABEF", "ACEF"};
        LongestCommonPrefix longestCommonPrefix = new LongestCommonPrefix();
        String s = longestCommonPrefix.longestCommonPrefix(strs);
        System.out.println(s);
    }
}
