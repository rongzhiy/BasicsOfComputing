package com.nowcoder;

import java.util.HashMap;

public class LongestUnrepeatedSubarray {
    /**
     * @param arr: an array of integers
     * @return: the length of the longest subarray
     */
    public int maxLength(int[] arr) {
        if (arr.length == 0)        //数组为空，返回0
            return 0;
        HashMap<Integer, Integer> map = new HashMap<>(); //用于存储每个字符出现的位置
        int max = 0;
        for (int i = 0, j = 0; i < arr.length; ++i) {   //i为右指针，j为左指针
            if (map.containsKey(arr[i])) {   //如果map中包含当前字符
                j = Math.max(j, map.get(arr[i]) + 1); //更新左指针位置
            }
            map.put(arr[i], i);  //更新字符出现的位置
            max = Math.max(max, i - j + 1);  //更新最大值
        }
        return max;
    }
    public int getLongestUnrepeatedSubarray(int[] arr) {
        // write your code here
        if (arr == null || arr.length == 0) {
            return 0;
        }
        int[] hash = new int[256];
        int left = 0;
        int right = 0;
        int max = 0;
        while (right < arr.length) {
            hash[arr[right]]++; //记录每个字符出现的次数
            while (hash[arr[right]] > 1) { //如果出现重复字符，左指针右移
                hash[arr[left]]--; //左指针右移，左指针对应的字符次数减一
                left++; //左指针右移
            }
            max = Math.max(max, right - left + 1); //更新最大值
            right++; //右指针右移
        }
        return max; //返回最大值
    }

    //    测试
    public static void main(String[] args) {
        LongestUnrepeatedSubarray longestUnrepeatedSubarray = new LongestUnrepeatedSubarray();
        int[] arr = {2,3,3,4,5};
//        int i = longestUnrepeatedSubarray.getLongestUnrepeatedSubarray(arr);
        int i = longestUnrepeatedSubarray.maxLength(arr);
        System.out.println(i);
    }
}
