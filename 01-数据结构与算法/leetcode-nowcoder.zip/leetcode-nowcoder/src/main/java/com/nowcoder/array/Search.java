package com.nowcoder.array;

public class Search {
    public static void main(String[] args) {
        int[] nums = {5,7,7,8,8,10};
        int target = 8;
        int res = search1(nums, target);
        System.out.println("res = " + res);

        int res1 = search(nums, target);
        System.out.println("res1 = " + res1);
    }

    // 剑指 Offer 53 - I. 在排序数组中查找数字 I
    // 统计一个数字在排序数组中出现的次数。

    //暴力美学
    public static int search(int[] nums,int target){
        int count = 0;
        for (int i = 0; i < nums.length - 1; i++) {
            if (nums[i] == target){
                count++;
            }
        }
        return count;
    }

    // 二分查找
    public static int search1(int[] nums, int target) {
        int left_index = left_bound(nums, target);
        if (left_index == -1) {
            return 0;
        }
        int right_index = right_bound(nums, target);
        // 根据左右边界即可推导出元素出现的次数
        return right_index - left_index + 1;
    }

    static int left_bound(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        // 搜索区间为 [left, right]
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (nums[mid] < target) {
                // 搜索区间变为 [mid+1, right]
                left = mid + 1;
            } else if (nums[mid] > target) {
                // 搜索区间变为 [left, mid-1]
                right = mid - 1;
            } else if (nums[mid] == target) {
                // 收缩右侧边界
                right = mid - 1;
            }
        }
        // 检查出界情况
        if (left >= nums.length || nums[left] != target) {



            return -1;
        }
        return left;
    }

    static int right_bound(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (nums[mid] < target) {
                left = mid + 1;
            } else if (nums[mid] > target) {
                right = mid - 1;
            } else if (nums[mid] == target) {
                // 这里改成收缩左侧边界即可
                left = mid + 1;
            }
        }
        // 这里改为检查 right 越界的情况，见下图
        if (right < 0 || nums[right] != target) {



            return -1;
        }
        return right;
    }

}
