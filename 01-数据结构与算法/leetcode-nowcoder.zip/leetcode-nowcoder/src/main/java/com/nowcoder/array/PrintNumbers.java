package com.nowcoder.array;

public class PrintNumbers {
    public static void main(String[] args) {
        int n = 2;
        int[] res = printNumbers(n);
        for (int i = 0; i < res.length; i++) {
            System.out.println("res = " + res[i]);
        }
    }

    // 剑指 Offer 17. 打印从1到最大的n位数
    public static int[] printNumbers(int n){
        int max = 0;
        for (int i = 0; i < n; i++) {
            max = max * 10 + 9;
        }
        int[] res = new int[max];
        for (int i = 0; i < max; i++) {
            res[i] = i + 1;
        }
        return res;
    }

}
