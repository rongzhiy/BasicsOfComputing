package com.nowcoder.array;

import java.util.Arrays;
import java.util.PriorityQueue;

public class FindKthLargest {
    public static void main(String[] args) {
        int[] nums = {3, 2, 1, 5, 6, 4, 7};
        int res  = findKthLargest(nums, 2);
        System.out.println("res = " + res);

        int res1 = finKthLargest1(nums, 2);
        System.out.println("res1 = " + res1);
    }

    // 215. 数组中的第K个最大元素
    public static int findKthLargest(int[] nums, int k) {
        // 小顶堆，堆顶是最小元素
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        for (int e : nums) {
            // 每个元素都要过一遍二叉堆
            pq.offer(e);
            // 堆中元素多于 k 个时，删除堆顶元素
            if (pq.size() > k) {
                pq.poll();
            }
        }
        // pq 中剩下的是 nums 中 k 个最大元素，
        // 堆顶是最小的那个，即第 k 个最大元素
        return pq.peek();
    }

    public static int finKthLargest1(int[] nums,int k){
        Arrays.sort(nums);
        for (int num : nums) {
            System.out.print("num = " + num);
        }
        return nums[nums.length-k];
    }
}
