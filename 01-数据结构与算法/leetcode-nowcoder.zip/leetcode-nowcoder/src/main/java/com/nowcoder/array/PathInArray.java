package com.nowcoder.array;

public class PathInArray {
    public static void main(String[] args) {
        char[][] board = {{'a', 'b', 'c', 'e'},
                          {'s', 'f', 'c', 's'},
                          {'a', 'd', 'e', 'e'}};
        String word = "abccedas";
        boolean res = exist(board, word);
        System.out.println("res = " + res);
    }
    // 剑指 Offer 12. 矩阵中的路径
    // 回溯法
    public static boolean exist(char[][] board, String word) {
        int rows = board.length, cols = board[0].length;
        boolean[][] visited = new boolean[rows][cols];
        char[] words = word.toCharArray();
        // 遍历二维数组，找到第一个字符
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < cols; j++){
                if(dfs(board, words, visited, i, j, 0)){
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean dfs(char[][] board, char[] words, boolean[][] visited, int i, int j, int k){
        // 越界或者不匹配，返回false
        if(i >= board.length || i < 0 || j >= board[0].length || j < 0 || board[i][j] != words[k] || visited[i][j]){
            return false;
        }
        // 匹配到最后一个字符，返回true
        if(k == words.length - 1){
            return true;
        }
        // 匹配到当前字符，继续匹配下一个字符
        visited[i][j] = true;
        boolean res = dfs(board, words, visited, i + 1, j, k + 1) || dfs(board, words, visited, i - 1, j, k + 1) || dfs(board, words, visited, i, j + 1, k + 1) || dfs(board, words, visited, i, j - 1, k + 1);
        // 回溯
        visited[i][j] = false;
        return res;
    }
}
