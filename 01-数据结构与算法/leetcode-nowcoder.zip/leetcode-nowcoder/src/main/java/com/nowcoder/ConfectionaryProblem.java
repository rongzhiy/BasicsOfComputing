package com.nowcoder;

public class ConfectionaryProblem {
    /**
     * @param arr: an integer array
     * @return: Integer
     * @Describe: 分糖果问题
     */
    public int candy(int[] arr) {
        // write your code here
        if (arr == null || arr.length == 0) {
            return 0;
        }
        int[] candies = new int[arr.length];
        candies[0] = 1;
        //从左往右遍历，如果右边的孩子比左边的孩子评分高，那么右边孩子的糖果数就比左边孩子的糖果数多1
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > arr[i - 1]) {
                candies[i] = candies[i - 1] + 1;
            } else {
                candies[i] = 1;
            }
        }
        //从右往左遍历，如果左边的孩子比右边的孩子评分高，那么左边孩子的糖果数就比右边孩子的糖果数多1
        for (int i = arr.length - 2; i >= 0; i--) {
            if (arr[i] > arr[i + 1] && candies[i] <= candies[i + 1]) {
                candies[i] = candies[i + 1] + 1;
            }
        }
        int result = 0;
        for (int i = 0; i < candies.length; i++) {
            result += candies[i];
        }
        return result;
    }

    //    测试
    public static void main(String[] args) {
        ConfectionaryProblem confectionaryProblem = new ConfectionaryProblem();
        int[] arr = {1, 1, 2, 1};
        int result = confectionaryProblem.candy(arr);
        System.out.println(result);
    }

}
