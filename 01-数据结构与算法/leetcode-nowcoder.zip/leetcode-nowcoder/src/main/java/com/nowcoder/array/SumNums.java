package com.nowcoder.array;

public class SumNums {
    public static void main(String[] args) {
        int n = 3;
        int res = sumNums(n);
        System.out.println(res);
    }

    // 剑指 Offer 64. 求1+2+…+n  要求不能使用乘除法、for、while、if、else、switch、case等关键字及条件判断语句（A?B:C）
    // 递归
    public static int sumNums(int n){
        boolean x = n > 1 && (n += sumNums(n - 1)) > 0;  // 逻辑运算符的短路效应
        return n;
    }

    public static int sumNums1(int n){
        return (1+n)*n/2;   // 等差数列求和公式
    }

    public static int sumNums2(int n){  //循环
        int sum = 0;
        for(int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }

    public static int sumNums3(int n){  //递归
      if(n == 1) {
          return 1;
      }
        return n + sumNums3(n - 1);
    }
}
