package com.nowcoder;

import java.util.ArrayList;

//给出一组区间，请合并所有重叠的区间。
public class CombinedArea {

    public ArrayList<Interval> merge(ArrayList<Interval> intervals) {
        ArrayList<Interval> res = new ArrayList<>(); //存储最终的结果
        if (intervals == null || intervals.size() == 0) { //如果传入的数组为空，或者数组的长度为0，直接返回空的结果
            return res;
        }
        intervals.sort((o1, o2) -> o1.start - o2.start); //按照区间的起始位置进行排序
        Interval last = intervals.get(0); //取出第一个区间
        for (int i = 1; i < intervals.size(); i++) { //遍历剩下的区间
            Interval cur = intervals.get(i); //取出当前区间
            if (cur.start <= last.end) { //如果当前区间的起始位置小于等于上一个区间的结束位置，说明这两个区间是重叠的
                last.end = Math.max(last.end, cur.end); //更新上一个区间的结束位置
            } else { //如果当前区间的起始位置大于上一个区间的结束位置，说明这两个区间不重叠
                res.add(last); //将上一个区间加入到结果集中
                last = cur; //更新上一个区间为当前区间
            }
        }
        res.add(last); //将最后一个区间加入到结果集中
        return res; //返回结果集
    }

    public static void main(String[] args) {
        ArrayList<Interval> intervals = new ArrayList<>();
        intervals.add(new Interval(1, 3));
        intervals.add(new Interval(2, 6));
        intervals.add(new Interval(8, 10));
        intervals.add(new Interval(15, 18));
        CombinedArea combinedArea = new CombinedArea();
        ArrayList<Interval> res = combinedArea.merge(intervals);
//        取出res中的每一个Interval，打印出来
        for (Interval interval : res) {
            System.out.println(interval.start + " " + interval.end);
        }
    }

}


class Interval {
    int start;
    int end;
    Interval() { start = 0; end = 0; }
    Interval(int s, int e) { start = s; end = e; }

}