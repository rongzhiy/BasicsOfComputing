package com.nowcoder.array;

public class LastRemaining {
    public static void main(String[] args) {
        int n = 5;
        int m = 3;
        int res = lastRemaining(n, m);
        System.out.println(res);
    }

    // 剑指 Offer 62. 圆圈中最后剩下的数字
    // 约瑟夫环问题
    public static int lastRemaining(int n, int m) {
        int res = 0;
        for(int i = 2; i <= n; i++) {
            res = (res + m) % i;
        }
        return res;
    }
}
