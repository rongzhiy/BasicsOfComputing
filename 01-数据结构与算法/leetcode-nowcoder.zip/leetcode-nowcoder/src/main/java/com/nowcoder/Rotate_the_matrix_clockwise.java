package com.nowcoder;

public class Rotate_the_matrix_clockwise {
    /**
     * @param matrix int整型二维数组
     * @return int整型二维数组
     * 矩阵转置是将上三角矩阵元素与下三角矩阵元素依据对角线位置对称互换，且该过程是可逆的。
     */
//    法一
    public int[][] rotateMatrix (int[][] matrix , int n) {
        // write code here
        int[][] res = new int[n][n];
        for (int i = 0; i < n; i++) { //行
            for (int j = 0; j < n; j++) {   //列
                res[j][n - i - 1] = matrix[i][j];
            }
        }
        return res;
    }

//    法二：矩阵转置，每行翻转
    public int[][] rotateMatrix1(int[][] mat, int n) {
        int length = mat.length;
        //矩阵转置
        for (int i = 0; i < length; ++i) {
            for (int j = 0; j < i; ++j) {
                //交换上三角与下三角对应的元素
                int temp = mat[i][j];
                mat[i][j] = mat[j][i];
                mat[j][i] = temp;
            }
        }
        //每行翻转
        for (int i = 0; i < length; i++) {
            for (int j = 0; j < length / 2; j++) {
                int temp = mat[i][j];
                mat[i][j] = mat[i][length - j - 1];
                mat[i][length - j - 1] = temp;
            }
        }
        return mat;
    }
//    测试
    public static void main(String[] args) {
        Rotate_the_matrix_clockwise rotate_the_matrix_clockwise = new Rotate_the_matrix_clockwise();
        int[][] matrix = {{1,2,3},{4,5,6},{7,8,9}};
        int[][] res = rotate_the_matrix_clockwise.rotateMatrix(matrix, 3);
        for (int i = 0; i < res.length; i++) {
            for (int j = 0; j < res[0].length; j++) {
                System.out.print(res[i][j] + " ");
            }
            System.out.println();
        }
    }
}
