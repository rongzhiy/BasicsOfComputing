package org.itstack.interview;

public class T {
}
