![logo](_media/tree.png)

# CodeGuide

## 程序员编码指南

- 本代码库是作者小傅哥多年从事一线互联网 `Java` 开发的学习历程技术汇总，旨在为大家提供一个清晰详细的学习教程，侧重点更倾向编写Java核心内容。如果本仓库能为您提供帮助，请给予支持(关注、点赞、分享)！   
    
[![stars](https://badgen.net/github/stars/fuzhengwei/CodeGuide?icon=github&color=4ab8a1)](https://github.com/fuzhengwei/CodeGuide) [![forks](https://badgen.net/github/forks/fuzhengwei/CodeGuide?icon=github&color=4ab8a1)](https://github.com/fuzhengwei/CodeGuide) [<img src="https://itstack.org/_media/wxbugstack.svg">](https://itstack.org/_media/qrcode.png?x-oss-process=style/may)    

[GitHub](<https://github.com/fuzhengwei/CodeGuide>)
[开始阅读](README.md)

