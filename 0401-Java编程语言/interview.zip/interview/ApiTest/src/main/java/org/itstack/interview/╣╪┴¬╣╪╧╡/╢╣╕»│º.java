package org.itstack.interview.关联关系;

/**
 * 博客：https://bugstack.cn - 沉淀、分享、成长，让自己和他人都能有所收获！
 * 公众号：bugstack虫洞栈
 * Create by 小傅哥(fustack) @2020
 */
public class 豆腐厂 {

    private 王小蒙 员工;

    public void 添加员工(王小蒙 小蒙){
        this.员工 = 小蒙;
    }

}
