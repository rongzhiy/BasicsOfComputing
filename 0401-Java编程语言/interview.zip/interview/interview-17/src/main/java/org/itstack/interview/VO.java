package org.itstack.interview;

public class VO {

    public int a = 0;
    public long b = 0;
    public String c = "123";
    public Object d = null;
    public int e = 100;
    public static int f = 0;
    public static String g = "";
    public Object h = null;
    public boolean i;
}
