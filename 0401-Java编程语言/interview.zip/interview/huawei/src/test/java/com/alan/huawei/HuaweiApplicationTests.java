package com.alan.huawei;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HuaweiApplicationTests {

    @Test
    void contextLoads() {
    }

}
