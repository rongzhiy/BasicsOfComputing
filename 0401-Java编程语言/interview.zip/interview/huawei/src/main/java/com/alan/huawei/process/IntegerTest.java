package com.alan.huawei.process;

public class IntegerTest {

}
