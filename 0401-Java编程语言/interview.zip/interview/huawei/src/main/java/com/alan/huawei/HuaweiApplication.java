package com.alan.huawei;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HuaweiApplication {

    public static void main(String[] args) {

        SpringApplication.run(HuaweiApplication.class, args);
    }

}
