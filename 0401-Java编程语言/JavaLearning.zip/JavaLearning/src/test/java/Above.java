import org.junit.Test;

import java.math.BigDecimal;
import java.util.Objects;

public class Above {
    @Test
    public void test2() {
        // 两种浮点数类型的包装类 Float,Double 并没有实现缓存机制。
        Integer i1 = 33;
        Integer i2 = 33;
        System.out.println(i1 == i2);// 输出 true

        Float i11 = 333f;
        Float i22 = 333f;
        System.out.println(i11 == i22);// 输出 false

        Double i3 = 1.2;
        Double i4 = 1.2;
        System.out.println(i3 == i4);// 输出 false

        return;
    }

    @Test
    public void test1() {
        Integer i11 = 40;
        Integer i22 = new Integer(40);
        System.out.println(i11==i22);  //比较的是地址 false. Integer i1=40 这一行代码会发生装箱，也就是说这行代码等价于 Integer i1=Integer.valueOf(40) 。因此，i1 直接使用的是缓存中的对象。而Integer i2 = new Integer(40) 会直接创建新的对象。

//        所有整型包装类对象之间的值的比较，全部使用equals方法比较。
//        说明：对于Integer var=?在-128至127之间的赋值，Integer对象是在IntegerCache.cache产生，会复用已有对象，这个区间内的Integer值可以直接使用==进行判断，
//        但是这个区间之外的所有数据，都会在堆上产生，并不会复用已有对象，这是一个大坑，推荐使用equals方法进行判断。
        Integer i1 = 40;
        Integer i2 = 40;
        System.out.println(i1==i2);  //比较的是地址 true
        System.out.println(i1.equals(i2)); //比较的是值 true

        Integer i3 = -129;
        Integer i4 = new Integer(-129);
        System.out.println(i3==i4);  //比较的是地址 false
        System.out.println(i3.equals(i4)); //比较的是值 true
        return;
    }

    @Test
    public void fudianshu(){
//        浮点数精度丢失
        float a = 2.0f - 1.9f;
        float b = 1.8f - 1.7f;
        System.out.println(a);// 0.100000024
        System.out.println(b);// 0.099999905
        System.out.println(a == b);// false
//        浮点数精度丢失解决  （比如涉及到钱的场景）
        BigDecimal a1 = new BigDecimal("1.0");
        BigDecimal b1 = new BigDecimal("0.9");
        BigDecimal c = new BigDecimal("0.8");

        BigDecimal x = a1.subtract(b1);
        BigDecimal y = b1.subtract(c);
        BigDecimal z = c.subtract(a1);
        System.out.println(z);

        System.out.println(x); /* 0.1 */
        System.out.println(y); /* 0.1 */
        System.out.println(Objects.equals(x, y)); /* true */

        return;
    }
}
