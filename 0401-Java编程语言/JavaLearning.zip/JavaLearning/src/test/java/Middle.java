import org.junit.Test;

public class Middle {
    @Test
    public void reference(){
        String str1 = "hello";
        String str2 = new String("hello");
        String str3 = "hello";
// 使用 == 比较字符串的引用相等
        System.out.println(str1 == str2); // false
        System.out.println(str1 == str3); // true
// 使用 equals 方法比较字符串的相等
        System.out.println(str1.equals(str2));  // true
        System.out.println(str1.equals(str3));  // true

        return;
    }
}
