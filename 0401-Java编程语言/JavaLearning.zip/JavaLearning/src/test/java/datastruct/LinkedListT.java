package datastruct;

import org.junit.Test;

import java.util.*;

public class LinkedListT {
    @Test
    public void test_init() {
        // 初始化方式；普通方式
        LinkedList<String> list01 = new LinkedList<String>();
        list01.add("a");
        list01.add("b");
        list01.add("c");
        System.out.println(list01);

        // 初始化方式；Arrays.asList
        LinkedList<String> list02 = new LinkedList<String>(Arrays.asList("a", "b", "c"));
        System.out.println(list02);

        // 初始化方式；内部类
        LinkedList<String> list03 = new LinkedList<String>() {
            {
                add("a");
                add("b");
                add("c");
            }
        };
        System.out.println(list03);

        // 初始化方式；Collections.nCopies
        LinkedList<Integer> list04 = new LinkedList<Integer>(Collections.nCopies(10, 0));
        System.out.println(list04);
    }

    @Test
    public void test_ArrayList_addFirst() {
        ArrayList<Integer> list = new ArrayList<Integer>();
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 10000000; i++) {
            // add(i) 则是尾插
            list.add(0, i);
        }
        System.out.println("耗时：" + (System.currentTimeMillis() - startTime));
    }

    @Test
    public void test_LinkedList_addFirst() {
        LinkedList<Integer> list = new LinkedList<Integer>();
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 10000000; i++) {
            list.addFirst(i);
        }
        System.out.println("耗时：" + (System.currentTimeMillis() - startTime));
    }

    @Test
    public void test_ArrayList_addLast() {
        ArrayList<Integer> list = new ArrayList<Integer>();
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 10000000; i++) {
            list.add(i);
        }
        System.out.println("耗时：" + (System.currentTimeMillis() - startTime));
    }

    @Test
    public void test_LinkedList_addLast() {
        LinkedList<Integer> list = new LinkedList<Integer>();
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 1000000; i++) {
            list.addLast(i);
        }
        System.out.println("耗时：" + (System.currentTimeMillis() - startTime));
    }

    @Test
    public void test_ArrayList_addCenter() {
        ArrayList<Integer> list = new ArrayList<Integer>();
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 10000000; i++) {
            list.add(list.size() >> 1, i);
        }
        System.out.println("耗时：" + (System.currentTimeMillis() - startTime));
    }

    @Test
    public void test_LinkedList_addCenter() {
        LinkedList<Integer> list = new LinkedList<Integer>();
        long startTime = System.currentTimeMillis();
        for (int i = 0; i < 1000000; i++) {
            list.add(list.size() >> 1, i);
        }
        System.out.println("耗时：" + (System.currentTimeMillis() - startTime));
    }


// 双端队列
    @Test
    public void test_Deque_LinkedList(){
        Deque<String> deque = new LinkedList<>();
        deque.push("a");
        deque.push("b");
        deque.push("c");
        deque.push("d");
        deque.offerLast("e");
        deque.offerLast("f");
        deque.offerLast("g");
        deque.offerLast("h");
        deque.push("i");
        deque.offerLast("j");

        System.out.println("数据出栈：");
        while (!deque.isEmpty()) {
            System.out.print(deque.pop() + " ");
        }
    }




}
