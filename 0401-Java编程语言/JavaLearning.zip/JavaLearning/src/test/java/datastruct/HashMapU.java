package datastruct;

//HashMap数据插入、查找、删除、遍历

import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class HashMapU {

    @Test
    public void test_Iterator() {
        Map<String, String> map = new HashMap<String, String>(64);
        map.put("24", "Idx：2");
        map.put("46", "Idx：2");
        map.put("68", "Idx：2");
        map.put("29", "Idx：7");
        map.put("150", "Idx：12");
        map.put("172", "Idx：12");
        map.put("194", "Idx：12");
        map.put("271", "Idx：12");
        System.out.println("排序01：");   // 添加元素，在HashMap还是只链表结构时，输出测试结果01
        for (String key : map.keySet()) {
            System.out.print(key + " ");
        }

        map.put("293", "Idx：12");
        map.put("370", "Idx：12");
        map.put("392", "Idx：12");
        map.put("491", "Idx：12");
        map.put("590", "Idx：12");
        System.out.println("\n\n排序02：");  // 添加元素，HashMap链表结构转红黑树结构后，输出测试结果02
        for (String key : map.keySet()) {
            System.out.print(key + " ");
        }

        map.remove("293");
        map.remove("370");
        map.remove("392");
        map.remove("491");
        map.remove("590");
        System.out.println("\n\n排序03：");    // 删除元素，HashMap红黑树结构转链表结构后，输出测试结果03
        for (String key : map.keySet()) {
            System.out.print(key + " ");
        }

    }


}
