package datastruct;

import org.junit.Test;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDequeT {
    @Test
    public void test_ArrayDeque() {
        Deque<String> deque = new ArrayDeque<String>(1);

        deque.push("a");
        deque.push("b");
        deque.push("c");
        deque.push("d");

        deque.offerLast("e");
        deque.offerLast("f");
        deque.offerLast("g");
        deque.offerLast("h");  // 这时候扩容了

        deque.push("i");
        deque.offerLast("j");

        System.out.println("数据出栈：");
        while (!deque.isEmpty()) {
            System.out.print(deque.pop() + " ");
        }
    }

}
