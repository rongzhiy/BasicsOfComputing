package datastruct;

import com.alibaba.fastjson2.JSON;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayListT {

    @Test
    public void test() {
        ArrayList<String> list = new ArrayList<String>();
        list.add("aaa");
        list.add("bbb");
        list.add("ccc");

        ArrayList<String> list1 = new ArrayList<String>(Arrays.asList("aaa", "bbb", "ccc"));

    }
    @Test
    public void t(){
        List<Integer> list1 = Arrays.asList(1, 2, 3);
        System.out.println("通过数组转换：" + (list1.toArray().getClass() == Object[].class));

        ArrayList<Integer> list2 = new ArrayList<Integer>(Arrays.asList(1, 2, 3));
        System.out.println("通过集合转换：" + (list2.toArray().getClass() == Object[].class));
    }

    @Test
    public void test_arraycopy() {
        int[] oldArr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] newArr = new int[oldArr.length + (oldArr.length >> 1)];
        System.arraycopy(oldArr, 0, newArr, 0, oldArr.length);

        newArr[11] = 11;
        newArr[12] = 12;
        newArr[13] = 13;
        newArr[14] = 14;

        System.out.println("数组元素：" + JSON.toJSONString(newArr));
        System.out.println("数组长度：" + newArr.length);

    }

    @Test
    public void test1(){
        List<String> list = new ArrayList<String>(10);
        list.add(2, "aaa");  //即使我们申请了10个容量长度的ArrayList，但是指定位置插入会依赖于size进行判断，所以会抛出IndexOutOfBoundsException异常。
        System.out.println(list.get(0));
    }



}
