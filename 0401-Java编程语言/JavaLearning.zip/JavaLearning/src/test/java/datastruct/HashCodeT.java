package datastruct;

//HashCode为什么使用31作为乘数？
// 散列效果最好

public class HashCodeT {
//    public int hashCode() {
//        int h = hash;
//        if (h == 0 && value.length > 0) {
//            char val[] = value;
//            for (int i = 0; i < value.length; i++) {
//                h = 31 * h + val[i];
//            }
//            hash = h;
//        }
//        return h;
//
//    }

    public static void main(String[] args) {

        System.out.println("Hello World!".hashCode());

    }
}
