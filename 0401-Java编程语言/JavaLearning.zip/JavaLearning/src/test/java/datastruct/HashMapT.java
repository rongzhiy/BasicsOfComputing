package datastruct;//HashMap核心知识，扰动函数、负载因子、扩容链表拆分，深度学习
//在JDK 1.8中包括；1、散列表实现、2、扰动函数、3、初始化容量、4、负载因子、
// 5、扩容元素拆分、6、链表树化、7、红黑树、8、插入、9、查找、10、删除、11、遍历、12、分段锁等等

import com.alibaba.fastjson2.JSON;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HashMapT {


    @Test
    public void test() {
        // 初始化一组字符串
        List<String> list = new ArrayList<>();
        list.add("jlkk");
        list.add("lopi");
        list.add("小傅哥");
        list.add("e4we");
        list.add("alpo");
        list.add("yhjk");
        list.add("plop");

// 定义要存放的数组
        String[] tab = new String[8];

// 循环存放
        for (String key : list) {
            int idx = key.hashCode() & (tab.length - 1);  // 计算索引位置
            System.out.println(String.format("key值=%s Idx=%d", key, idx));
            if (null == tab[idx]) {
                tab[idx] = key;
                continue;
            }
            tab[idx] = tab[idx] + "->" + key;
        }
// 输出测试结果
        System.out.println(JSON.toJSONString(tab));



    }

    public static class Disturb {

        public static int disturbHashIdx(String key, int size) {
            return (size - 1) & (key.hashCode() ^ (key.hashCode() >>> 16));
        }

        public static int hashIdx(String key, int size) {
            return (size - 1) & key.hashCode();
        }

    }

    // 10万单词已经初始化到words中
    @Test
    public void test_disturb() {
        Map<Integer, Integer> map = new HashMap<>(16);
        String[] words = new String[]{"a", "b", "c", "d", "e", "f", "g", "h"};
        for (String word : words) {
            // 使用扰动函数
            int idx = Disturb.disturbHashIdx(word, 128);
            // 不使用扰动函数
            // int idx = Disturb.hashIdx(word, 128);
            if (map.containsKey(idx)) {
                Integer integer = map.get(idx);
                map.put(idx, ++integer);
            } else {
                map.put(idx, 1);
            }
        }
        System.out.println(map.values());
    }






}
