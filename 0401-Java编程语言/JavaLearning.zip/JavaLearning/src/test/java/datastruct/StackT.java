package datastruct;

import org.junit.Test;

import java.util.Stack;

public class StackT {
    @Test
    public void test_stack() {
        Stack<String> s = new Stack<String>();
        s.push("aaa");
        s.push("bbb");
        s.push("ccc");

        System.out.println("获取最后一个元素：" + s.peek());
        System.out.println("获取最后一个元素：" + s.lastElement());
        System.out.println("获取最先放置元素：" + s.firstElement());

        System.out.println("弹出一个元素[LIFO]：" + s.pop());
        System.out.println("弹出一个元素[LIFO]：" + s.pop());
        System.out.println("弹出一个元素[LIFO]：" + s.pop());
    }

}
