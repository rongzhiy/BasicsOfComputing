package org.alan.juc;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class MultiThread {
    public static void main(String[] args) {
        // 获取 Java 线程管理 MXBean
        ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
        // 不需要获取同步的 monitor 和 synchronizer 信息，仅获取线程和线程堆栈信息
        ThreadInfo[] threadInfos = threadMXBean.dumpAllThreads(false, false);
        // 遍历线程信息，仅打印线程 ID 和线程名称信息
        for (ThreadInfo threadInfo : threadInfos) {
            System.out.println("[" + threadInfo.getThreadId() + "] " + threadInfo.getThreadName());
        }


//        创建多线程的方式
//        1.继承Thread类
//        2.实现Runnable接口
//        3.实现Callable接口
//        4.使用线程池

//        创建线程池的方式
//        1.使用Executors工具类创建
        Executors.newCachedThreadPool();   // 无界线程池，可以进行自动线程回收
        Executors.newFixedThreadPool(10); // 固定大小线程池
        Executors.newScheduledThreadPool(10); // 延迟或定时执行任务的线程池
        Executors.newSingleThreadExecutor();    // 单线程化的线程池，只会用唯一的工作线程来执行任务
        Executors.newSingleThreadScheduledExecutor(); // 单线程化的线程池，可以进行定时或延时任务的执行

//        2.使用ThreadPoolExecutor构造方法创建


        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                10,
                10,
                10L,
                TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>());

        threadPoolExecutor.execute(new Runnable() {
            @Override
            public void run() {
                System.out.println("hello");
            }
        });




//        3.使用ThreadPoolExecutor的静态方法创建
        ThreadPoolExecutor threadPoolExecutor1 = (ThreadPoolExecutor) Executors.newFixedThreadPool(10);
        threadPoolExecutor1.execute(new Runnable() {
            @Override
            public void run() {
                System.out.println("hello");
            }
        });

    }
}
