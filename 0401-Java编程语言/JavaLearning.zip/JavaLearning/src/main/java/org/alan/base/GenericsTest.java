package org.alan.base;

import sun.misc.Unsafe;

public class GenericsTest {
    public static void main(String[] args) {


    }
}
