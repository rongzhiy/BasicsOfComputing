package org.alan.juc;

public class Singleton {

//    双重检查锁定
    private volatile static Singleton instance;

    private Singleton() {
    }

    public  static Singleton getInstance() {
        //先判断对象是否已经实例过，没有实例化过才进入加锁代码
        if (instance == null) {
            //类对象加锁
            synchronized (Singleton.class) {
                if (instance == null) {
//                   1. 为 uniqueInstance 分配内存空间
//                   2. 初始化 uniqueInstance
//                   3. 将 uniqueInstance 指向分配的内存地址
                    instance = new Singleton();
                }
            }
        }
        return instance;
    }

    public static void main(String[] args) {
        System.out.println("Singleton.getUniqueInstance() = " + Singleton.getInstance());
    }
}
