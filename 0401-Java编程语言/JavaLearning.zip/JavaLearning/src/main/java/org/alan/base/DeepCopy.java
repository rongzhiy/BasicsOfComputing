package org.alan.base;


import lombok.Data;

// ![引用拷贝、浅拷贝、深拷贝](https://oss.javaguide.cn/github/javaguide/java/basis/shallow&deep-copy.png)
class Address1 implements Cloneable{
    private String name;

    public Address1(String name) {
        this.name = name;
    }

    // 省略构造函数、Getter&Setter方法
    @Override
    public Address1 clone() {
        try {
            return (Address1) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}

@Data
class Person1 implements Cloneable {
    private Address1 address;

    public Person1(Address1 address) {
        this.address = address;
    }

    // 省略构造函数、Getter&Setter方法
    @Override
    public Person1 clone() {
        try {
            Person1 person = (Person1) super.clone();
            person.setAddress(person.getAddress().clone());   //这里我们简单对 Person 类的 clone() 方法进行修改，连带着要把 Person 对象内部的 Address 对象一起复制。
            return person;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}


public class DeepCopy {


    public static void main(String[] args) {
        Person1 person1 = new Person1(new Address1("武汉"));
        Person1 person1Copy = person1.clone();
// false
        System.out.println(person1.getAddress() == person1Copy.getAddress());
        System.out.println(person1==person1Copy);

    }
}
