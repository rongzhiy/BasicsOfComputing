package org.alan.base.demo;

/**
 * @author alan
 * @data 2022/5/9
 * @email 2735545128@qq.com
 */
public class 作用域 {
}
//小结
//Java内建的访问权限包括public、protected、private和package权限；
//
//Java在方法内部定义的变量是局部变量，局部变量的作用域从变量声明开始，到一个块结束；
//
//final修饰符不是访问权限，它可以修饰class、field和method；
//
//一个.java文件只能包含一个public类，但可以包含多个非public类。
