package org.alan.myio;

import lombok.Data;

public class Vo2dto {

// 小傅哥的插件：https://bugstack.cn/md/product/idea-plugin/vo2dto.html

    public static void main(String[] args) {
        User user = new User();
        user.setName("alan");
        user.setPassword("123456");
        user.setEmail("wqewq@qq.com");

        UserDto userDto = new UserDto();
        userDto.setName(user.getName());
        userDto.setPassword(user.getPassword());
        userDto.setEmail(user.getEmail());



        System.out.println("userDto = " + userDto);

    }

}

@Data
class User{
    private String name;
    private String password;
    private String email;
}

@Data
class UserDto{
    private String name;
    private String password;
    private String email;
}
