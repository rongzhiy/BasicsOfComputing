package org.alan.base.reflection;


//类对象，就是用于描述这种类，都有什么属性，什么方法的
//获取类对象有3种方式
//        1. Class.forName
//        2. Hero.class
//        3. new Hero().getClass()
//
//        在一个JVM中，一种类，只会有一个类对象存在。所以以上三种方式取出来的类对象，都是一样的。
public class TestReflection {
public static void main(String[] args) {
    String className = "org.alan.hello.reflection.Hero";
//    获取类对象的时候，会导致类属性被初始化
//    无论什么途径获取类对象，都会导致静态属性被初始化，而且只会执行一次。
//    （除了直接使用 Class c = Hero.class 这种方式，这种方式不会导致静态属性被初始化）


    try {
        Class pClass1 = Class.forName(className);
        Class pClass2 = Hero.class;
        Class pClass3 = new Hero().getClass();
        System.out.println(pClass1);
        System.out.println(pClass2);
        System.out.println(pClass3);
    } catch (ClassNotFoundException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
}
}


