package org.alan.base.gaoji;

/**
 * @author alan
 * @data 2022/5/9
 * @email 2735545128@qq.com
 */
public class 注解 {
}
//@Target(ElementType.TYPE)
//@Retention(RetentionPolicy.RUNTIME)
//public @interface Report {
//    int type() default 0;
//    String level() default "info";
//    String value() default "";
//}

//小结
//Java使用@interface定义注解：
//
//可定义多个参数和默认值，核心参数使用value名称；
//
//必须设置@Target来指定Annotation可以应用的范围；
//
//应当设置@Retention(RetentionPolicy.RUNTIME)便于运行期读取该Annotation。
