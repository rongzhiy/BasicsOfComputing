package org.alan.myio;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class WriterTest {
    public static void main(String[] args) {
        try (Writer output = new FileWriter("output.txt")) {
            output.write("你好，我是alan。");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
