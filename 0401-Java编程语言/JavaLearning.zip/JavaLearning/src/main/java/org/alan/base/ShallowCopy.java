package org.alan.base;


import lombok.Data;


class Address implements Cloneable{
    private String name;

    public Address(String name) {
        this.name = name;
    }

    // 省略构造函数、Getter&Setter方法
    @Override
    public Address1 clone() {
        try {
            return (Address1) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}

@Data
class Person implements Cloneable {
    private Address1 address;

    public Person(Address1 address) {
        this.address = address;
    }

    // 省略构造函数、Getter&Setter方法
    @Override
    public Person1 clone() {
        try {
            Person1 person = (Person1) super.clone();
            return person;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}


public class ShallowCopy {


    public static void main(String[] args) {
        Person1 person1 = new Person1(new Address1("武汉"));
        Person1 person1Copy = person1.clone();
// true
        System.out.println(person1.getAddress() == person1Copy.getAddress());

    }
}
