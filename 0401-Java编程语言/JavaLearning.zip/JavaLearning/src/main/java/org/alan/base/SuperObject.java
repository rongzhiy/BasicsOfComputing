package org.alan.base;

public class SuperObject extends Object {
//    public final native Class<?> getClass()  用于返回当前运行时对象的 Class 对象
    @Override
    public native int hashCode(); //native 方法，用于返回对象的哈希码，主要使用在哈希表中，比如 JDK 中的HashMap。

    @Override
    public boolean equals(Object obj){ //用于比较 2 个对象的内存地址是否相等，String 类对该方法进行了重写以用于比较字符串的值是否相等。
        return (this == obj);
    }

    @Override
    protected native Object clone() throws CloneNotSupportedException; //用于创建并返回当前对象的一份拷贝。

    @Override
    public String toString(){  //返回类的名字实例的哈希码的 16 进制的字符串表示。
        return getClass().getName() + "@" + Integer.toHexString(hashCode());
    }

//    public final native void notify(); //用于唤醒在此对象监视器上等待的单个线程。
//    public final native void notifyAll(); //用于唤醒在此对象监视器上等待的所有线程。
//    public final native void wait(long timeout) throws InterruptedException;  //用于导致当前线程等待，直到另一个线程调用此对象的 notify() 方法或 notifyAll() 方法，或者超过指定的时间量。
//    public final void wait(long timeout, int nanos) throws InterruptedException { }   //用于导致当前线程等待，直到另一个线程调用此对象的 notify() 方法或 notifyAll() 方法，或者其他某个线程中断当前线程，或者已超过某个实际时间量。
//    public final void wait() throws InterruptedException { }  //跟之前的2个wait方法一样，只不过该方法一直等待，没有超时时间这个概念

//    protected void finalize() throws Throwable {} //用于在垃圾收集器将对象从内存中清除出去之前做必要的清理工作。

    public static void main(String[] args) {
//        hashCode的作用
//        1.在集合中，如何判断两个对象是否相等，依赖于hashCode方法
//        2.在HashMap中，如何判断两个键值对是否相等，依赖于hashCode方法
//        3.在HashSet中，如何判断两个对象是否相等，依赖于hashCode方法
//        4.在Hashtable中，如何判断两个键值对是否相等，依赖于hashCode方法
//        5.在HashTable中，如何判断两个对象是否相等，依赖于hashCode方法
//        6.在ThreadLocal中，如何判断两个键值对是否相等，依赖于hashCode方法
//        7.在ThreadLocal中，如何判断两个对象是否相等，依赖于hashCode方法
//        8.在ThreadLocalMap中，如何判断两个键值对是否相等，依赖于hashCode方法
//        9.在ThreadLocalMap中，如何判断两个对象是否相等，依赖于hashCode方法

    }
}
