package org.alan.myio;

import java.io.*;

public class InputStreamTest {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        try (InputStream fis = new FileInputStream("input.txt")) {
            System.out.println("Number of remaining bytes:"
                    + fis.available());
            int content;
            long skip = fis.skip(2);
            System.out.println("The actual number of bytes skipped:" + skip);
            System.out.print("The content read from file:");
            while ((content = fis.read()) != -1) {
                System.out.print((char) content);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }



        // 新建一个 BufferedInputStream 对象
        BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream("input.txt"));
// 读取文件的内容并复制到 String 对象中
//        int result = bufferedInputStream.read();
//        System.out.println(result);


        FileInputStream fileInputStream = new FileInputStream("input.txt");
//必须将fileInputStream作为构造参数才能使用
        DataInputStream dataInputStream = new DataInputStream(fileInputStream);
//可以读取任意具体的类型数据
//        dataInputStream.readBoolean();
//        dataInputStream.readInt();
//          dataInputStream.readUTF();

//        对象反序列化
        ObjectInputStream input = new ObjectInputStream(new FileInputStream("file.txt"));
        Person person = (Person) input.readObject();
        System.out.println("person = " + person);
        input.close();

    }

}
