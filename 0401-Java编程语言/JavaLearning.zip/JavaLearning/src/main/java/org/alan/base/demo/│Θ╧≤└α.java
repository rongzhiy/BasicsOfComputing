package org.alan.base.demo;

/**
 * @author alan
 * @data 2022/5/9
 * @email 2735545128@qq.com
 * 由于多态的存在，每个子类都可以覆写父类的方法；如果父类Person的run()方法没有实际意义，能否去掉方法的执行语句？
 * 如果父类的方法本身不需要实现任何功能，仅仅是为了定义方法签名，目的是让子类去覆写它，那么，可以把父类的方法声明为抽象方法：
 *
 * class Person {
 *     public abstract void run();
 * }
 */
public class 抽象类 {
    public static void main(String[] args) {
        System.out.println("抽象类");
}
}
//这种尽量引用高层类型，避免引用实际子类型的方式，称之为面向抽象编程。
//面向抽象编程的本质就是：
//上层代码只定义规范（例如：abstract class Person）；
//不需要子类就可以实现业务逻辑（正常编译）；
//具体的业务逻辑由不同的子类实现，调用者并不关心。
//public class Main {
//    public static void main(String[] args) {
//        Person p = new Student();
//        p.run();
//    }
//}
//
//abstract class Person {
//    public abstract void run();
//}
//
//class Student extends Person {
//    @Override
//    public void run() {
//        System.out.println("Student.run");
//    }
//}
