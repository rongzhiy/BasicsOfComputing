package org.alan.base.demo;

public class Base {
    public static void main(String[] args) {
       A a = new B();
       a.show();

       H h = new I();
         h.show(1);

         class Base3 {  //局部内部类:  方法内部类
             public void show() {
                 System.out.println("Base3");
             }
         }

         new A() {  //匿名内部类: 没有类名，只能使用一次
             public int show() {
                 System.out.println("匿名内部类");
                     return 0;
             }
         }.show();
    }

   static class Base1 {  //静态内部类
        public void show() {
            System.out.println("Base1");
        }
    }

    class Base2 {  //成员内部类
        public void show() {
            System.out.println("Base2");
        }
    }






}
//java继承父类，重写方法
class A {
//    构造方法
    public A() {
        System.out.println("构造方法");
    }
    public int show() {
        System.out.println("A");
        return 0;
    }
}

class B extends A {
    public int show() {
        System.out.println("B");
        return 1;
    }
    public void show1() {
        System.out.println("B1");
    }
}

//java 接口继承用extends，类继承用implements
interface C {
    public void show();
}
interface E {
    public void show();
}
class D implements C, E {
    public void show() {
        System.out.println("D");
    }
}
interface F extends C, E {
    public void show();
}

//java抽象类
abstract class G {
    public abstract void show();
}



//java多态
class H {
    public void show() {
        System.out.println("H");
    }
    public void show(int i) {
        System.out.println("H1");
    }

}

class I extends H {
    public void show() {
        System.out.println("I");
    }
    public void show(int i) {
        System.out.println("I1");
    }
}


