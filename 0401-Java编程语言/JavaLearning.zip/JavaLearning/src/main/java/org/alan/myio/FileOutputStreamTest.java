package org.alan.myio;

import java.io.*;

public class FileOutputStreamTest {
    public static void main(String[] args) throws IOException {
        try (FileOutputStream output = new FileOutputStream("output.txt")) {
            byte[] array = "JavaGuide".getBytes();
            output.write(array);
        } catch (IOException e) {
            e.printStackTrace();
        }

//        //        对象序列化
        ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("file.txt"));
        Person person = new Person("Guide哥", "JavaGuide作者");
        try {
            output.writeObject(person);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}

class Person implements Serializable {
    private String name;
    private String desc;

    public Person(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
    @Override
public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", desc='" + desc + '\'' +
                '}';
    }
}
