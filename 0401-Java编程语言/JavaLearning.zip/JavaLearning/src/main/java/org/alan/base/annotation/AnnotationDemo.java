package org.alan.base.annotation;

public class AnnotationDemo {
    String name;

    @Deprecated
    public void hackMap(){

    }
    public static void main(String[] args) {
        new AnnotationDemo().hackMap();
    }
}
