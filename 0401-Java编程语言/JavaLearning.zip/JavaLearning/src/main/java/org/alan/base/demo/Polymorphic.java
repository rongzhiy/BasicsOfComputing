package org.alan.base.demo;

/**
 * @author alan
 * @data 2022/5/9
 * @email 2735545128@qq.com
 */
public class Polymorphic {
    public static void main(String[] args) {
        // 给一个有普通收入、工资收入和享受国务院特殊津贴的小伙伴算税:
        Income[] incomes = new Income[] {
                new Income(3000),
                new Salary(7500),
                new StateCouncilSpecialAllowance(15000)
        };
        System.out.println(totalTax(incomes));
    }
//观察totalTax()方法：利用多态，totalTax()方法只需要和Income打交道，
// 它完全不需要知道Salary和StateCouncilSpecialAllowance的存在，就可以正确计算出总的税。
// 如果我们要新增一种稿费收入，只需要从Income派生，然后正确覆写getTax()方法就可以。
// 把新的类型传入totalTax()，不需要修改任何代码。
//可见，多态具有一个非常强大的功能，就是允许添加更多类型的子类实现功能扩展，却不需要修改基于父类的代码。
 public static double totalTax(Income... incomes) {
        double total = 0;
        for (Income income: incomes) {
            total = total + income.getTax();
        }
        return total;
    }
}

class Income {
    protected double income;

    public Income(double income) {
        this.income = income;
    }

    public double getTax() {
        return income * 0.1; // 税率10%
    }
}

class Salary extends Income {
    public Salary(double income) {
        super(income);
    }

    @Override
    public double getTax() {
        if (income <= 5000) {
            return 0;
        }
        return (income - 5000) * 0.2;
    }
}

class StateCouncilSpecialAllowance extends Income {
    public StateCouncilSpecialAllowance(double income) {
        super(income);
    }

    @Override
    public double getTax() {
        return 0;
    }
}
