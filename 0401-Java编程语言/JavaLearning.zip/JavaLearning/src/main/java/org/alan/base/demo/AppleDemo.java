//package org.alan.hello.demo;
//
//import java.awt.*;
//
//import java.applet.*;
//
//public class AppletDemo extends Applet{
//
//
//    public void paint(Graphics g) {
//
//        g.drawString("Welcome to nhooo", 50, 50);
//
//    }
//
//}