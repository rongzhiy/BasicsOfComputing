package org.alan.base.demo;

/**
 * @author alan
 * @data 2022/5/9
 * @email 2735545128@qq.com
 */
class Person {
    protected String name;
    public final String hello() {
        return "Hello, " + name;
    }
}
//final
//继承可以允许子类覆写父类的方法。
// 如果一个父类不允许子类对它的某个方法进行覆写，
// 可以把该方法标记为final。用final修饰的方法不能被Override
//final修饰的类不能被继承
//final修饰的方法不可以被覆写
//final修饰的变量不可以被修改


class student extends Person {
//   @Override
//    public String hello() {
//        return "Hello, " + name + " (student)";
//    }
}
