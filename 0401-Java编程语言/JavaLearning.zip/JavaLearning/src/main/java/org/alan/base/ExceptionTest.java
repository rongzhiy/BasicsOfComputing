package org.alan.base;

import java.io.*;
import java.util.Scanner;

public class ExceptionTest {
    public static void main(String[] args) {
        try {
            System.out.println("Try to do something");
            throw new RuntimeException("RuntimeException");
        } catch (Exception e) {
            System.out.println("Catch Exception -> " + e.getMessage());
        } finally {
            System.out.println("Finally");
        }

    }
}

class FinalyTest{
    // 注意：不要在 finally 语句块中使用 return!
    // 当执行到 finally 语句中的 return 之后，这个本地变量的值就变为了 finally 语句中的 return 返回值。
    public static void main(String[] args) {
        System.out.println(f(2));

    }

    public static int f(int value) {
        try {
            return value * value;
        } finally {
            if (value == 2) {
                return 0;
            }
        }
    }

}

class FinalyTest2{
    //finally 中的代码不会被执行
    public static void main(String[] args) {
        try {
            System.out.println("Try to do something");
            throw new RuntimeException("RuntimeException");
        } catch (Exception e) {
            System.out.println("Catch Exception -> " + e.getMessage());
            // 终止当前正在运行的Java虚拟机
            System.exit(1);
        } finally {
            System.out.println("Finally");
        }

    }
}

class FinalyTest3{
    public static void main(String[] args) {
        //读取文本文件的内容
        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("D:\\IdeaProjects\\java-learning\\README.md"));
            while (scanner.hasNext()) {
                System.out.println(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }

//使用 Java 7 之后的 try-with-resources 语句改造上面的代码
        try (Scanner scanner1 = new Scanner(new File("D:\\IdeaProjects\\java-learning\\README.md"))) {
            while (scanner1.hasNext()) {
                System.out.println(scanner1.nextLine());
            }
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        }

    }
}
