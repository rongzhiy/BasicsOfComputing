package org.alan.juc;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * volatile 关键字能保证变量的可见性，但不能保证对变量的操作是原子性的。
 * 正常情况下，运行上面的代码理应输出 2500。但你真正运行了上面的代码之后，你会发现每次输出结果都小于 2500。
 * 为什么会出现这种情况呢？不是说好了，volatile 可以保证变量的可见性嘛！
 * 也就是说，如果 volatile 能保证 inc++ 操作的原子性的话。
 * 每个线程中对 inc 变量自增完之后，其他线程可以立即看到修改后的值。
 * 5 个线程分别进行了 500 次操作，那么最终 inc 的值应该是 5*500=2500。
 * 很多人会误认为自增操作 inc++ 是原子性的，实际上，inc++ 其实是一个复合操作，
 * 包括三步：
 * 读 * 取 inc 的值。
 * 对 inc 加 1。
 * 将 inc 的值写回内存。

 */
public class VolatoleAtomicityDemo {
    public volatile static int inc = 0;

    public void increase() {
        inc++;
    }

    public static void main(String[] args) throws InterruptedException {
        ExecutorService threadPool = Executors.newFixedThreadPool(5);
        VolatoleAtomicityDemo volatoleAtomicityDemo = new VolatoleAtomicityDemo();
        for (int i = 0; i < 5; i++) {
            threadPool.execute(() -> {
                for (int j = 0; j < 500; j++) {
                    volatoleAtomicityDemo.increase();
                }
            });
        }
        // 等待1.5秒，保证上面程序执行完成
        Thread.sleep(1500);
        System.out.println(inc);
        threadPool.shutdown();
    }
}
