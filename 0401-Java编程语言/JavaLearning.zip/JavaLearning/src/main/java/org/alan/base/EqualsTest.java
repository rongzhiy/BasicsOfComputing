package org.alan.base;

public class EqualsTest {

    /**
     * == 和 equals() 的区别
     * == 对于基本类型和引用类型的作用效果是不同的：
     * 对于基本数据类型来说，== 比较的是值。
     * 对于引用数据类型来说，== 比较的是对象的内存地址。
     *
     * equals() 不能用于判断基本数据类型的变量，只能用来判断两个对象是否相等。equals()方法存在于Object类中，
     * 而Object类是所有类的直接或间接父类，因此所有的类都有equals()方法。
     * equals() 方法存在两种使用情况：类没有重写 equals()方法：通过equals()比较该类的两个对象时，等价于通过“==”比较这两个对象，使用的默认是 Object类equals()方法。
     * 类重写了 equals()方法：一般我们都重写 equals()方法来比较两个对象中的属性是否相等；若它们的属性相等，则返回 true(即，认为这两个对象相等)。
     *
     */
    public static void main(String[] args) {
        String a = new String("ab"); // a 为一个引用
        String b = new String("ab"); // b为另一个引用,对象的内容一样
        System.out.println(a == b);// false

        String aa = "ab"; // 放在常量池中
        String bb = "ab"; // 从常量池中查找
        System.out.println(aa == bb);// true

        System.out.println(a.equals(b));// true
        System.out.println(42 == 42.0);// true

    }
}
