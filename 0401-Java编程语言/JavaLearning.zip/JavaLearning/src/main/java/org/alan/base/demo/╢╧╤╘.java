package org.alan.base.demo;

/**
 * @author alan
 * @data 2022/5/9
 * @email 2735545128@qq.com
 */
public class 断言 {
    //断言
    public static void main(String[] args) {
        int a = 1;
        int b = 2;
        assert a != b;
        System.out.println("断言成功");
    }
}
//这是怎么肥四？为什么assert语句不起作用？
//
//这是因为JVM默认关闭断言指令，即遇到assert语句就自动忽略了，不执行。
//
//要执行assert语句，必须给Java虚拟机传递-enableassertions（可简写为-ea）参数启用断言。所以，上述程序必须在命令行下运行才有效果：
//
//$ java -ea Main.java
//Exception in thread "main" java.lang.AssertionError
//	at Main.main(Main.java:5)
