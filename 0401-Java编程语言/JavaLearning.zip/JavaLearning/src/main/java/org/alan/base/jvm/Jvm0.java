package org.alan.base.jvm;

import java.util.ArrayList;
import java.util.List;

public class Jvm0 {
    public static void main(String[] args) {
        System.out.println("Hello JVM!");
//        List<Object> list = new ArrayList<>();
//        while(true){
//            list.add(new Object());
        //JVM调优
        //JVM调优的目的是让JVM运行在最佳状态，以达到最佳性能。
        //JVM调优的方法有很多，但是，最常用的方法是通过参数来调整JVM的运行参数。
//        如在VM options中添加参数：
//        -Xms512m -Xmx1024m -XX:+PrintGCDetails


    }
}
