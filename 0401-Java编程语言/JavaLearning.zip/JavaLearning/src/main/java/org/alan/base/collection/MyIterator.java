package org.alan.base.collection;

import java.util.ArrayList;
import java.util.Iterator;

// 当遍历集合时，首先通过调用集合的 iterator() 方法获得迭代器对象，
//然后使用 hashNext() 方法判断集合中是否存在下一个元素，
//如果存在，则调用 next() 方法将元素取出，否则说明已到达了集合末尾，停止遍历元素。
public class MyIterator {
    public static void main(String[] args) {
        //定义集合,添加数据
        ArrayList<Integer> list = new ArrayList<>();
        list.add(100);
        list.add(200);
        list.add(300);
        //增强型for循环遍历
        for(Integer value:list){
            System.out.println(value);
        }
        //首先通过调用集合的 iterator()方法获得迭代器对象
        Iterator<Integer> listIt = list.iterator();
        while (listIt.hasNext()) {//判断集合中是否还有元素
            System.out.println(listIt.next());//将集合取出
        }

//正确的移除方法
        while(listIt.hasNext()){
//设置移除元素的条件
            listIt.remove();
            System.out.println(listIt.hasNext());
        }

//一种最常见的错误代码如下
//        for(Integer i : list){
//            list.remove(i);//报 ConcurrentModificationException 异常
//        }



    }
}

