package org.alan.base.GUI;

import javax.swing.*;
import java.awt.*;

public class TestGUI {
//    public static void main(String[] args) {
//        // 主窗体
//        JFrame f = new JFrame("LoL");
//
//        // 主窗体设置大小
//        f.setSize(900, 800);
//
//        // 主窗体设置位置
//        f.setLocation(200, 200);
//
//        // 主窗体中的组件设置为绝对定位
//        f.setLayout(null);
//
//        // 按钮组件
//        JButton b = new JButton("一键秒对方基地挂");
//
//        // 同时设置组件的大小和位置
//        b.setBounds(100, 50, 280, 30);
//
//        // 把按钮加入到主窗体中
//        f.add(b);
//
//        // 关闭窗体的时候，退出程序
//        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        // 让窗体变得可见
//        f.setVisible(true);
//
//    }
//public static void main(String[] args) {
//
//    //普通的窗体，带最大和最小化按钮，而对话框却不带
//    JDialog d = new JDialog();
//    d.setTitle("LOL");
//    d.setSize(400, 300);
//    d.setLocation(200, 200);
//    d.setLayout(null);
//    JButton b = new JButton("一键秒对方基地挂");
//    b.setBounds(50, 50, 280, 30);
//
//    d.add(b);
//
//    d.setVisible(true);
//}

//    public static void main(String[] args) {
//        JFrame f = new JFrame("外部窗体");
//        f.setSize(800, 600);
//        f.setLocation(100, 100);
//
//        // 根据外部窗体实例化JDialog
//        JDialog d = new JDialog(f);
//        // 设置为模态
//        d.setModal(true);
//
//        d.setTitle("模态的对话框");
//        d.setSize(400, 300);
//        d.setLocation(200, 200);
//        d.setLayout(null);
//        JButton b = new JButton("一键秒对方基地挂");
//        b.setBounds(50, 50, 280, 30);
//        d.add(b);
//
//        f.setVisible(true);
//        d.setVisible(true);
//
//    }

    public static void main(String[] args) {

        JFrame f = new JFrame("LoL");
        f.setSize(400, 300);
        f.setLocation(200, 200);
        // 设置布局器为FlowLayerout
        // 容器上的组件水平摆放
        f.setLayout(new FlowLayout());

        JButton b1 = new JButton("英雄1");
        JButton b2 = new JButton("英雄2");
        JButton b3 = new JButton("英雄3");

        // 加入到容器即可，无需单独指定大小和位置
        f.add(b1);
        f.add(b2);
        f.add(b3);

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f.setVisible(true);
    }

}
