package org.alan.base.gaoji;

/**
 * @author alan
 * @data 2022/5/9
 * @email 2735545128@qq.com
 */
public class 反射 {
    public static void main(String[] args) {
        printClassInfo("".getClass());
        printClassInfo(Runnable.class);
        printClassInfo(java.time.Month.class);
        printClassInfo(String[].class);
        printClassInfo(int.class);
    }

    static void printClassInfo(Class cls) {
        System.out.println("Class name--------------------------------: " + cls.getName());
        System.out.println("Simple name: " + cls.getSimpleName());
        if (cls.getPackage() != null) {
            System.out.println("Package name: " + cls.getPackage().getName());
        }
        System.out.println("is interface: " + cls.isInterface());
        System.out.println("is enum: " + cls.isEnum());
        System.out.println("is array: " + cls.isArray());
        System.out.println("is primitive: " + cls.isPrimitive());
    }
}
//VM为每个加载的class及interface创建了对应的Class实例来保存class及interface的所有信息；
//
//获取一个class对应的Class实例后，就可以获取该class的所有信息；
//
//通过Class实例获取class信息的方法称为反射（Reflection）；
//
//JVM总是动态加载class，可以在运行期根据条件来控制加载class。
