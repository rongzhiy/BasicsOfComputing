package org.alan.test;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

@SpringBootApplication
@EnableAsync
public class AsyncTest {
    public static void main(String[] args) {
        AsyncService asyncService = new AsyncService();
        asyncService.async();
        System.out.println(Thread.currentThread());
    }
}

@Component
class AsyncService {
    @Async
    public void async(){
        try {
            Thread.sleep(1000);
            System.out.println(Thread.currentThread());
            System.out.println("async");
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}