package org.alan.myio;

import java.io.*;
import java.nio.file.*;

public class IODesgin {
    public static void main(String[] args) throws IOException {

//  装饰器举例：      BufferedInputStream（字节缓冲输入流）来增强 FileInputStream 的功能
        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream("input.txt"))) {
            int content;
            long skip = bis.skip(2);
            while ((content = bis.read()) != -1) {
                System.out.print((char) content);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
//        适配器举例
//        InputStreamReader 和 OutputStreamWriter 就是两个适配器(Adapter)，
//        同时，它们两个也是字节流和字符流之间的桥梁。InputStreamReader 使用 StreamDecoder （流解码器）对字节进行解码，实现字节流到字符流的转换，
//        OutputStreamWriter 使用StreamEncoder（流编码器）对字符进行编码，实现字符流到字节流的转换。

        // InputStreamReader 是适配器，FileInputStream 是被适配的类
        InputStreamReader isr = new InputStreamReader(new FileInputStream(new File("input.txt")), "UTF-8");
        // BufferedReader 增强 InputStreamReader 的功能（装饰器模式）
        BufferedReader bufferedReader = new BufferedReader(isr);
        System.out.println("bufferedReader = " + bufferedReader);

//        工厂模式举例： 工厂模式用于创建对象，NIO 中大量用到了工厂模式，比如 Files 类的 newInputStream 方法用于创建 InputStream 对象（静态工厂）、 Paths 类的 get 方法创建 Path 对象（静态工厂）
//        InputStream is Files.newInputStream(Paths.get(generatorLogoPath));

        // 观察者模式：  NIO 中的文件目录监听服务使用到了观察者模式。
//        NIO 中的文件目录监听服务基于 WatchService 接口和 Watchable 接口。WatchService 属于观察者，Watchable 属于被观察者。
    // 创建 WatchService 对象
            WatchService watchService = FileSystems.getDefault().newWatchService();

    // 初始化一个被监控文件夹的 Path 类:
            Path path = Paths.get("workingDirectory");
    // 将这个 path 对象注册到 WatchService（监控服务） 中去
            WatchKey watchKey = path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);


    }
}
