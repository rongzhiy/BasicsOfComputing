"java's learn" 

https://javaguide.cn/
