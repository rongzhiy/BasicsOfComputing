package com.yupi.sqlfather.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yupi.sqlfather.model.entity.User;

/**
 * @Entity com.yupi.sqlfather.model.domain.User
 */
public interface UserMapper extends BaseMapper<User> {

}




